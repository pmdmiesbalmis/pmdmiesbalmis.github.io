package com.pmdm.agenda.data.firestore.contacto

import com.google.firebase.firestore.Exclude

data class ContactoFSDocument(
    @get:Exclude
    val id: Int = 0,
    val nombre: String = "",
    val apellidos: String = "",
    val foto: String? = null,
    val correo: String = "",
    val telefono: String = "",
    val categorias: List<String> = emptyList()
)
