package com.pmdm.agenda

import android.app.Application
import android.util.Log
import com.pmdm.agenda.data.firestore.contacto.ContactoFSService
import com.pmdm.agenda.data.mocks.contacto.ContactoDaoMock
import com.pmdm.agenda.data.toContacto
import com.pmdm.agenda.data.toContactoFSDocument
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@HiltAndroidApp
class AgendaApplication : Application()  {
    @Inject
    lateinit var daoMock: ContactoDaoMock
    @Inject
    lateinit var daoDocuments: ContactoFSService

    override fun onCreate() {
        super.onCreate()

        runBlocking {
            if (daoDocuments.count() == 0)
                daoMock.get()
                    .forEach { daoDocuments.insert(it.toContacto().toContactoFSDocument()) }
        }
    }
}