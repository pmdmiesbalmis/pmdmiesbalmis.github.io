package com.pmdm.agenda.data.firestore.contacto

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

class FirestoreException(message: String) : Exception(message)

@Singleton
class ContactoFSService @Inject constructor(
    private val firestore: FirebaseFirestore
) {
    private companion object {
        const val COLLECTION = "contactos"
        const val TAG = "Firestore"

        object Fields {
            const val ID = "id"
            const val NOMBRE = "nombre"
            const val APELLIDOS = "apellidos"
            const val FOTO = "foto"
            const val CORREO = "correo"
            const val TELEFONO = "telefono"
            const val CATEGORIAS = "categorias"
        }
    }

    private fun Exception.gestionaError(mensaje: String) {
        Log.e(TAG, "$mensaje: ${this.localizedMessage}", this)
        throw FirestoreException(mensaje)
    }

    suspend fun get(): List<ContactoFSDocument> {
        return firestore
            .collection(COLLECTION)
            .get()
            .addOnFailureListener { e ->
                e.gestionaError("Error al obtener los contactos")
            }
            .await()
            .documents.map { document ->
                document.toObject(ContactoFSDocument::class.java)!!.copy(id = document.id.toInt())
            }
    }

    suspend fun get(id: Int): ContactoFSDocument? {
        return firestore
            .collection(COLLECTION)
            .document(id.toString())
            .get()
            .addOnFailureListener { e ->
                e.gestionaError("Error al obtener el contacto $id")
            }
            .await()
            ?.let { document ->
                document.toObject(ContactoFSDocument::class.java)?.copy(id = document.id.toInt())
            }
    }

    suspend fun insert(contacto: ContactoFSDocument) {
        firestore
            .collection(COLLECTION)
            .document(contacto.id.toString())
            .set(contacto)
            .addOnFailureListener { e ->
                e.gestionaError("Error al insertar el contacto ${contacto.id}")
            }
            .await()
    }

    suspend fun update(contacto: ContactoFSDocument) {
        firestore
            .collection(COLLECTION)
            .document(contacto.id.toString())
            .set(contacto, SetOptions.merge())
            .addOnFailureListener { e ->
                e.gestionaError("Error al actualizar el contacto ${contacto.id}")
            }
            .await()
    }

    suspend fun delete(id: Int) {
        firestore
            .collection(COLLECTION)
            .document(id.toString())
            .delete()
            .addOnFailureListener { e ->
                e.gestionaError("Error al borrar el contacto $id")
            }
            .await()
    }

    suspend fun count(): Int {
        val querySnapshot = firestore
            .collection(COLLECTION)
            .get()
            .addOnFailureListener { e ->
                e.gestionaError("Error al obtener el número de contactos")
            }
            .await()
        return querySnapshot.size()
    }

    suspend fun get(
        ascendente: Boolean,
        categorias: List<String>,
    ): List<ContactoFSDocument> = firestore
        .collection(COLLECTION)
        .orderBy(
            Fields.NOMBRE,
            if (ascendente) Query.Direction.ASCENDING
            else Query.Direction.DESCENDING
        )
        .whereArrayContainsAny(Fields.CATEGORIAS, categorias)
        .get()
        .addOnFailureListener { e ->
            e.gestionaError("Error al obtener contactos por categorías.")
        }
        .await()
        .documents.map { document ->
            document.toObject(ContactoFSDocument::class.java)!!.copy(id = document.id.toInt())
        }
}