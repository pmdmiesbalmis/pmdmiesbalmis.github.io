package com.pmdm.gestionimagenesazure.ui.features

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.github.pmdmiesbalmis.utilities.imagetools.toBlob
import com.pmdm.gestionimagenesazure.ui.features.formcontacto.ContactoEvent
import com.pmdm.gestionimagenesazure.data.ContactoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayInputStream
import javax.inject.Inject


@HiltViewModel
class ContactoViewModel @Inject constructor(
    private val contactoRepository: ContactoRepository,
    private val application: Application
) : AndroidViewModel(application) {

    var contactosState = mutableStateListOf<ContactoUiState>()
    var contactoState by mutableStateOf(ContactoUiState())

    init {
        runBlocking {
            contactosState = contactoRepository.get().toContatosUiState().toMutableStateList()
        }
    }

    private fun extensionStream(imageBitmap: ImageBitmap): String {
        val biteArray = imageBitmap.toBlob()
        val inputStream = ByteArrayInputStream(biteArray)
        val bytes = ByteArray(4)
        inputStream.read(bytes)
        val hexadecimal = bytes.joinToString(" ") { "%02X".format(it) }
        val extension = when (hexadecimal) {
            "FF D8 FF E0" -> "jpeg"
            "89 50 4E 47" -> "png"
            "47 49 46 38" -> "gif"
            "25 50 44 46" -> "pdf"
            else -> ""
        }
        inputStream.close()
        return extension
    }

    fun onContactoEvent(e: ContactoEvent) {
        when (e) {
            is ContactoEvent.OnChangeFoto -> {
                val extension = extensionStream(e.imageBitmap)
                val mimeType = "image/$extension"
                val blobName = "imagen_${System.currentTimeMillis()}.${extension}"
                contactoState = contactoState.copy(
                    id = e.contactoUiState.id,
                    nombre = e.contactoUiState.nombre,
                    urlFoto = blobName
                )
                val byteArray = e.imageBitmap.toBlob()
                val requestBody =
                    byteArray.toRequestBody(mimeType.toMediaTypeOrNull(), 0, byteArray.size)

                viewModelScope.launch {
                    contactoRepository.update(contactoState.toContacto())
                    contactoRepository.subirImagen(blobName, requestBody)
                    val indice =
                        contactosState.indexOf(contactosState.find { it.id == e.contactoUiState.id })
                    contactosState[indice] = contactoState

                }
            }
        }
    }
}
