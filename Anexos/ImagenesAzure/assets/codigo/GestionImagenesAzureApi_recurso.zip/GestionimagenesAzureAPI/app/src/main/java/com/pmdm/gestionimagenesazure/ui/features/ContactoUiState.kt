package com.pmdm.gestionimagenesazure.ui.features


import com.pmdm.gestionimagenesazure.models.Contacto
import java.time.Instant

data class ContactoUiState(
    val id: Int = Instant.now().epochSecond.toInt(),
    val nombre: String = "",
    val urlFoto: String?=null,
)

fun ContactoUiState.toContacto() = Contacto(
    id = id,
    nombre = nombre,
    foto = urlFoto,
)

fun Contacto.toContactoUiState() = ContactoUiState(
    id = id,
    nombre = nombre,
    urlFoto = foto,
)

fun List<ContactoUiState>.toContatos()= this.map { it.toContacto() }
fun List<Contacto>.toContatosUiState()= this.map { it.toContactoUiState() }