package com.pmdm.gestionimagenesazure.data.mocks.contacto

data class ContactoMock(
    val id: Int,
    val nombre: String,
    val foto: String?,

)