package com.pmdm.gestionimagenesazure.ui.features.formcontacto

import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import com.pmdm.gestionimagenesazure.ui.features.ContactoUiState


sealed interface ContactoEvent {
    data class OnChangeFoto(val imageBitmap: ImageBitmap, val contactoUiState: ContactoUiState) : ContactoEvent
}