package com.pmdm.gestionimagenesazure.data.services
class ApiServicesException(mensaje: String) : Exception(mensaje)
