package com.pmdm.gestionimagenesazure.ui.features

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pmdm.gestionimagenesazure.ui.features.formcontacto.ContactoEvent
import com.pmdm.gestionimagenesazure.data.mocks.contacto.ContactoDaoMock

@Composable
fun ListaContactosScreen(
    modifier: Modifier = Modifier,
    contactosState: List<ContactoUiState>,
    onContactoEvent: (ContactoEvent) -> Unit,
) {
    Box(modifier = modifier.then(Modifier.fillMaxSize())) {
        LazyColumn(
            contentPadding = PaddingValues(all = 4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(
                contactosState,
                key = { it.id }
            ) { contacto ->
                FormContactoScreen(contacto, onContactoEvent)
             //   Column {  }

            }
        }
    }

}


@Preview(
    name = "PORTRAIT",
    device = "spec:width=360dp,height=800dp,dpi=480",
    showBackground = true
)
@Composable
fun ListaContactosScreenTest() {
    val contactos = ContactoDaoMock().get().map {
        ContactoUiState(
            id = it.id,
            urlFoto = "sinfoto.png",
            nombre = it.nombre,
        )
    }

    // Definimos un estado que nos permitirá gestionar el contacto
    // actualmente seleccionado y su manejador
    var contactoSeleccionadoState: ContactoUiState? by remember { mutableStateOf(null) }
    var onContactoClicked: (ContactoUiState) -> Unit = { c ->
        contactoSeleccionadoState =
            if (contactoSeleccionadoState == null
                || c.id != contactoSeleccionadoState!!.id) c.copy()
            else null
    }

    ListaContactosScreen(
        modifier = Modifier.fillMaxSize(),
        contactosState = contactos,
        {}
    )
}