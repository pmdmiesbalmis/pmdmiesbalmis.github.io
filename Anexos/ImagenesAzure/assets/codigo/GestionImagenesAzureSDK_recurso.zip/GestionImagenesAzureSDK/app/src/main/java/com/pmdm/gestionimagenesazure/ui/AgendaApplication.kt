package com.pmdm.gestionimagenesazure.ui

import android.app.Application
import com.pmdm.gestionimagenesazure.data.ContactoRepository
import com.pmdm.gestionimagenesazure.data.mocks.contacto.ContactoDaoMock
import com.pmdm.gestionimagenesazure.data.room.ContactoDao
import com.pmdm.gestionimagenesazure.data.toContacto
import com.pmdm.gestionimagenesazure.data.toContactoEntity
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@HiltAndroidApp
class AgendaApplication : Application()  {
    @Inject
    lateinit var daoMock: ContactoDaoMock
    @Inject
    lateinit var daoEntity: ContactoDao
 /*   @Inject
    lateinit  var  contactoRepository:ContactoRepository

    override fun onCreate() {
        super.onCreate()

        runBlocking {
            if (contactoRepository.count()==0)
                daoMock.get().forEach {contactoRepository.insert(it.toContacto()) }
        }
    }*/
}