package com.pmdm.gestionimagenesazure.models

data class Contacto(
    val id: Int,
    val nombre: String,
    val foto: String?,
)