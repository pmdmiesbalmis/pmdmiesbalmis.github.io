package com.pmdm.gestionimagenesazure.data.mocks.contacto

import javax.inject.Inject

class ContactoDaoMock @Inject constructor() {


    private var contactos = mutableListOf(
        ContactoMock(
            id = 1,
            nombre = "Xusa",
            foto = "sinfoto.png",
        ),
        ContactoMock(
            id = 2,
            nombre = "Jose",
            foto = "sinfoto.png",
        ),
        ContactoMock(
            id = 3,
            nombre = "Juan José",
            foto = "sinfoto.png",
        ),
        ContactoMock(
            id = 4,
            nombre = "Vicente",
            foto = "sinfoto.png",
        ),
        ContactoMock(
            id = 5,
            nombre = "Vicente José",
            foto = "sinfoto.png",
        ),
        ContactoMock(
            id = 6,
            nombre = "Luís",
            foto = "sinfoto.png",
        ),
    )

    fun get(): MutableList<ContactoMock> = contactos
    fun get(id: Int): ContactoMock? = contactos.find { u -> u.id == id }
    fun insert(contacto: ContactoMock) = contactos.add(contacto)
    fun update(contacto: ContactoMock) {
        val index = contactos.indexOfFirst { u -> u.id == contacto.id }
        if (index != -1) contactos[index] = contacto
    }

    fun delete(id: Int) {
        val index = contactos.indexOfFirst { u -> u.id == id }
        if (index != -1) contactos.removeAt(index)
    }
}
