package com.pmdm.gestionimagenesazure.data

import com.pmdm.gestionimagenesazure.data.mocks.contacto.ContactoMock
import com.pmdm.gestionimagenesazure.data.room.ContactoEntity
import com.pmdm.gestionimagenesazure.data.services.ContactoApi
import com.pmdm.gestionimagenesazure.models.Contacto


fun Contacto.toContactoMock() = ContactoMock(
    id = id,
    nombre = nombre,
    foto = foto,
)
fun ContactoMock.toContacto() = Contacto(
    id = id,
    nombre = nombre,
    foto = foto,
)

fun Contacto.toContactoEntity() = ContactoEntity(
    id = id,
    nombre = nombre,
    foto = foto,
)

fun ContactoEntity.toContacto() = Contacto(
    id = id,
    nombre = nombre,
    foto = foto,
)

fun Contacto.toContactoApi() = ContactoApi(
    id = id,
    nombre = nombre,
    foto = foto,
)

fun ContactoApi.toContacto() = Contacto(
    id = id,
    nombre = nombre,
    foto = foto,
)