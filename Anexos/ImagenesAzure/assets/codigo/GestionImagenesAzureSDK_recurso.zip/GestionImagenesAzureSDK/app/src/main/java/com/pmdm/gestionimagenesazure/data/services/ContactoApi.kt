package com.pmdm.gestionimagenesazure.data.services

import com.google.gson.annotations.SerializedName

data class ContactoApi(
    val id: Int,
    @SerializedName(value = "nombre")
    val nombre: String,
    val foto: String?,
)
