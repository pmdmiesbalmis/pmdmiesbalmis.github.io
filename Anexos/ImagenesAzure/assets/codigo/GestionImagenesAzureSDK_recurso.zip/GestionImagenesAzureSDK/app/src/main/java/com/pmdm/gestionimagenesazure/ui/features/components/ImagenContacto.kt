package com.pmdm.gestionimagenesazure.ui.features.components

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.pmdm.gestionimagenesazure.R
import com.pmdm.gestionimagenesazure.ui.theme.GestionImagenesTheme


@Composable
fun ImagenContacto(
    modifier: Modifier = Modifier,
    urlFoto: String,
    anchoBorde: Dp = 4.dp
) {
    val urlCompleta = "https://almacenimagenes.blob.core.windows.net/contenedor1/$urlFoto"
    AsyncImage(
        model = urlCompleta,
        contentDescription = "Imagen contacto",
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .clip(CircleShape)
            .aspectRatio(ratio = 1f)
            .background(MaterialTheme.colorScheme.surface)
            .border(
                width = anchoBorde,
                color = MaterialTheme.colorScheme.inversePrimary,
                shape = CircleShape
            ),
        error = painterResource(R.drawable.face_2_24px)
    )
}

@Preview(showBackground = true)
@Composable
fun ImagenContactoPreviewSinFoto() {
    GestionImagenesTheme {
        Box(
            modifier = Modifier
                .width(300.dp)
                .height(200.dp)
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) {
            ImagenContacto(
                modifier = Modifier.fillMaxHeight(),
                urlFoto = "sinfoto.png"
            )
        }
    }
}

@Preview(showBackground = true)
@Preview(
    showBackground = true,
    uiMode = Configuration.UI_MODE_NIGHT_YES or Configuration.UI_MODE_TYPE_NORMAL
)
@Composable
fun ImagenContactoPreviewConFotoYFondo() {
    GestionImagenesTheme {
        Box(
            modifier = Modifier
                .width(300.dp)
                .height(200.dp)
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) {
            val bitmapFoto = ImageBitmap.imageResource(id = R.drawable.foto_prueba)
            val painterBg = painterResource(
                id = if (isSystemInDarkTheme()) R.drawable.bg_dark else R.drawable.bg_light
            )

            Image(
                painterBg,
                contentDescription = "Fondo",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.matchParentSize()
            )
            ImagenContacto(
                modifier = Modifier.fillMaxHeight(),
                urlFoto = "sinfoto.png"
            )
        }
    }
}
