package com.pmdm.gestionimagenesazure.ui.features

import android.net.Uri
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.github.pmdmiesbalmis.components.ui.icons.Filled
import com.github.pmdmiesbalmis.utilities.device.*
import com.pmdm.gestionimagenesazure.ui.features.components.ImagenContacto
import com.pmdm.gestionimagenesazure.ui.features.formcontacto.ContactoEvent
import com.pmdm.gestionimagenesazure.R
import com.pmdm.gestionimagenesazure.ui.theme.GestionImagenesTheme
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date

/*
@Composable
fun registroSelectorDeImagenesConGetContent(
    onFotoCambiada: (Uri) -> Unit,
): ManagedActivityResultLauncher<String, Uri?> {
    val context = LocalContext.current
    return rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            onFotoCambiada(it)
        }
    }
}

@Composable
fun registroHacerFotoConTakePicture(
    onFotoCambiada: (Uri) -> Unit
): ManagedActivityResultLauncher<String, Boolean> {

    val context = LocalContext.current
    val ficheroTemporal = File.createTempFile(
        "JPEG_${SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())}_",
        ".jpg",
        context.externalCacheDir
    )
    val uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.provider",
        ficheroTemporal
    )
    val cameraLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                onFotoCambiada(uri)
            }
        }
    return rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { success ->
        if (success) {
            cameraLauncher.launch(uri)
        }
    }
}
*/
@Composable
private fun CabeceraFoto(
    backgroundModifier: Modifier = Modifier,
    imageModifier: Modifier = Modifier,
    urlFoto: String,
    onFotoCambiada: (ImageBitmap) -> Unit,

    ) {
    val slectorDeImagenes = registroSelectorDeImagenesConGetContent(onFotoCambiada)
    val hacerFoto = registroHacerFotoConTakePicture(onFotoCambiada)

    Box(
        modifier = backgroundModifier.then(
            Modifier.background(MaterialTheme.colorScheme.primary)
        ),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(
                id = if (isSystemInDarkTheme()) R.drawable.bg_dark else R.drawable.bg_light
            ),
            contentDescription = "Fondo",
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.matchParentSize()
        )
        ImagenContacto(
            modifier = imageModifier.then(Modifier.padding(16.dp)),
            urlFoto = urlFoto,
            anchoBorde = 4.dp,
        )
        OutlinedIconButton(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp),
            onClick = { hacerFoto.launch(android.Manifest.permission.CAMERA) }
        ) {
            Icon(
                painter = Filled.getPhotoCameraIcon(),
                contentDescription = "Hacer Foto",
                modifier = Modifier.size(ButtonDefaults.IconSize),
            )
        }
        OutlinedIconButton(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            onClick = { slectorDeImagenes.launch("image/*") }
        ) {
            Icon(
                painter = Filled.getImageIcon(),
                contentDescription = "Cargar Imagen",
                modifier = Modifier.size(ButtonDefaults.IconSize),
            )
        }
    }
}

@Composable
private fun CuerpoFormulario(
    modifier: Modifier = Modifier,
    contactoState: ContactoUiState,
) {
    Box(
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {

            Text(
                modifier = Modifier.fillMaxWidth(),
                text = contactoState.nombre,
            )

        }
    }
}


@Composable
fun FormContactoScreen(
    contactoState: ContactoUiState,
    onContactoEvent: (ContactoEvent) -> Unit,
) {
    Column {
        CabeceraFoto(
            backgroundModifier = Modifier
                .fillMaxWidth()
                .size(height = 225.dp, width = 0.dp),
            imageModifier = Modifier.fillMaxWidth(),
            urlFoto = contactoState.urlFoto ?: "sinfoto.png",
            onFotoCambiada = { uri ->
                onContactoEvent(
                    ContactoEvent.OnChangeFoto(
                        uri, contactoState
                    )
                )
            }
        )
        CuerpoFormulario(
            modifier = Modifier.fillMaxWidth(),
            contactoState = contactoState,
        )
    }
}


@Preview(
    name = "PORTRAIT",
    device = "spec:width=360dp,height=800dp,dpi=480",
    showBackground = true
)

@Composable
fun FormContactoScreenTest() {
    var contactoState by remember { mutableStateOf(ContactoUiState()) }

    GestionImagenesTheme {
        Surface {
            FormContactoScreen(
                contactoState = contactoState,
                onContactoEvent = { e ->
                    when (e) {

                        is ContactoEvent.OnChangeFoto -> {
                            val blobName = "imagen_${System.currentTimeMillis()}.jpg"
                            contactoState = contactoState.copy(urlFoto = blobName)
                        }

                    }
                })
        }
    }
}
