package com.pmdm.gestionimagenesazure.ui.features

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.azure.storage.blob.BlobClientBuilder
import com.github.pmdmiesbalmis.utilities.imagetools.toBlob
import com.pmdm.gestionimagenesazure.data.ContactoRepository
import com.pmdm.gestionimagenesazure.ui.features.formcontacto.ContactoEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.internal.ws.RealWebSocket
import java.io.ByteArrayInputStream
import java.io.InputStream
import javax.inject.Inject


@HiltViewModel
class ContactoViewModel @Inject constructor(
    private val contactoRepository: ContactoRepository,
    private val application: Application
) : AndroidViewModel(application) {

    var contactosState = mutableStateListOf<ContactoUiState>()
    var contactoState by mutableStateOf(ContactoUiState())

    init {
        runBlocking {
            contactosState = contactoRepository.get().toContatosUiState().toMutableStateList()
        }
    }

    private fun extensionStream(imageBitmap: ImageBitmap): String {
        val biteArray = imageBitmap.toBlob()
        val inputStream = ByteArrayInputStream(biteArray)
        val bytes = ByteArray(4)
        inputStream.read(bytes)
        val hexadecimal = bytes.joinToString(" ") { "%02X".format(it) }
        val extension = when (hexadecimal) {
            "FF D8 FF E0" -> "jpeg"
            "89 50 4E 47" -> "png"
            "47 49 46 38" -> "gif"
            "25 50 44 46" -> "pdf"
            else -> ""
        }
        inputStream.close()
        return extension
    }

    fun onContactoEvent(e: ContactoEvent) {
        when (e) {
            is ContactoEvent.OnChangeFoto -> {
                val extension = extensionStream(e.imageBitmap)
                val connectionString =
                    "DefaultEndpointsProtocol=https;AccountName=almacenimagenes;AccountKey=E2XnAGzC5c+KPrtDQHurdxIrO9US8mU26Db/9PYiiQNHTUEzmLunnh4j040ulDiCdSfZ9gQpgu6D+AStg9J8rA==;EndpointSuffix=core.windows.net"
                val containerName = "contenedor1"

                val blobName = "imagen_${System.currentTimeMillis()}.${extension}"
                val biteArray = e.imageBitmap.toBlob()
                val stream = ByteArrayInputStream(biteArray)
                val blobClient = BlobClientBuilder()
                    .connectionString(connectionString)
                    .containerName(containerName)
                    .blobName(blobName)
                    .buildClient()

                contactoState = contactoState.copy(
                    id = e.contactoUiState.id,
                    nombre = e.contactoUiState.nombre,
                    urlFoto = blobName
                )
                viewModelScope.launch {
                    contactoRepository.update(contactoState.toContacto())
                    blobClient.upload(stream, stream.available().toLong(), true)
                    val indice =
                        contactosState.indexOf(contactosState.find { it.id == e.contactoUiState.id })
                    contactosState[indice] = contactoState
                    stream.close()

                }

            }
        }
    }
}
