package com.pmdm.gestionimagenesazure.data.room

import android.content.Context
import androidx.room.*

@Database(
    entities = [ContactoEntity::class],
    exportSchema = false,
    version = 1
)

abstract class ContactoDb : RoomDatabase() {
    abstract fun contactoDao(): ContactoDao

    companion object {
        @Volatile
        private var db: ContactoDb? = null

        fun getDatabase(context: Context) = Room.databaseBuilder(
            context,
            ContactoDb::class.java, "agenda"
        )
        .allowMainThreadQueries()
        .fallbackToDestructiveMigration()
        .build()
    }
}
