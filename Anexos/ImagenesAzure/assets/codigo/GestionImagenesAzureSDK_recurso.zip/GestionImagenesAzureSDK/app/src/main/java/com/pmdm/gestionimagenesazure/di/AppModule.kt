package com.pmdm.gestionimagenesazure.di

import android.content.Context
import com.pmdm.gestionimagenesazure.data.ContactoRepository
import com.pmdm.gestionimagenesazure.data.mocks.contacto.ContactoDaoMock
import com.pmdm.gestionimagenesazure.data.room.ContactoDb
import com.pmdm.gestionimagenesazure.data.room.ContactoDao
import com.pmdm.gestionimagenesazure.data.services.ContactoService
import com.pmdm.gestionimagenesazure.data.services.ContactoServiceImplementation
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class AppModule {
    @Provides
    @Singleton
    fun provideOkHttpClient() : OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = HttpLoggingInterceptor.Level.HEADERS

        val timeout = 30L
        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(timeout, TimeUnit.SECONDS)
            .readTimeout(timeout, TimeUnit.SECONDS)
            .writeTimeout(timeout, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    @Named("DefaultRetrofit")
    fun provideRetrofit(
        okHttpClient: OkHttpClient
    ) : Retrofit = Retrofit.Builder()
        .client(okHttpClient)
        .baseUrl("http://10.0.2.2/contacto24/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()


    @Provides
    @Singleton
    fun provideContactoService(@Named("DefaultRetrofit")
        retrofit: Retrofit
    ) : ContactoService = retrofit.create(ContactoService::class.java)

    @Provides
    @Singleton
    fun provideAgendaDatabase(
        @ApplicationContext context: Context
    ) : ContactoDb = ContactoDb.getDatabase(context)

    @Provides
    @Singleton
    fun provideContactoDao(
        db: ContactoDb
    ) : ContactoDao = db.contactoDao()

    @Provides
    @Singleton
    fun provideContactoDaoMock() : ContactoDaoMock = ContactoDaoMock()

    @Provides
    @Singleton
    fun provideContactoRepository(
        contactoServiceImplementation:  ContactoServiceImplementation
    ) : ContactoRepository= ContactoRepository(contactoServiceImplementation)
}