package com.pmdm.login.ui.features.login.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.pmdm.login.ui.composables.CheckboxWithText
import com.pmdm.login.ui.composables.OutlinedTextFieldEmail
import com.pmdm.login.ui.composables.OutlinedTextFieldPassword
import com.pmdm.login.utilities.validacion.Validacion


@Composable
fun UsuarioPassword(
    modifier: Modifier,
    loginState: String,
    validacionLogin: Validacion,
    passwordState: String,
    validacionPassword: Validacion,
    recordarmeState: Boolean,
    onValueChangeLogin: (String) -> Unit,
    onValueChangePassword: (String) -> Unit,
    onCheckedChanged: (Boolean) -> Unit,
    onClickLogearse: () -> Unit
) {
    OutlinedTextFieldEmail(
        modifier = modifier,
        label = "Login",
        emailState = loginState,
        validacionState = validacionLogin,
        onValueChange = onValueChangeLogin
    )

    OutlinedTextFieldPassword(
        modifier = modifier,
        label = "Password",
        passwordState = passwordState,
        validacionState = validacionPassword,
        onValueChange = onValueChangePassword
    )

    CheckboxWithText(
        label = "Recordarme",
        checkedState = recordarmeState,
        onCheckedChange = onCheckedChanged
    )

    Button(
        onClick = onClickLogearse,
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Text("Login")
    }
}
