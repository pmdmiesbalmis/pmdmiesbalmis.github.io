package com.pmdm.login.ui.features

import android.content.res.Configuration
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.ScrollableState
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.pmdmiesbalmis.components.validacion.Validacion
import com.pmdm.login.R
import com.pmdm.login.ui.features.login.components.CircularImageFromResource
import com.pmdm.login.ui.features.login.components.TextNewAccount
import com.pmdm.login.ui.features.login.components.UsuarioPassword
import com.pmdm.login.ui.theme.LoginTheme
import com.pmdm.login.ui.theme.Purple40



@Composable

fun LoginScreen(
    loginState: String,
    passwordState: String,
    validacionLogin: Validacion,
    validacionPassword: Validacion,
    onLoginChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit
) {

    val contexto = LocalContext.current

    var recordarmeState by remember { mutableStateOf(false) }
    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(20.dp)
    ) {
        CircularImageFromResource(
            idImageResource = R.drawable.login, contentDescription = "Imagen Login"
        )

        UsuarioPassword(modifier = Modifier.fillMaxWidth(),
            loginState = loginState,
            passwordState = passwordState,
            validacionLogin = validacionLogin,
            validacionPassword = validacionPassword,
            recordarmeState = recordarmeState,
            onValueChangeLogin = { onLoginChanged(it) },
            onValueChangePassword = { onPasswordChanged(it) },
            onCheckedChanged = { recordarmeState = it },
            onClickLogearse = {
                val validaLogin = validaLogin(loginState)
                val validaPassword = validaPassword(passwordState)
                if (validaLogin.hayError)
                    Toast.makeText(contexto, validaLogin.mensajeError, Toast.LENGTH_LONG).show()
                else if (validaPassword.hayError)
                    Toast.makeText(contexto, validaPassword.mensajeError, Toast.LENGTH_LONG).show()
                else Toast.makeText(contexto, "Entrando a la APP", Toast.LENGTH_LONG).show()
            })
        Spacer(modifier = Modifier.fillMaxHeight(0.1f))
        Text(
            "Olvidaste Password?", fontSize = 15.sp, fontStyle = FontStyle.Italic, color = Purple40
        )
        Text("ó")
        Row(
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {

            Image(
                painter = painterResource(id = R.drawable.facebook),
                contentDescription = "Facebook",
                alignment = Alignment.Center,
                modifier = Modifier.size(35.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.gmail),
                contentDescription = "Gmail",
                alignment = Alignment.Center,
                modifier = Modifier
                    .size(36.dp)
                    .padding(3.dp)

            )
        }
        TextNewAccount(onClick = {
            Toast.makeText(contexto, "Nueva Cuenta", Toast.LENGTH_LONG).show()
        })
    }

}

private fun validaPassword(password: String): Validacion {
    var validacionPassword: Validacion
    if (password.isEmpty()) {
        validacionPassword = object : Validacion {
            override val hayError: Boolean
                get() = true
            override val mensajeError: String?
                get() = "El password no puede estar vacío"
        }
    } else if (password.length < 8) {
        validacionPassword = object : Validacion {
            override val hayError: Boolean
                get() = true
            override val mensajeError: String?
                get() = "El password debe tener como mínimo 8 caracteres"
        }
    } else {
        validacionPassword = object : Validacion {}
    }
    return validacionPassword
}

private fun validaLogin(login: String): Validacion {
    var validacionLogin: Validacion
    if (login.isEmpty()) {
        validacionLogin = object : Validacion {
            override val hayError: Boolean
                get() = true
            override val mensajeError: String?
                get() = "El login no puede estar vacío"
        }

    } else if ( !Regex("^[A-Za-z](.*)([@]{1})(.{1,})(\\.)(.{1,})$").matches(login)) {
        validacionLogin = object : Validacion {
            override val hayError: Boolean
                get() = true
            override val mensajeError: String?
                get() = "Correo no válido"
        }
    } else {
        validacionLogin = object : Validacion {}
    }
    return validacionLogin
}


@Preview(
    showBackground = true, device = "spec:parent=pixel_5,orientation=landscape",
    name = "LandScape"
)

@Preview(
    showBackground = true,
    device = "spec:parent=pixel_5",
    uiMode = Configuration.UI_MODE_NIGHT_YES or Configuration.UI_MODE_TYPE_NORMAL
)
@Composable
fun LoginText() {
    var loginState by remember { mutableStateOf("") }
    var validacionLogin by remember { mutableStateOf(object : Validacion {} as Validacion) }
    var passwordState by remember { mutableStateOf("") }
    var validacionPassword by remember { mutableStateOf(object : Validacion {} as Validacion) }

    LoginTheme {
        // A surface container using the 'background' color from the theme
        Surface(modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
                color = MaterialTheme.colorScheme.background) {

            LoginScreen(
                loginState = loginState,
                passwordState = passwordState,
                validacionLogin = validacionLogin,
                validacionPassword = validacionPassword,
                onLoginChanged = {
                    loginState = it
                    validacionLogin = validaLogin(it)
                },
                onPasswordChanged = {
                    passwordState = it
                    validacionPassword = validaPassword(it)
                }
            )

        }
    }

}