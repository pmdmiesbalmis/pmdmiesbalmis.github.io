package com.pmdm.gestorcolecciones.data


import com.pmdm.gestorcolecciones.data.mocks.PiezaDaoMock
import com.pmdm.gestorcolecciones.model.CategoriaColeccion
import com.pmdm.gestorcolecciones.model.Pieza

class PiezaRepository () {
    private val pieza: PiezaDaoMock = PiezaDaoMock()
    fun getPiezas(): List<Pieza> {
        return pieza.getTodos().map { it.aPieza() }
    }


    fun countPiezas(): Int {
        return pieza.count()
    }
}
