# Guía de Navegación y ViewModels en Jetpack Compose

Esta guía detalla el patrón de diseño estricto para la gestión de estado y navegación en la aplicación según los convenios del curso.

---

## 1. Reglas Fundamentales de Estado y ViewModel

1. **Uso Exclusivo de `mutableStateOf`**:
   * **NUNCA usar Kotlin Flows** (`StateFlow`, `SharedFlow`, `Flow`, `collectAsStateWithLifecycle`, etc.).
   * El estado se declara directamente en el `ViewModel` mediante propiedades mutables con getter público y setter privado:
     ```kotlin
     var miVariableState by mutableStateOf(valorInicial)
         private set
     ```
2. **Desacoplamiento Total Pantalla - ViewModel**:
   * **NUNCA pasar la instancia del `ViewModel` al Composable de la pantalla (`@Composable fun ...Screen`)**.
   * La pantalla debe recibir únicamente:
     - Las variables de estado descompuestas necesarias (`miVariableState: Tipo`).
     - Funciones lambda para eventos (`onEvent: (MiEvent) -> Unit` o callbacks específicos).
   * Esto garantiza la testeabilidad, reusabilidad y compatibilidad con `@Preview`.

---

## 2. Estructura Estándar de un ViewModel

```kotlin
package com.pmdm.<proyecto>.ui.features

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pmdm.<proyecto>.data.<Nombre>Repository
import com.pmdm.<proyecto>.model.<Entidad>
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class <Feature>ViewModel @Inject constructor(
    private val repository: <Nombre>Repository
) : ViewModel() {

    // 1. Estados de la UI (sufijo State y setter privado)
    var listaElementosState: List<<Entidad>> by mutableStateOf(emptyList())
        private set

    var elementoSeleccionadoState: <Entidad>? by mutableStateOf(null)
        private set

    var cargandoState: Boolean by mutableStateOf(false)
        private set

    // 2. Callbacks de navegación (lambdas vacías por defecto)
    var onNavegarVerDetalle: (() -> Unit) = { }
    var onNavegarCrearElemento: (() -> Unit) = { }
    var onNavegarConParametro: ((String) -> Unit) = { }

    init {
        onCargarDatos()
    }

    fun onCargarDatos() {
        viewModelScope.launch {
            cargandoState = true
            listaElementosState = repository.getTodos()
            cargandoState = false
        }
    }

    // 3. Procesador de eventos de UI
    fun on<Feature>Event(e: <Feature>Event) {
        when (e) {
            is <Feature>Event.OnSeleccionarElemento -> {
                elementoSeleccionadoState = listaElementosState.find { it.id == e.id }
            }
            is <Feature>Event.OnNavegarDetalleClick -> {
                onNavegarVerDetalle()
            }
            is <Feature>Event.OnBorrarClick -> {
                elementoSeleccionadoState?.let { item ->
                    viewModelScope.launch {
                        repository.delete(item.id)
                        elementoSeleccionadoState = null
                        onCargarDatos()
                    }
                }
            }
        }
    }
}
```

---

## 3. Definición de Eventos (`<Feature>Event.kt`)

Los eventos de UI se modelan como una `sealed interface`:

```kotlin
package com.pmdm.<proyecto>.ui.features

sealed interface <Feature>Event {
    data class OnSeleccionarElemento(val id: Int) : <Feature>Event
    object OnNavegarDetalleClick : <Feature>Event
    object OnBorrarClick : <Feature>Event
    data class OnFiltrarPorCategoria(val categoria: String) : <Feature>Event
}
```

---

## 4. Diseño del Composable de Pantalla (`<Feature>Screen.kt`)

```kotlin
package com.pmdm.<proyecto>.ui.features.<feature>

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.pmdm.<proyecto>.model.<Entidad>
import com.pmdm.<proyecto>.ui.features.<Feature>Event

@Composable
fun <Feature>Screen(
    listaElementosState: List<<Entidad>>,
    elementoSeleccionadoState: <Entidad>?,
    cargandoState: Boolean,
    on<Feature>Event: (<Feature>Event) -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = { /* TopBar */ }
    ) { innerPadding ->
        if (cargandoState) {
            CircularProgressIndicator()
        } else {
            // Contenido UI
        }
    }
}
```

---

## 5. Esquema de Navegación (Type-Safe con Compose Navigation 2.8+)

### 5.1 Definición de Rutas y Extensiones (`<Feature>Route.kt`)

Cada pantalla define su ruta serializable y una función de extensión sobre `NavGraphBuilder`:

```kotlin
package com.pmdm.<proyecto>.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.<proyecto>.ui.features.<Feature>ViewModel
import com.pmdm.<proyecto>.ui.features.<feature>.<Feature>Screen
import kotlinx.serialization.Serializable

@Serializable
object <Feature>Route

fun NavGraphBuilder.<feature>Destination(
    vm: <Feature>ViewModel
) {
    composable<<Feature>Route> {
        <Feature>Screen(
            listaElementosState = vm.listaElementosState,
            elementoSeleccionadoState = vm.elementoSeleccionadoState,
            cargandoState = vm.cargandoState,
            on<Feature>Event = vm::on<Feature>Event
        )
    }
}
```

Para pantallas con botón volver o navegación de retorno:

```kotlin
@Serializable
object DetalleRoute

fun NavGraphBuilder.detalleDestination(
    vm: <Feature>ViewModel,
    onVolverClick: () -> Unit
) {
    composable<DetalleRoute> {
        DetalleScreen(
            elementoState = vm.elementoSeleccionadoState!!,
            onVolverClick = onVolverClick,
            on<Feature>Event = vm::on<Feature>Event
        )
    }
}
```

### 5.2 NavHost Principal (`<NombreProyecto>NavHost.kt`)

El `NavHost` crea el `navController`, obtiene los ViewModels mediante `hiltViewModel<...>()`, conecta los callbacks de navegación y construye el grafo:

```kotlin
package com.pmdm.<proyecto>.ui.navigation

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import com.pmdm.<proyecto>.ui.features.<Feature>ViewModel

@Composable
fun <NombreProyecto>NavHost() {
    val navController = rememberNavController()
    val vm = hiltViewModel<<Feature>ViewModel>()

    // Conexión de callbacks de navegación del ViewModel con NavController
    vm.onNavegarVerDetalle = {
        navController.navigate(DetalleRoute)
    }
    vm.onNavegarCrearElemento = {
        navController.navigate(CrearRoute)
    }

    NavHost(
        navController = navController,
        startDestination = <Feature>Route
    ) {
        <feature>Destination(
            vm = vm
        )
        detalleDestination(
            vm = vm,
            onVolverClick = {
                navController.navigateUp()
            }
        )
    }
}
```
