package com.pmdm.gestorcolecciones.data.mocks

data class UsuarioMock(
    val id: Int,
    val correo: String,
    val nick: String,
    val contrasena: String,
    val recordarSesion: Boolean = true
)


