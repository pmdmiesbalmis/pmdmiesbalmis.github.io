package com.pmdm.gestorcolecciones.ui.theme

import androidx.compose.ui.graphics.Color

val GlacierPrimary = Color(0xFF006686)
val GlacierOnPrimary = Color(0xFFFFFFFF)
val GlacierPrimaryContainer = Color(0xFF7DD3FC)
val GlacierOnPrimaryContainer = Color(0xFF005B78)
val GlacierInversePrimary = Color(0xFF7BD1FA)

val GlacierSecondary = Color(0xFF376479)
val GlacierOnSecondary = Color(0xFFFFFFFF)
val GlacierSecondaryContainer = Color(0xFFBAE6FF)
val GlacierOnSecondaryContainer = Color(0xFF3C687E)

val GlacierTertiary = Color(0xFF724E97)
val GlacierOnTertiary = Color(0xFFFFFFFF)
val GlacierTertiaryContainer = Color(0xFFDDBAFF)
val GlacierOnTertiaryContainer = Color(0xFF66438B)

val GlacierBackground = Color(0xFFF9F9FF)
val GlacierOnBackground = Color(0xFF111B2F)
val GlacierSurface = Color(0xFFF9F9FF)
val GlacierOnSurface = Color(0xFF111B2F)
val GlacierSurfaceVariant = Color(0xFFD8E2FD)
val GlacierOnSurfaceVariant = Color(0xFF3F484E)

val GlacierSurfaceContainerLowest = Color(0xFFFFFFFF)
val GlacierSurfaceContainerLow = Color(0xFFF1F3FF)
val GlacierSurfaceContainer = Color(0xFFE9EDFF)
val GlacierSurfaceContainerHigh = Color(0xFFE0E8FF)
val GlacierSurfaceContainerHighest = Color(0xFFD8E2FD)

val GlacierOutline = Color(0xFF6F787E)
val GlacierOutlineVariant = Color(0xFFBEC8CE)

val GlacierError = Color(0xFFBA1A1A)
val GlacierOnError = Color(0xFFFFFFFF)
val GlacierErrorContainer = Color(0xFFFFDAD6)
val GlacierOnErrorContainer = Color(0xFF93000A)