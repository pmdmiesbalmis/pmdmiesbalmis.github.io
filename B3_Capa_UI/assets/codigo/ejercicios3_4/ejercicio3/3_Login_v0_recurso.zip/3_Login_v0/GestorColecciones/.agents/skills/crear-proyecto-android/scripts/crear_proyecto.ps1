<#
.SYNOPSIS
    Crea un nuevo proyecto Android a partir de la plantilla base proyectobase.zip
    configurando Room, repositorios, Hilt y precarga de base de datos desde mocks.

.PARAMETER Name
    Nombre del proyecto (e.g. MiRecetario, Tareas, etc.)

.PARAMETER TargetDir
    Directorio donde se creará el proyecto (por defecto el directorio actual)

.PARAMETER EntityName
    Nombre de la entidad base de Room (por defecto Elemento)

.PARAMETER ZipPath
    Ruta al archivo zip de la plantilla

.PARAMETER SyncGradle
    Si se especifica, ejecuta ./gradlew tasks para sincronizar el proyecto.
#>
param (
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$Name,

    [Parameter(Mandatory = $false)]
    [string]$TargetDir = ".",

    [Parameter(Mandatory = $false)]
    [string]$EntityName = "Elemento",

    [Parameter(Mandatory = $false)]
    [string]$ZipPath,

    [Parameter(Mandatory = $false)]
    [switch]$SyncGradle
)

$ErrorActionPreference = "Stop"

# Conversión a PascalCase y paquete en minúsculas
$splitWords = ($Name -creplace '([a-z0-9])([A-Z])', '$1 $2' -replace '[^a-zA-Z0-9]', ' ').Trim() -split '\s+'
if ($splitWords.Count -eq 0 -or [string]::IsNullOrWhiteSpace($splitWords[0])) {
    $pascalName = "MiProyecto"
    $pkgName = "miproyecto"
} else {
    $pascalName = ($splitWords | ForEach-Object { $_.Substring(0,1).ToUpper() + $_.Substring(1).ToLower() }) -join ""
    $pkgName = ($splitWords -join "").ToLower()
}

$entityWords = ($EntityName -creplace '([a-z0-9])([A-Z])', '$1 $2' -replace '[^a-zA-Z0-9]', ' ').Trim() -split '\s+'
if ($entityWords.Count -eq 0 -or [string]::IsNullOrWhiteSpace($entityWords[0])) {
    $entityPascal = "Elemento"
} else {
    $entityPascal = ($entityWords | ForEach-Object { $_.Substring(0,1).ToUpper() + $_.Substring(1).ToLower() }) -join ""
}
$entityVar = $entityPascal.Substring(0,1).ToLower() + $entityPascal.Substring(1)
$tableName = $entityVar.ToLower() + "s"

$newPackage = "com.pmdm.$pkgName"
$oldPackage = "com.pmdm.proyectobase2425"
$oldTheme = "ProyectoBase2425Theme"
$newTheme = "${pascalName}Theme"
$oldStyleTheme = "Theme.Proyectobase2425"
$newStyleTheme = "Theme.${pascalName}"

if (-not $ZipPath) {
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $ZipPath = Join-Path (Split-Path -Parent $scriptDir) "resources/proyectobase.zip"
}

if (-not (Test-Path $ZipPath)) {
    Write-Error "No se encuentra el archivo zip de la plantilla en $ZipPath"
    exit 1
}

$targetFullPath = [System.IO.Path]::GetFullPath($TargetDir)
if (-not (Test-Path $targetFullPath)) {
    New-Item -ItemType Directory -Path $targetFullPath -Force | Out-Null
}

Write-Host "=== Creando Proyecto Android ===" -ForegroundColor Cyan
Write-Host "Nombre del proyecto: $Name"
Write-Host "Nombre PascalCase: $pascalName"
Write-Host "Paquete: $newPackage"
Write-Host "Entidad Room: $entityPascal"
Write-Host "Destino: $targetFullPath"

# 1. Descomprimir plantilla
Expand-Archive -Path $ZipPath -DestinationPath $targetFullPath -Force

# 2. Renombrar directorios de paquetes
$sources = @(
    "app/src/main/java/com/pmdm",
    "app/src/androidTest/java/com/pmdm",
    "app/src/test/java/com/pmdm"
)

foreach ($rel in $sources) {
    $basePath = Join-Path $targetFullPath $rel
    $oldDir = Join-Path $basePath "proyectobase2425"
    $newDir = Join-Path $basePath $pkgName
    if (Test-Path $oldDir) {
        if (Test-Path $newDir) { Remove-Item $newDir -Recurse -Force }
        Rename-Item -Path $oldDir -NewName $pkgName -Force
    }
}

# 3. Modificar contenido de archivos
$textExts = @(".kt", ".kts", ".xml", ".properties", ".pro", ".gradle", ".gitignore")

Get-ChildItem -Path $targetFullPath -Recurse -File | Where-Object {
    $ext = $_.Extension
    $textExts -contains $ext -or $_.Name -eq "gradlew"
} | ForEach-Object {
    $content = [System.IO.File]::ReadAllText($_.FullName, [System.Text.Encoding]::UTF8)
    $modified = $content

    $modified = $modified.Replace($oldPackage, $newPackage)
    $modified = $modified.Replace("com.pmdm.plantillacurso2425", $newPackage)
    $modified = $modified.Replace($oldTheme, $newTheme)
    $modified = $modified.Replace($oldStyleTheme, $newStyleTheme)

    if ($_.Name -eq "settings.gradle.kts") {
        $modified = [regex]::Replace($modified, 'rootProject\.name\s*=\s*"[^"]*"', "rootProject.name = `"$pascalName`"")
    }

    if ($_.Name -eq "strings.xml") {
        $modified = [regex]::Replace($modified, '<string\s+name="app_name">[^<]*</string>', "<string name=`"app_name`">$Name</string>")
    }

    if ($_.Name -eq "build.gradle.kts" -and $_.Directory.Name -eq "app") {
        $modified = [regex]::Replace($modified, '//\s*alias\(libs\.plugins\.devtools\.ksp\)', '    alias(libs.plugins.devtools.ksp)')
        $modified = [regex]::Replace($modified, '//\s*alias\(libs\.plugins\.com\.google\.dagger\)', '    alias(libs.plugins.com.google.dagger)')
        $modified = [regex]::Replace($modified, '//\s*implementation\(libs\.dagger\.hilt\.android\)', '    implementation(libs.dagger.hilt.android)')
        $modified = [regex]::Replace($modified, '//\s*implementation\(libs\.androidx\.hilt\.navigation\.compose\)', '    implementation(libs.androidx.hilt.navigation.compose)')
        $modified = [regex]::Replace($modified, '//\s*ksp\(libs\.dagger\.hilt\.android\.compiler\)', '    ksp(libs.dagger.hilt.android.compiler)')
        $modified = [regex]::Replace($modified, '//\s*kspAndroidTest\(libs\.dagger\.hilt\.android\.compiler\)', '    kspAndroidTest(libs.dagger.hilt.android.compiler)')
        $modified = [regex]::Replace($modified, '//\s*implementation\(libs\.compose\.navigation\)', '    implementation(libs.compose.navigation)')
        $modified = [regex]::Replace($modified, '//\s*implementation\(libs\.kotlinx\.serializarion\.json\)', '    implementation(libs.kotlinx.serializarion.json)')
        $modified = [regex]::Replace($modified, '//\s*implementation\(libs\.androidx\.room\.ktx\)', '    implementation(libs.androidx.room.ktx)')
        $modified = [regex]::Replace($modified, '//\s*ksp\(libs\.androidx\.room\.compiler\)', '    ksp(libs.androidx.room.compiler)')
    }

    if ($_.Name -eq "AndroidManifest.xml") {
        $appAttr = "android:name=`".$pascalName`Application`""
        if (-not $modified.Contains($appAttr)) {
            $modified = [regex]::Replace($modified, '<application\b', "<application`n        $appAttr", 1)
        }
    }

    if ($_.Name -eq "MainActivity.kt") {
        if (-not $modified.Contains("@AndroidEntryPoint")) {
            $modified = [regex]::Replace($modified, '(package\s+[^\r\n]+[\r\n]+)', "`$1`nimport dagger.hilt.android.AndroidEntryPoint`n", 1)
            $modified = [regex]::Replace($modified, 'class\s+MainActivity\b', "@AndroidEntryPoint`nclass MainActivity", 1)
        }
    }

    if ($modified -ne $content) {
        [System.IO.File]::WriteAllText($_.FullName, $modified, [System.Text.Encoding]::UTF8)
    }
}

# 4. Generar arquitectura de Persistencia (Room, Repositorio, Mocks, Mappers, Application y DI)
$pkgDir = Join-Path $targetFullPath "app/src/main/java/com/pmdm/$pkgName"
$modelDir = Join-Path $pkgDir "model"
$dataDir = Join-Path $pkgDir "data"
$roomDir = Join-Path $dataDir "room"
$mocksDir = Join-Path $dataDir "mocks"
$diDir = Join-Path $pkgDir "di"

foreach ($d in @($modelDir, $roomDir, $mocksDir, $diDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

# 4.1 Application class
$appClassFile = Join-Path $pkgDir "${pascalName}Application.kt"
if (-not (Test-Path $appClassFile)) {
    @"
package com.pmdm.$pkgName

import android.app.Application
import com.pmdm.$pkgName.data.${pascalName}Repository
import com.pmdm.$pkgName.data.a$entityPascal
import com.pmdm.$pkgName.data.mocks.${entityPascal}DaoMock
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@HiltAndroidApp
class ${pascalName}Application : Application() {
    @Inject
    lateinit var daoMock: ${entityPascal}DaoMock

    @Inject
    lateinit var repository: ${pascalName}Repository

    override fun onCreate() {
        super.onCreate()

        // Precarga de la base de datos Room con datos de ejemplo si está vacía
        runBlocking {
            if (repository.count() == 0) {
                daoMock.getTodas().forEach { mockItem ->
                    repository.insert(mockItem.a$entityPascal())
                }
            }
        }
    }
}
"@ | Out-File -FilePath $appClassFile -Encoding utf8
}

# 4.2 Modelo de Dominio
$modelFile = Join-Path $modelDir "${entityPascal}.kt"
if (-not (Test-Path $modelFile)) {
    @"
package com.pmdm.$pkgName.model

data class $entityPascal(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val categoria: String,
    val destacado: Boolean = false
)
"@ | Out-File -FilePath $modelFile -Encoding utf8
}

# 4.3 Entidad Room
$entityFile = Join-Path $roomDir "${entityPascal}Entity.kt"
if (-not (Test-Path $entityFile)) {
    @"
package com.pmdm.$pkgName.data.room

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "$tableName")
data class ${entityPascal}Entity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Int,
    @ColumnInfo(name = "nombre")
    val nombre: String,
    @ColumnInfo(name = "descripcion")
    val descripcion: String,
    @ColumnInfo(name = "categoria")
    val categoria: String,
    @ColumnInfo(name = "destacado")
    val destacado: Boolean
)
"@ | Out-File -FilePath $entityFile -Encoding utf8
}

# 4.4 DAO Room
$daoFile = Join-Path $roomDir "${entityPascal}Dao.kt"
if (-not (Test-Path $daoFile)) {
    @"
package com.pmdm.$pkgName.data.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface ${entityPascal}Dao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(${entityVar}: ${entityPascal}Entity)

    @Update(onConflict = OnConflictStrategy.ABORT)
    suspend fun update(${entityVar}: ${entityPascal}Entity)

    @Query("DELETE FROM $tableName WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("SELECT COUNT(*) FROM $tableName")
    suspend fun count(): Int

    @Query("SELECT * FROM $tableName")
    suspend fun getTodas(): List<${entityPascal}Entity>

    @Query("SELECT * FROM $tableName WHERE id = :id")
    suspend fun getPorId(id: Int): ${entityPascal}Entity

    @Query("SELECT * FROM $tableName WHERE categoria = :categoria")
    suspend fun getPorCategoria(categoria: String): List<${entityPascal}Entity>

    @Query("SELECT * FROM $tableName WHERE destacado = 1")
    suspend fun getDestacados(): List<${entityPascal}Entity>

    @Query("SELECT DISTINCT categoria FROM $tableName ORDER BY categoria ASC")
    suspend fun getCategorias(): List<String>
}
"@ | Out-File -FilePath $daoFile -Encoding utf8
}

# 4.5 Room Database
$dbFile = Join-Path $roomDir "${pascalName}Db.kt"
if (-not (Test-Path $dbFile)) {
    @"
package com.pmdm.$pkgName.data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [${entityPascal}Entity::class],
    exportSchema = false,
    version = 1
)
abstract class ${pascalName}Db : RoomDatabase() {
    abstract fun ${entityVar}Dao(): ${entityPascal}Dao

    companion object {
        fun getDatabase(context: Context): ${pascalName}Db = Room.databaseBuilder(
            context,
            ${pascalName}Db::class.java,
            "$pkgName.db"
        )
            .allowMainThreadQueries()
            .fallbackToDestructiveMigration()
            .build()
    }
}
"@ | Out-File -FilePath $dbFile -Encoding utf8
}

# 4.6 Mock Entity
$mockModelFile = Join-Path $mocksDir "${entityPascal}Mock.kt"
if (-not (Test-Path $mockModelFile)) {
    @"
package com.pmdm.$pkgName.data.mocks

data class ${entityPascal}Mock(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val categoria: String,
    val destacado: Boolean = false
)
"@ | Out-File -FilePath $mockModelFile -Encoding utf8
}

# 4.7 Mock DAO
$mockDaoFile = Join-Path $mocksDir "${entityPascal}DaoMock.kt"
if (-not (Test-Path $mockDaoFile)) {
    @"
package com.pmdm.$pkgName.data.mocks

import kotlinx.coroutines.coroutineScope

class ${entityPascal}DaoMock {

    val ${entityVar}s: MutableList<${entityPascal}Mock> = mutableListOf(
        ${entityPascal}Mock(
            id = 1,
            nombre = "$entityPascal Ejemplo 1",
            descripcion = "Descripción detallada del primer $entityVar de prueba precargado.",
            categoria = "General",
            destacado = true
        ),
        ${entityPascal}Mock(
            id = 2,
            nombre = "$entityPascal Ejemplo 2",
            descripcion = "Descripción del segundo $entityVar de ejemplo con datos iniciales.",
            categoria = "General",
            destacado = false
        ),
        ${entityPascal}Mock(
            id = 3,
            nombre = "$entityPascal Especial 3",
            descripcion = "Tercer $entityVar de ejemplo para pruebas de listas y filtros.",
            categoria = "Especial",
            destacado = true
        )
    )

    suspend fun insert(${entityVar}: ${entityPascal}Mock) = coroutineScope {
        ${entityVar}s.add($entityVar)
    }

    suspend fun update(${entityVar}: ${entityPascal}Mock) = coroutineScope {
        val idx = ${entityVar}s.indexOfFirst { it.id == ${entityVar}.id }
        if (idx != -1) ${entityVar}s[idx] = $entityVar
    }

    suspend fun delete(id: Int) = coroutineScope {
        ${entityVar}s.removeIf { it.id == id }
    }

    suspend fun count(): Int = coroutineScope { ${entityVar}s.size }

    suspend fun getTodas(): List<${entityPascal}Mock> = coroutineScope { ${entityVar}s }

    suspend fun getPorId(id: Int): ${entityPascal}Mock = coroutineScope {
        ${entityVar}s.find { it.id == id } ?: throw NoSuchElementException("$entityPascal no encontrado")
    }

    suspend fun getPorCategoria(categoria: String): List<${entityPascal}Mock> = coroutineScope {
        ${entityVar}s.filter { it.categoria == categoria }
    }

    suspend fun getDestacados(): List<${entityPascal}Mock> = coroutineScope {
        ${entityVar}s.filter { it.destacado }
    }

    suspend fun getCategorias(): List<String> = coroutineScope {
        ${entityVar}s.map { it.categoria }.distinct().sorted()
    }
}
"@ | Out-File -FilePath $mockDaoFile -Encoding utf8
}

# 4.8 RepositoryConverter
$convFile = Join-Path $dataDir "RepositoryConverter.kt"
if (-not (Test-Path $convFile)) {
    @"
package com.pmdm.$pkgName.data

import com.pmdm.$pkgName.data.mocks.${entityPascal}Mock
import com.pmdm.$pkgName.data.room.${entityPascal}Entity
import com.pmdm.$pkgName.model.$entityPascal

fun ${entityPascal}Mock.a$entityPascal(): $entityPascal = $entityPascal(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    categoria = categoria,
    destacado = destacado
)

fun ${entityPascal}.a${entityPascal}Mock(): ${entityPascal}Mock = ${entityPascal}Mock(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    categoria = categoria,
    destacado = destacado
)

fun ${entityPascal}Entity.a$entityPascal(): $entityPascal = $entityPascal(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    categoria = categoria,
    destacado = destacado
)

fun ${entityPascal}.a${entityPascal}Entity(): ${entityPascal}Entity = ${entityPascal}Entity(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    categoria = categoria,
    destacado = destacado
)
"@ | Out-File -FilePath $convFile -Encoding utf8
}

# 4.9 Repositorio
$repoFile = Join-Path $dataDir "${pascalName}Repository.kt"
if (-not (Test-Path $repoFile)) {
    @"
package com.pmdm.$pkgName.data

import com.pmdm.$pkgName.data.room.${entityPascal}Dao
import com.pmdm.$pkgName.model.$entityPascal
import javax.inject.Inject

class ${pascalName}Repository @Inject constructor(
    private val dao: ${entityPascal}Dao
) {
    suspend fun insert(${entityVar}: $entityPascal) = dao.insert(${entityVar} = ${entityVar}.a${entityPascal}Entity())

    suspend fun update(${entityVar}: $entityPascal) = dao.update(${entityVar} = ${entityVar}.a${entityPascal}Entity())

    suspend fun delete(id: Int) = dao.delete(id)

    suspend fun count(): Int = dao.count()

    suspend fun getTodas(): List<$entityPascal> = dao.getTodas().map { it.a$entityPascal() }

    suspend fun getPorId(id: Int): $entityPascal = dao.getPorId(id).a$entityPascal()

    suspend fun getPorCategoria(categoria: String): List<$entityPascal> =
        dao.getPorCategoria(categoria).map { it.a$entityPascal() }

    suspend fun getDestacados(): List<$entityPascal> = dao.getDestacados().map { it.a$entityPascal() }

    suspend fun getCategorias(): List<String> = dao.getCategorias()
}
"@ | Out-File -FilePath $repoFile -Encoding utf8
}

# 4.10 Módulo Hilt
$modFile = Join-Path $diDir "ModuleApp.kt"
if (-not (Test-Path $modFile)) {
    @"
package com.pmdm.$pkgName.di

import android.content.Context
import com.pmdm.$pkgName.data.${pascalName}Repository
import com.pmdm.$pkgName.data.mocks.${entityPascal}DaoMock
import com.pmdm.$pkgName.data.room.${entityPascal}Dao
import com.pmdm.$pkgName.data.room.${pascalName}Db
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class ModuleApp {

    @Provides
    @Singleton
    fun provide${entityPascal}DaoMock(): ${entityPascal}DaoMock = ${entityPascal}DaoMock()

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context
    ): ${pascalName}Db = ${pascalName}Db.getDatabase(context)

    @Provides
    @Singleton
    fun provide${entityPascal}Dao(
        db: ${pascalName}Db
    ): ${entityPascal}Dao = db.${entityVar}Dao()

    @Provides
    @Singleton
    fun provideRepository(
        dao: ${entityPascal}Dao
    ): ${pascalName}Repository = ${pascalName}Repository(dao)
}
"@ | Out-File -FilePath $modFile -Encoding utf8
}

Write-Host "Proyecto configurado con éxito con Room, Repositorio y Mocks de precarga." -ForegroundColor Green

if ($SyncGradle) {
    $gradlew = Join-Path $targetFullPath "gradlew.bat"
    if (Test-Path $gradlew) {
        Write-Host "Sincronizando Gradle..." -ForegroundColor Cyan
        & $gradlew tasks --no-daemon
    }
}
