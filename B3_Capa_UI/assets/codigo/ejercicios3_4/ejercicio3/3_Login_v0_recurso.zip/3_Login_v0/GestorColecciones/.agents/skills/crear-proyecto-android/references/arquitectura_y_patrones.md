# Guía de Arquitectura y Patrones Android (PMDM)

Esta guía define la arquitectura estándar para los proyectos Android según los patrones y convenios de `@ejemplo_app_android`.

---

## 1. Estructura de Paquetes y Capas

Todo proyecto sigue una arquitectura en capas limpia, desacoplada y orientada a características (*feature-first* en la capa UI):

```text
com.pmdm.<nombre_proyecto>/
├── <NombreProyecto>Application.kt     # Clase Application anotada con @HiltAndroidApp
├── data/                              # Capa de Datos (Repositorios, Room, Mocks, Mappers)
│   ├── <Nombre>Repository.kt          # Repositorio (fuente única de verdad)
│   ├── RepositoryConverter.kt         # Conversores y mappers entre capas (Entity <-> Model <-> Mock)
│   ├── mocks/                         # Fuentes de datos simuladas para pruebas/desarrollo
│   │   ├── <Entidad>Mock.kt
│   │   └── <Entidad>DaoMock.kt
│   └── room/                          # Persistencia local con Room
│       ├── <Entidad>Entity.kt         # @Entity(tableName = "...")
│       ├── <Entidad>Dao.kt            # @Dao con operaciones suspend (@Query, @Insert, etc.)
│       └── <Nombre>Db.kt              # @Database(...) abstract class ...Db : RoomDatabase()
├── di/                                # Inyección de Dependencias (Hilt)
│   └── ModuleApp.kt                   # Módulo @Module @InstallIn(SingletonComponent::class)
├── model/                             # Modelos de Dominio puros (Data classes de Kotlin)
│   └── <Entidad>.kt
└── ui/                                # Capa de Presentación (Jetpack Compose)
    ├── features/                      # Pantallas organizadas por funcionalidad
    │   ├── <feature_name>/
    │   │   ├── <Feature>Screen.kt     # Composable principal de la pantalla
    │   │   └── <Item/Dialog>.kt       # Componentes y diálogos específicos de la pantalla
    │   ├── <Feature>Event.kt          # Sealed interface para eventos de usuario
    │   └── <Feature>ViewModel.kt      # ViewModel con mutableStateOf y callbacks de navegación
    ├── navigation/                    # Rutas seguras y NavHost
    │   ├── <Feature>Route.kt          # @Serializable object/data class y función de extensión NavGraphBuilder
    │   └── <Nombre>NavHost.kt         # NavHost que enlaza ViewModel y NavController
    ├── theme/                         # Sistema de diseño Material 3
    │   ├── Color.kt
    │   ├── Theme.kt                   # <NombreProyecto>Theme
    │   └── Type.kt
    └── views/                         # Actividades principales
        └── MainActivity.kt            # @AndroidEntryPoint ComponentActivity
```

---

## 2. Inyección de Dependencias (Hilt)

### 2.1 Configuración de la Aplicación y Precarga de Datos
```kotlin
package com.pmdm.<proyecto>

import android.app.Application
import com.pmdm.<proyecto>.data.<NombreProyecto>Repository
import com.pmdm.<proyecto>.data.aModelo
import com.pmdm.<proyecto>.data.mocks.<Entidad>DaoMock
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@HiltAndroidApp
class <NombreProyecto>Application : Application() {
    @Inject
    lateinit var daoMock: <Entidad>DaoMock

    @Inject
    lateinit var repository: <NombreProyecto>Repository

    override fun onCreate() {
        super.onCreate()

        // Precarga de la base de datos Room con datos de ejemplo si está vacía
        runBlocking {
            if (repository.count() == 0) {
                daoMock.getTodas().forEach { itemMock ->
                    repository.insert(item = itemMock.aModelo())
                }
            }
        }
    }
}
```

### 2.2 Módulo de Dependencias (`ModuleApp.kt`)
```kotlin
package com.pmdm.<proyecto>.di

import android.content.Context
import com.pmdm.<proyecto>.data.<NombreProyecto>Repository
import com.pmdm.<proyecto>.data.mocks.<Entidad>DaoMock
import com.pmdm.<proyecto>.data.room.<Entidad>Dao
import com.pmdm.<proyecto>.data.room.<NombreProyecto>Db
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class ModuleApp {

    @Provides
    @Singleton
    fun provide<Entidad>DaoMock(): <Entidad>DaoMock = <Entidad>DaoMock()

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): <NombreProyecto>Db =
        <NombreProyecto>Db.getDatabase(context)

    @Provides
    @Singleton
    fun provide<Entidad>Dao(db: <NombreProyecto>Db): <Entidad>Dao = db.<entidad>Dao()

    @Provides
    @Singleton
    fun provideRepository(dao: <Entidad>Dao): <NombreProyecto>Repository =
        <NombreProyecto>Repository(dao)
}
```

---

## 3. Capa de Datos, Persistencia Room y Mappers

Para una guía exhaustiva y completa de persistencia, consulta [Guía de Persistencia: Room, Repositorios y Precarga](./persistencia_room_y_repositorio.md).

### 3.1 Reglas Críticas de Persistencia
* **Room Obligatorio**: Toda persistencia relacional local debe implementarse con Room (`@Database`, `@Dao`, `@Entity`).
* **PROHIBICIÓN ESTRICTA**: Está **terminantemente prohibido** el uso de `SharedPreferences` y Jetpack `DataStore` (Preferences / Proto).
* **Precarga Automática con Mocks**: El proyecto debe incluir datos iniciales cargados desde `<Entidad>DaoMock` en `Application.onCreate()`, garantizando datos disponibles inmediatamente al ejecutar la app.

### 3.2 Repositorio (`<Nombre>Repository.kt`)
* Los repositorios son clases anotadas con `@Inject constructor(private val dao: <Entidad>Dao)`.
* Exponen funciones `suspend` limpias que devuelven los modelos de dominio (`model.<Entidad>`).
* Ocultan los detalles de Room, Retrofit o Mocks.

```kotlin
package com.pmdm.<proyecto>.data

import com.pmdm.<proyecto>.data.room.<Entidad>Dao
import com.pmdm.<proyecto>.model.<Entidad>
import javax.inject.Inject

class <NombreProyecto>Repository @Inject constructor(
    private val dao: <Entidad>Dao
) {
    suspend fun insert(item: <Entidad>) = dao.insert(item.aEntity())
    suspend fun update(item: <Entidad>) = dao.update(item.aEntity())
    suspend fun delete(id: Int) = dao.delete(id)
    suspend fun count(): Int = dao.count()
    suspend fun getTodos(): List<<Entidad>> = dao.getTodos().map { it.aModelo() }
    suspend fun getPorId(id: Int): <Entidad> = dao.getPorId(id).aModelo()
}
```

### 3.3 Conversores (`RepositoryConverter.kt`)
Funciones de extensión claras para mapear entre capas sin acoplamiento:

```kotlin
package com.pmdm.<proyecto>.data

import com.pmdm.<proyecto>.data.mocks.<Entidad>Mock
import com.pmdm.<proyecto>.data.room.<Entidad>Entity
import com.pmdm.<proyecto>.model.<Entidad>

fun <Entidad>Entity.aModelo(): <Entidad> = <Entidad>(
    id = id,
    nombre = nombre
)

fun <Entidad>.aEntity(): <Entidad>Entity = <Entidad>Entity(
    id = id,
    nombre = nombre
)

fun <Entidad>Mock.aModelo(): <Entidad> = <Entidad>(
    id = id,
    nombre = nombre
)

fun <Entidad>.aMock(): <Entidad>Mock = <Entidad>Mock(
    id = id,
    nombre = nombre
)
```

### 3.4 Configuración de Base de Datos Room (`<NombreProyecto>Db.kt`)
```kotlin
package com.pmdm.<proyecto>.data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [<Entidad>Entity::class],
    exportSchema = false,
    version = 1
)
abstract class <NombreProyecto>Db : RoomDatabase() {
    abstract fun <entidad>Dao(): <Entidad>Dao

    companion object {
        fun getDatabase(context: Context): <NombreProyecto>Db = Room.databaseBuilder(
            context,
            <NombreProyecto>Db::class.java,
            "<nombre_proyecto>.db"
        )
            .allowMainThreadQueries()
            .fallbackToDestructiveMigration()
            .build()
    }
}
```

