package com.pmdm.gestorcolecciones

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.pmdm.gestorcolecciones.data.UsuarioRepository
import com.pmdm.gestorcolecciones.data.mocks.UsuarioDaoMock
import com.pmdm.gestorcolecciones.model.Usuario
import com.pmdm.gestorcolecciones.ui.features.login.LoginEvent
import com.pmdm.gestorcolecciones.ui.features.login.LoginScreen
import com.pmdm.gestorcolecciones.ui.features.login.LoginUiState
import com.pmdm.gestorcolecciones.ui.features.login.ValidadorLogin
import com.pmdm.gestorcolecciones.ui.features.registro.RegistroEvent
import com.pmdm.gestorcolecciones.ui.features.registro.RegistroScreen
import com.pmdm.gestorcolecciones.ui.features.registro.RegistroUiState
import com.pmdm.gestorcolecciones.ui.features.registro.ValidadorRegistro
import com.pmdm.gestorcolecciones.ui.theme.GestorColeccionesTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GestorColeccionesTheme {
                val validadorRegistro = remember { ValidadorRegistro() }
                var registroUiState by remember { mutableStateOf(RegistroUiState()) }
                val validadorLogin = remember { ValidadorLogin() }
                var loginUiState by remember { mutableStateOf(LoginUiState()) }
                LoginScreen(
                    modifier = Modifier.fillMaxSize(),
                    uiState = loginUiState,
                    onLoginEvent = { evento ->
                        when (evento) {
                            is LoginEvent.OnCorreoCambiado -> {
                                val validacionCorreo =
                                    validadorLogin.validadorCorreo.valida(evento.correo)
                                loginUiState = loginUiState.copy(
                                    correo = evento.correo,
                                    mensajeError = null,
                                    validacion = loginUiState.validacion.copy(validacionCorreo = validacionCorreo)
                                )
                            }

                            is LoginEvent.OnContrasenaCambiado -> {
                                val validacionContrasena =
                                    validadorLogin.validadorContrasena.valida(evento.contrasena)
                                loginUiState = loginUiState.copy(
                                    contrasena = evento.contrasena,
                                    mensajeError = null,
                                    validacion = loginUiState.validacion.copy(validacionContrasena = validacionContrasena)
                                )
                            }
                        }
                    }
                )
        /*        RegistroScreen(
                    modifier = Modifier.fillMaxSize(),
                    uiState = registroUiState,
                    onRegistroEvent = { evento ->
                        when (evento) {
                            is RegistroEvent.OnCorreoCambiado -> {
                                val validacionCorreo =
                                    validadorRegistro.validadorCorreo.valida(evento.correo)
                                registroUiState = registroUiState.copy(
                                    correo = evento.correo,
                                    mensajeError = null,
                                    acreditadoConExito = false,
                                    validacion = registroUiState.validacion.copy(validacionCorreo = validacionCorreo)
                                )
                            }

                            is RegistroEvent.OnNickCambiado -> {
                                val validacionNick = validadorRegistro.validarNick(evento.nick)
                                registroUiState = registroUiState.copy(
                                    nick = evento.nick,
                                    mensajeError = null,
                                    acreditadoConExito = false,
                                    validacion = registroUiState.validacion.copy(validacionNick = validacionNick)
                                )
                            }

                            is RegistroEvent.OnContrasenaCambiado -> {
                                val validacionContrasena =
                                    validadorRegistro.validadorContrasena.valida(evento.contrasena)
                                val validacionConfirmar =
                                    validadorRegistro.validarConfirmarContrasena(
                                        evento.contrasena,
                                        registroUiState.confirmarContrasena
                                    )
                                registroUiState = registroUiState.copy(
                                    contrasena = evento.contrasena,
                                    mensajeError = null,
                                    acreditadoConExito = false,
                                    validacion = registroUiState.validacion.copy(
                                        validacionContrasena = validacionContrasena,
                                        validacionConfirmarContrasena = validacionConfirmar
                                    )
                                )
                            }

                            is RegistroEvent.OnConfirmarContrasenaCambiado -> {
                                val validacionConfirmar =
                                    validadorRegistro.validarConfirmarContrasena(
                                        registroUiState.contrasena,
                                        evento.confirmar
                                    )
                                registroUiState = registroUiState.copy(
                                    confirmarContrasena = evento.confirmar,
                                    mensajeError = null,
                                    acreditadoConExito = false,
                                    validacion = registroUiState.validacion.copy(
                                        validacionConfirmarContrasena = validacionConfirmar
                                    )
                                )
                            }
                        }
                    })*/
            }
        }
    }
}