package com.pmdm.gestorcolecciones.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val GlacierLightColorScheme = lightColorScheme(
    primary = GlacierPrimary,
    onPrimary = GlacierOnPrimary,
    primaryContainer = GlacierPrimaryContainer,
    onPrimaryContainer = GlacierOnPrimaryContainer,
    inversePrimary = GlacierInversePrimary,
    secondary = GlacierSecondary,
    onSecondary = GlacierOnSecondary,
    secondaryContainer = GlacierSecondaryContainer,
    onSecondaryContainer = GlacierOnSecondaryContainer,
    tertiary = GlacierTertiary,
    onTertiary = GlacierOnTertiary,
    tertiaryContainer = GlacierTertiaryContainer,
    onTertiaryContainer = GlacierOnTertiaryContainer,
    background = GlacierBackground,
    onBackground = GlacierOnBackground,
    surface = GlacierSurface,
    onSurface = GlacierOnSurface,
    surfaceVariant = GlacierSurfaceVariant,
    onSurfaceVariant = GlacierOnSurfaceVariant,
    surfaceContainerLowest = GlacierSurfaceContainerLowest,
    surfaceContainerLow = GlacierSurfaceContainerLow,
    surfaceContainer = GlacierSurfaceContainer,
    surfaceContainerHigh = GlacierSurfaceContainerHigh,
    surfaceContainerHighest = GlacierSurfaceContainerHighest,
    outline = GlacierOutline,
    outlineVariant = GlacierOutlineVariant,
    error = GlacierError,
    onError = GlacierOnError,
    errorContainer = GlacierErrorContainer,
    onErrorContainer = GlacierOnErrorContainer
)

private val GlacierDarkColorScheme = darkColorScheme(
    primary = GlacierPrimaryContainer,
    onPrimary = GlacierOnPrimaryContainer,
    primaryContainer = GlacierPrimary,
    onPrimaryContainer = GlacierOnPrimary,
    inversePrimary = GlacierPrimary,
    secondary = GlacierSecondaryContainer,
    onSecondary = GlacierOnSecondaryContainer,
    secondaryContainer = GlacierSecondary,
    onSecondaryContainer = GlacierOnSecondary,
    tertiary = GlacierTertiaryContainer,
    onTertiary = GlacierOnTertiaryContainer,
    tertiaryContainer = GlacierTertiary,
    onTertiaryContainer = GlacierOnTertiary,
    background = GlacierOnBackground,
    onBackground = GlacierBackground,
    surface = GlacierOnBackground,
    onSurface = GlacierSurface,
    surfaceVariant = GlacierOnSurfaceVariant,
    onSurfaceVariant = GlacierSurfaceVariant,
    outline = GlacierOutlineVariant,
    outlineVariant = GlacierOutline,
    error = GlacierErrorContainer,
    onError = GlacierOnErrorContainer,
    errorContainer = GlacierError,
    onErrorContainer = GlacierOnError
)

@Composable
fun GestorColeccionesTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> GlacierDarkColorScheme
        else -> GlacierLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}