# Guía de Persistencia de Datos: Room, Repositorios y Mocks de Precarga

Esta guía detalla la implementación obligatoria de persistencia local en los proyectos Android de PMDM, basada estrictamente en los patrones y arquitectura de `@ejemplo_app_android`.

---

## 1. Reglas Fundamentales de Persistencia

1. **Uso Exclusivo de Room**:
   * Toda persistencia relacional y almacenamiento local de datos debe realizarse mediante **Room Database**.
   * No se permite el acceso directo a bases de datos SQLite nativas sin el ORM Room.
2. **Prohibición Estricta de SharedPreferences y DataStore**:
   * Está **ESTRICTAMENTE PROHIBIDO** usar `SharedPreferences` o Jetpack `DataStore` (tanto `Preferences DataStore` como `Proto DataStore`).
   * Cualquier dato que requiera persistencia (configuraciones, listas, estados de entidades, favoritos, etc.) debe almacenarse en tablas de Room gestionadas a través del repositorio.
3. **Capa de Repositorio como Fuente Única de Verdad**:
   * Las pantallas composables y los ViewModels **NUNCA** acceden directamente al DAO ni a Room.
   * Toda operación de datos pasa a través de la clase `<Proyecto>Repository`, inyectada mediante Hilt.
4. **Mock de Precarga de la Base de Datos al Arrancar**:
   * Para garantizar que el usuario o evaluador disponga de datos de ejemplo inmediatamente al iniciar la app, se debe implementar una precarga automática en `<Proyecto>Application.onCreate()`.
   * Se utiliza un `DaoMock` precargado con datos iniciales realistas que se insertan en Room si la base de datos está vacía (`repository.count() == 0`).

---

## 2. Dependencias en Gradle (`app/build.gradle.kts`)

Asegúrate de que los plugins y librerías de Room, KSP y Hilt están activos en `app/build.gradle.kts`:

```kotlin
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.devtools.ksp)
    alias(libs.plugins.com.google.dagger)
    alias(libs.plugins.kotlinx.serialization)
    id("kotlin-parcelize")
}

dependencies {
    // Inyección de dependencias con Hilt
    implementation(libs.dagger.hilt.android)
    implementation(libs.androidx.hilt.navigation.compose)
    ksp(libs.dagger.hilt.android.compiler)
    kspAndroidTest(libs.dagger.hilt.android.compiler)

    // Persistencia local con Room
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // Navegación y serialización
    implementation(libs.compose.navigation)
    implementation(libs.kotlinx.serializarion.json)
}
```

---

## 3. Estructura de la Capa de Persistencia

```text
com.pmdm.<proyecto>/
├── <Proyecto>Application.kt           # @HiltAndroidApp con precarga en onCreate()
├── data/
│   ├── <Proyecto>Repository.kt        # Repositorio (métodos suspend y fuente de verdad)
│   ├── RepositoryConverter.kt         # Extension functions para conversión (Entity <-> Model <-> Mock)
│   ├── mocks/
│   │   ├── <Entidad>Mock.kt           # Data class del mock
│   │   └── <Entidad>DaoMock.kt        # Mock en memoria con lista inicializada de datos de ejemplo
│   └── room/
│       ├── <Entidad>Entity.kt         # @Entity(tableName = "...")
│       ├── <Entidad>Dao.kt            # @Dao con consultas Room (@Insert, @Update, @Query)
│       └── <Proyecto>Db.kt            # @Database abstract class ...Db : RoomDatabase()
├── di/
│   └── ModuleApp.kt                   # Proveedor Hilt de Database, DAOs, DaoMock y Repositorio
└── model/
    └── <Entidad>.kt                   # Modelo de dominio puro de Kotlin
```

---

## 4. Implementación Detallada Componente a Componente

### 4.1 Modelo de Dominio (`model/<Entidad>.kt`)
Data class inmutable que representa la entidad en las capas superiores (UI, ViewModel):

```kotlin
package com.pmdm.<proyecto>.model

data class Receta(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val chef: String,
    val foto: String?,
    val favorita: Boolean = false
)
```

### 4.2 Entidad de Room (`data/room/<Entidad>Entity.kt`)
Anotada con `@Entity(tableName = "...")` y `@PrimaryKey`:

```kotlin
package com.pmdm.<proyecto>.data.room

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recetas")
data class RecetaEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Int,
    @ColumnInfo(name = "nombre")
    val nombre: String,
    @ColumnInfo(name = "descripcion")
    val descripcion: String,
    @ColumnInfo(name = "chef")
    val chef: String,
    @ColumnInfo(name = "foto")
    val foto: String?,
    @ColumnInfo(name = "favorita")
    val favorita: Boolean
)
```

### 4.3 DAO de Room (`data/room/<Entidad>Dao.kt`)
Define las operaciones sobre SQLite mediante funciones `suspend`:

```kotlin
package com.pmdm.<proyecto>.data.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface RecetaDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(receta: RecetaEntity)

    @Update(onConflict = OnConflictStrategy.ABORT)
    suspend fun update(receta: RecetaEntity)

    @Query("DELETE FROM recetas WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("SELECT COUNT(*) FROM recetas")
    suspend fun count(): Int

    @Query("SELECT * FROM recetas")
    suspend fun getTodas(): List<RecetaEntity>

    @Query("SELECT * FROM recetas WHERE id = :id")
    suspend fun getReceta(id: Int): RecetaEntity

    @Query("SELECT * FROM recetas WHERE chef = :chef")
    suspend fun getRecetasPorChef(chef: String): List<RecetaEntity>

    @Query("SELECT * FROM recetas WHERE favorita = 1")
    suspend fun getRecetasFavoritas(): List<RecetaEntity>

    @Query("SELECT DISTINCT chef FROM recetas ORDER BY chef ASC")
    suspend fun getChefs(): List<String>
}
```

### 4.4 Base de Datos Room (`data/room/<Proyecto>Db.kt`)
Configuración singleton con `fallbackToDestructiveMigration()` y `allowMainThreadQueries()`:

```kotlin
package com.pmdm.<proyecto>.data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [RecetaEntity::class],
    exportSchema = false,
    version = 1
)
abstract class RecetarioDb : RoomDatabase() {
    abstract fun recetaDao(): RecetaDao

    companion object {
        fun getDatabase(context: Context): RecetarioDb = Room.databaseBuilder(
            context,
            RecetarioDb::class.java,
            "recetario.db"
        )
            .allowMainThreadQueries()
            .fallbackToDestructiveMigration()
            .build()
    }
}
```

### 4.5 Mocks para Precarga (`data/mocks/`)

#### `<Entidad>Mock.kt`
```kotlin
package com.pmdm.<proyecto>.data.mocks

data class RecetaMock(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val chef: String,
    val foto: String?,
    val favorita: Boolean = false
)
```

#### `<Entidad>DaoMock.kt`
Contiene una lista mutable en memoria preinicializada con elementos representativos y métodos `suspend`:

```kotlin
package com.pmdm.<proyecto>.data.mocks

import kotlinx.coroutines.coroutineScope

class RecetaDaoMock {

    val recetas: MutableList<RecetaMock> = mutableListOf(
        RecetaMock(
            id = 1,
            nombre = "Merluza a la Koxkera",
            descripcion = "Tradicional plato vasco en salsa verde con almejas y guisantes.",
            chef = "Carlos Arguiñano",
            foto = "http://10.0.2.2/recetas/1.jpg"
        ),
        RecetaMock(
            id = 2,
            nombre = "Pollo al Ajillo con Patatas",
            descripcion = "Receta clásica con mucho ajo, vino blanco y hierbas aromáticas.",
            chef = "Carlos Arguiñano",
            foto = "http://10.0.2.2/recetas/2.jpg",
            favorita = true
        ),
        RecetaMock(
            id = 3,
            nombre = "Risotto de Setas Porcini",
            descripcion = "Arroz cremoso con setas porcini, caldo de verduras y parmesano.",
            chef = "Massimo Bottura",
            foto = "http://10.0.2.2/recetas/3.jpg"
        )
    )

    suspend fun insert(receta: RecetaMock) = coroutineScope { recetas.add(receta) }
    suspend fun update(receta: RecetaMock) = coroutineScope {
        val idx = recetas.indexOfFirst { it.id == receta.id }
        if (idx != -1) recetas[idx] = receta
    }
    suspend fun delete(id: Int) = coroutineScope { recetas.removeIf { it.id == id } }
    suspend fun count(): Int = coroutineScope { recetas.size }
    suspend fun getTodas(): List<RecetaMock> = coroutineScope { recetas }
    suspend fun getReceta(id: Int): RecetaMock = coroutineScope {
        recetas.find { it.id == id } ?: throw NoSuchElementException("Elemento no encontrado")
    }
}
```

### 4.6 Conversores de Capa (`data/RepositoryConverter.kt`)
Funciones de extensión puras de Kotlin para mapear bidireccionalmente entre Model, Entity y Mock:

```kotlin
package com.pmdm.<proyecto>.data

import com.pmdm.<proyecto>.data.mocks.RecetaMock
import com.pmdm.<proyecto>.data.room.RecetaEntity
import com.pmdm.<proyecto>.model.Receta

fun RecetaMock.aReceta(): Receta = Receta(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    chef = chef,
    foto = foto,
    favorita = favorita
)

fun Receta.aRecetaMock(): RecetaMock = RecetaMock(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    chef = chef,
    foto = foto,
    favorita = favorita
)

fun RecetaEntity.aReceta(): Receta = Receta(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    chef = chef,
    foto = foto,
    favorita = favorita
)

fun Receta.aRecetaEntity(): RecetaEntity = RecetaEntity(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    chef = chef,
    foto = foto,
    favorita = favorita
)
```

### 4.7 Repositorio (`data/<Proyecto>Repository.kt`)
Encapsula el DAO y expone únicamente modelos de dominio:

```kotlin
package com.pmdm.<proyecto>.data

import com.pmdm.<proyecto>.data.room.RecetaDao
import com.pmdm.<proyecto>.model.Receta
import javax.inject.Inject

class RecetarioRepository @Inject constructor(
    private val dao: RecetaDao
) {
    suspend fun insert(receta: Receta) = dao.insert(receta = receta.aRecetaEntity())

    suspend fun update(receta: Receta) = dao.update(receta = receta.aRecetaEntity())

    suspend fun delete(id: Int) = dao.delete(id)

    suspend fun count(): Int = dao.count()

    suspend fun getTodas(): List<Receta> = dao.getTodas().map { it.aReceta() }

    suspend fun getPorId(id: Int): Receta = dao.getReceta(id).aReceta()

    suspend fun getPorChef(chef: String): List<Receta> =
        dao.getRecetasPorChef(chef).map { it.aReceta() }

    suspend fun getFavoritas(): List<Receta> = dao.getRecetasFavoritas().map { it.aReceta() }

    suspend fun getChefs(): List<String> = dao.getChefs()
}
```

### 4.8 Módulo Hilt (`di/ModuleApp.kt`)
Provee las instancias singleton para inyección de dependencias:

```kotlin
package com.pmdm.<proyecto>.di

import android.content.Context
import com.pmdm.<proyecto>.data.RecetarioRepository
import com.pmdm.<proyecto>.data.mocks.RecetaDaoMock
import com.pmdm.<proyecto>.data.room.RecetaDao
import com.pmdm.<proyecto>.data.room.RecetarioDb
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class ModuleApp {

    @Provides
    @Singleton
    fun provideRecetaDaoMock(): RecetaDaoMock = RecetaDaoMock()

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context
    ): RecetarioDb = RecetarioDb.getDatabase(context)

    @Provides
    @Singleton
    fun provideRecetaDao(
        db: RecetarioDb
    ): RecetaDao = db.recetaDao()

    @Provides
    @Singleton
    fun provideRepository(
        dao: RecetaDao
    ): RecetarioRepository = RecetarioRepository(dao)
}
```

### 4.9 Precarga en Application (`<Proyecto>Application.kt`)
La clase de aplicación (`@HiltAndroidApp`) comprueba al arrancar si Room no tiene datos y precarga el contenido del mock:

```kotlin
package com.pmdm.<proyecto>

import android.app.Application
import com.pmdm.<proyecto>.data.RecetarioRepository
import com.pmdm.<proyecto>.data.aReceta
import com.pmdm.<proyecto>.data.mocks.RecetaDaoMock
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@HiltAndroidApp
class RecetarioApplication : Application() {
    @Inject
    lateinit var daoMock: RecetaDaoMock

    @Inject
    lateinit var repository: RecetarioRepository

    override fun onCreate() {
        super.onCreate()

        // Precarga de la base de datos Room con datos iniciales si está vacía
        runBlocking {
            if (repository.count() == 0) {
                daoMock.getTodas().forEach { itemMock ->
                    repository.insert(receta = itemMock.aReceta())
                }
            }
        }
    }
}
```

En `app/src/main/AndroidManifest.xml`:
```xml
<application
    android:name=".RecetarioApplication"
    android:allowBackup="true"
    ... >
    <activity
        android:name=".ui.views.MainActivity"
        android:exported="true">
        ...
    </activity>
</application>
```

---

## 5. Resumen de Buenas Prácticas

| Requisito | Cumplimiento |
| :--- | :--- |
| **Persistencia** | **Room exclusiva**; prohibido `SharedPreferences` y `DataStore`. |
| **Mapeo** | Uso de funciones de extensión `aModelo()`, `aEntity()`, `aMock()` en `RepositoryConverter.kt`. |
| **Repositorio** | Clase inyectable `@Inject constructor(dao: ...Dao)` con operaciones `suspend`. |
| **Hilt** | `@HiltAndroidApp` en Application, `@AndroidEntryPoint` en MainActivity, `@HiltViewModel` en ViewModel. |
| **Precarga** | `runBlocking { if (repository.count() == 0) ... }` en `Application.onCreate()`. |
| **Estados UI** | Inmutables hacia afuera con `mutableStateOf` (nunca Flows). |
