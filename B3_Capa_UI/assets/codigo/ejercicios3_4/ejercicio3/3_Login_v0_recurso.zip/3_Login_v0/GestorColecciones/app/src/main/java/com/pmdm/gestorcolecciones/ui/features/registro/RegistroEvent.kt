package com.pmdm.gestorcolecciones.ui.features.registro

sealed interface RegistroEvent {
    data class OnCorreoCambiado(val correo: String) : RegistroEvent
    data class OnNickCambiado(val nick: String) : RegistroEvent
    data class OnContrasenaCambiado(val contrasena: String) : RegistroEvent
    data class OnConfirmarContrasenaCambiado(val confirmar: String) : RegistroEvent

}
