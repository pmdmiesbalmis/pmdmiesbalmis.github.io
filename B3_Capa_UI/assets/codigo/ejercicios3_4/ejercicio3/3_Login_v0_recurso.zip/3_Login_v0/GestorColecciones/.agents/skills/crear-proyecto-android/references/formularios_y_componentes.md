# Guía de Formularios y Componentes Balmis

Esta guía describe el uso de la biblioteca de componentes y utilidades del repositorio:
`https://github.com/pmdmiesbalmis/components.git`

---

## 1. Dependencias en `gradle/libs.versions.toml`

La biblioteca se distribuye mediante JitPack y se declara en el catálogo de versiones:

```toml
[versions]
pmdmIesBalmisVersion = "24.1"

[libraries]
pmdm-ies-balmis-components = { group = "com.github.pmdmiesbalmis", name = "components", version.ref = "pmdmIesBalmisVersion" }
pmdm-ies-balmis-utilities = { group = "com.github.pmdmiesbalmis", name = "utilities", version.ref = "pmdmIesBalmisVersion" }
```

En `app/build.gradle.kts`:
```kotlin
dependencies {
    implementation(libs.pmdm.ies.balmis.components)
    implementation(libs.pmdm.ies.balmis.utilities)
}
```

---

## 2. Patrón de Validación de Formularios con Wrappers de TextField

Cuando la aplicación requiera captura y validación de datos (formularios de entrada, creación/edición de entidades):

### 2.1 Principios de Diseño
1. **Wrappers sobre TextField**: Usar los componentes encapsulados de la librería `com.github.pmdmiesbalmis.components` que integran:
   - Validación reactiva en tiempo de edición.
   - Mensajes de error contextuales bajo el campo.
   - Estados de validez (`isValid`, `hasError`, `errorMessage`).
2. **Estado en el ViewModel**:
   - Cada campo del formulario se almacena en el `ViewModel` mediante `mutableStateOf`.
   - Se mantiene un estado para el valor del texto y otro para el estado de validación si procede, o se utiliza el contenedor de estado provisto por la librería.
   - NUNCA usar Flows; actualizar mediante eventos del ViewModel (`onFormularioEvent`).
3. **Comprobación antes de Enviar**:
   - El botón de guardar/confirmar solo se activa cuando todos los campos requeridos son válidos.

### 2.2 Ejemplo de Integración en ViewModel

```kotlin
@HiltViewModel
class FormularioViewModel @Inject constructor(
    private val repository: MiRepository
) : ViewModel() {

    var nombreState by mutableStateOf("")
        private set
    var nombreErrorState by mutableStateOf<String?>(null)
        private set

    var emailState by mutableStateOf("")
        private set
    var emailErrorState by mutableStateOf<String?>(null)
        private set

    val esFormularioValido: Boolean
        get() = nombreState.isNotBlank() && nombreErrorState == null &&
                emailState.isNotBlank() && emailErrorState == null

    fun onNombreCambiado(nuevoNombre: String) {
        nombreState = nuevoNombre
        nombreErrorState = if (nuevoNombre.isBlank()) "El nombre no puede estar vacío" else null
    }

    fun onEmailCambiado(nuevoEmail: String) {
        emailState = nuevoEmail
        emailErrorState = if (!android.util.Patterns.EMAIL_ADDRESS.matcher(nuevoEmail).matches()) {
            "Formato de correo no válido"
        } else {
            null
        }
    }

    fun onGuardarClick() {
        if (!esFormularioValido) return
        viewModelScope.launch {
            repository.insert(MiEntidad(nombre = nombreState, email = emailState))
            onNavegarAtras()
        }
    }
}
```

### 2.3 Uso en el Composable

```kotlin
@Composable
fun FormularioScreen(
    nombreState: String,
    nombreErrorState: String?,
    emailState: String,
    emailErrorState: String?,
    esValido: Boolean,
    onNombreChange: (String) -> Unit,
    onEmailChange: (String) -> Unit,
    onGuardarClick: () -> Unit
) {
    Column(modifier = Modifier.padding(16.dp)) {
        // Uso de componentes con soporte de validación
        OutlinedTextField(
            value = nombreState,
            onValueChange = onNombreChange,
            label = { Text("Nombre") },
            isError = nombreErrorState != null,
            supportingText = {
                if (nombreErrorState != null) {
                    Text(text = nombreErrorState, color = MaterialTheme.colorScheme.error)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = emailState,
            onValueChange = onEmailChange,
            label = { Text("Correo electrónico") },
            isError = emailErrorState != null,
            supportingText = {
                if (emailErrorState != null) {
                    Text(text = emailErrorState, color = MaterialTheme.colorScheme.error)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onGuardarClick,
            enabled = esValido,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Guardar")
        }
    }
}
```
