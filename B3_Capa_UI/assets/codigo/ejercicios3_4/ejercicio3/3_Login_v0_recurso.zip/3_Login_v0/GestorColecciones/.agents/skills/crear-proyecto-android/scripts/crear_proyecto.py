#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para inicializar un nuevo proyecto Android desde la plantilla base.
Aplica renombrado de paquetes, settings, temas, strings, manifiesto,
configuración de Room, Repositorios, Hilt y mock de precarga de base de datos.
"""

import sys
import os
import re
import shutil
import zipfile
import subprocess
import argparse

def to_pascal_case(text: str) -> str:
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', text)
    words = re.findall(r'[a-zA-Z0-9]+', s)
    if not words:
        return "MiProyecto"
    return "".join(w.capitalize() for w in words)

def to_lowercase_pkg(text: str) -> str:
    cleaned = re.sub(r'[^a-zA-Z0-9]', '', text).lower()
    return cleaned if cleaned else "miproyecto"

def create_project(project_name: str, target_dir: str, zip_path: str, entity_name: str = "Elemento", sync_gradle: bool = False):
    pascal_name = to_pascal_case(project_name)
    pkg_name = to_lowercase_pkg(project_name)
    entity_pascal = to_pascal_case(entity_name)
    entity_var = entity_pascal[0].lower() + entity_pascal[1:]
    table_name = entity_var.lower() + "s"

    new_package = f"com.pmdm.{pkg_name}"
    old_package = "com.pmdm.proyectobase2425"
    old_theme = "ProyectoBase2425Theme"
    new_theme = f"{pascal_name}Theme"
    old_style_theme = "Theme.Proyectobase2425"
    new_style_theme = f"Theme.{pascal_name}"

    print(f"=== Creando Proyecto Android ===")
    print(f"Nombre del proyecto: {project_name}")
    print(f"Nombre en PascalCase: {pascal_name}")
    print(f"Paquete destino: {new_package}")
    print(f"Entidad base Room: {entity_pascal}")
    print(f"Directorio destino: {target_dir}")
    print(f"Plantilla zip: {zip_path}")

    os.makedirs(target_dir, exist_ok=True)

    # 1. Descomprimir plantilla
    with zipfile.ZipFile(zip_path, 'r') as zf:
        zf.extractall(target_dir)

    # 2. Renombrar directorios de paquetes en main, androidTest y test
    sources_to_move = [
        ("app/src/main/java/com/pmdm", "proyectobase2425", pkg_name),
        ("app/src/androidTest/java/com/pmdm", "proyectobase2425", pkg_name),
        ("app/src/test/java/com/pmdm", "proyectobase2425", pkg_name),
    ]

    for base_rel, old_dir_name, new_dir_name in sources_to_move:
        base_path = os.path.join(target_dir, base_rel)
        old_full = os.path.join(base_path, old_dir_name)
        new_full = os.path.join(base_path, new_dir_name)
        if os.path.exists(old_full):
            if os.path.exists(new_full) and old_full != new_full:
                shutil.rmtree(new_full)
            os.rename(old_full, new_full)

    # 3. Modificar archivos de texto (.kt, .kts, .xml, .properties)
    text_extensions = {".kt", ".kts", ".xml", ".properties", ".pro", ".gradle"}

    for root, dirs, files in os.walk(target_dir):
        for f in files:
            ext = os.path.splitext(f)[1]
            if ext in text_extensions or f in {".gitignore", "gradlew"}:
                file_path = os.path.join(root, f)
                try:
                    with open(file_path, "r", encoding="utf-8") as file_handle:
                        content = file_handle.read()

                    new_content = content
                    # Reemplazo de paquete e imports
                    new_content = new_content.replace(old_package, new_package)
                    new_content = new_content.replace("com.pmdm.plantillacurso2425", new_package)

                    # Reemplazo de nombre de tema Composable
                    new_content = new_content.replace(old_theme, new_theme)

                    # Reemplazo de estilo XML de tema
                    new_content = new_content.replace(old_style_theme, new_style_theme)

                    # Archivos específicos:
                    # settings.gradle.kts: rootProject.name
                    if f == "settings.gradle.kts":
                        new_content = re.sub(
                            r'rootProject\.name\s*=\s*"[^"]*"',
                            f'rootProject.name = "{pascal_name}"',
                            new_content
                        )

                    # strings.xml: app_name
                    if f == "strings.xml":
                        new_content = re.sub(
                            r'<string\s+name="app_name">[^<]*</string>',
                            f'<string name="app_name">{project_name}</string>',
                            new_content
                        )

                    # app/build.gradle.kts: activar plugins y dependencias Room y Hilt
                    if f == "build.gradle.kts" and os.path.basename(root) == "app":
                        # Descomentar plugins ksp y hilt
                        new_content = re.sub(r'//\s*alias\(libs\.plugins\.devtools\.ksp\)', 'alias(libs.plugins.devtools.ksp)', new_content)
                        new_content = re.sub(r'//\s*alias\(libs\.plugins\.com\.google\.dagger\)', 'alias(libs.plugins.com.google.dagger)', new_content)
                        # Descomentar dependencias hilt, navigation y room
                        new_content = re.sub(r'//\s*implementation\(libs\.dagger\.hilt\.android\)', 'implementation(libs.dagger.hilt.android)', new_content)
                        new_content = re.sub(r'//\s*implementation\(libs\.androidx\.hilt\.navigation\.compose\)', 'implementation(libs.androidx.hilt.navigation.compose)', new_content)
                        new_content = re.sub(r'//\s*ksp\(libs\.dagger\.hilt\.android\.compiler\)', 'ksp(libs.dagger.hilt.android.compiler)', new_content)
                        new_content = re.sub(r'//\s*kspAndroidTest\(libs\.dagger\.hilt\.android\.compiler\)', 'kspAndroidTest(libs.dagger.hilt.android.compiler)', new_content)
                        new_content = re.sub(r'//\s*implementation\(libs\.compose\.navigation\)', 'implementation(libs.compose.navigation)', new_content)
                        new_content = re.sub(r'//\s*implementation\(libs\.kotlinx\.serializarion\.json\)', 'implementation(libs.kotlinx.serializarion.json)', new_content)
                        new_content = re.sub(r'//\s*implementation\(libs\.androidx\.room\.ktx\)', 'implementation(libs.androidx.room.ktx)', new_content)
                        new_content = re.sub(r'//\s*ksp\(libs\.androidx\.room\.compiler\)', 'ksp(libs.androidx.room.compiler)', new_content)

                    # AndroidManifest.xml: registrar clase Application
                    if f == "AndroidManifest.xml":
                        app_name_attr = f'android:name=".{pascal_name}Application"'
                        if app_name_attr not in new_content:
                            new_content = re.sub(
                                r'<application\b',
                                f'<application\n        {app_name_attr}',
                                new_content,
                                count=1
                            )

                    # MainActivity.kt: agregar @AndroidEntryPoint si no está
                    if f == "MainActivity.kt":
                        if "@AndroidEntryPoint" not in new_content:
                            new_content = re.sub(
                                r'(package\s+[^\n]+\n)',
                                r'\1\nimport dagger.hilt.android.AndroidEntryPoint\n',
                                new_content,
                                count=1
                            )
                            new_content = re.sub(
                                r'class\s+MainActivity\b',
                                '@AndroidEntryPoint\nclass MainActivity',
                                new_content,
                                count=1
                            )

                    if new_content != content:
                        with open(file_path, "w", encoding="utf-8") as file_handle:
                            file_handle.write(new_content)
                except Exception as e:
                    print(f"Error procesando {file_path}: {e}")

    # 4. Generar arquitectura de Persistencia (Room, Repositorio, Mocks, Mappers, Application y DI)
    pkg_dir = os.path.join(target_dir, "app/src/main/java/com/pmdm", pkg_name)
    model_dir = os.path.join(pkg_dir, "model")
    data_dir = os.path.join(pkg_dir, "data")
    room_dir = os.path.join(data_dir, "room")
    mocks_dir = os.path.join(data_dir, "mocks")
    di_dir = os.path.join(pkg_dir, "di")

    os.makedirs(model_dir, exist_ok=True)
    os.makedirs(room_dir, exist_ok=True)
    os.makedirs(mocks_dir, exist_ok=True)
    os.makedirs(di_dir, exist_ok=True)

    # 4.1 Application class con precarga automática de la BD
    app_class_path = os.path.join(pkg_dir, f"{pascal_name}Application.kt")
    if not os.path.exists(app_class_path):
        with open(app_class_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}

import android.app.Application
import com.pmdm.{pkg_name}.data.{pascal_name}Repository
import com.pmdm.{pkg_name}.data.a{entity_pascal}
import com.pmdm.{pkg_name}.data.mocks.{entity_pascal}DaoMock
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@HiltAndroidApp
class {pascal_name}Application : Application() {{
    @Inject
    lateinit var daoMock: {entity_pascal}DaoMock

    @Inject
    lateinit var repository: {pascal_name}Repository

    override fun onCreate() {{
        super.onCreate()

        // Precarga de la base de datos Room con datos de ejemplo si está vacía
        runBlocking {{
            if (repository.count() == 0) {{
                daoMock.getTodas().forEach {{ mockItem ->
                    repository.insert(mockItem.a{entity_pascal}())
                }}
            }}
        }}
    }}
}}
''')

    # 4.2 Modelo de Dominio
    model_path = os.path.join(model_dir, f"{entity_pascal}.kt")
    if not os.path.exists(model_path):
        with open(model_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}.model

data class {entity_pascal}(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val categoria: String,
    val destacado: Boolean = false
)
''')

    # 4.3 Entidad Room
    entity_path = os.path.join(room_dir, f"{entity_pascal}Entity.kt")
    if not os.path.exists(entity_path):
        with open(entity_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}.data.room

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "{table_name}")
data class {entity_pascal}Entity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Int,
    @ColumnInfo(name = "nombre")
    val nombre: String,
    @ColumnInfo(name = "descripcion")
    val descripcion: String,
    @ColumnInfo(name = "categoria")
    val categoria: String,
    @ColumnInfo(name = "destacado")
    val destacado: Boolean
)
''')

    # 4.4 DAO Room
    dao_path = os.path.join(room_dir, f"{entity_pascal}Dao.kt")
    if not os.path.exists(dao_path):
        with open(dao_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}.data.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface {entity_pascal}Dao {{
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert({entity_var}: {entity_pascal}Entity)

    @Update(onConflict = OnConflictStrategy.ABORT)
    suspend fun update({entity_var}: {entity_pascal}Entity)

    @Query("DELETE FROM {table_name} WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("SELECT COUNT(*) FROM {table_name}")
    suspend fun count(): Int

    @Query("SELECT * FROM {table_name}")
    suspend fun getTodas(): List<{entity_pascal}Entity>

    @Query("SELECT * FROM {table_name} WHERE id = :id")
    suspend fun getPorId(id: Int): {entity_pascal}Entity

    @Query("SELECT * FROM {table_name} WHERE categoria = :categoria")
    suspend fun getPorCategoria(categoria: String): List<{entity_pascal}Entity>

    @Query("SELECT * FROM {table_name} WHERE destacado = 1")
    suspend fun getDestacados(): List<{entity_pascal}Entity>

    @Query("SELECT DISTINCT categoria FROM {table_name} ORDER BY categoria ASC")
    suspend fun getCategorias(): List<String>
}}
''')

    # 4.5 Room Database
    db_path = os.path.join(room_dir, f"{pascal_name}Db.kt")
    if not os.path.exists(db_path):
        with open(db_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}.data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [{entity_pascal}Entity::class],
    exportSchema = false,
    version = 1
)
abstract class {pascal_name}Db : RoomDatabase() {{
    abstract fun {entity_var}Dao(): {entity_pascal}Dao

    companion object {{
        fun getDatabase(context: Context): {pascal_name}Db = Room.databaseBuilder(
            context,
            {pascal_name}Db::class.java,
            "{pkg_name}.db"
        )
            .allowMainThreadQueries()
            .fallbackToDestructiveMigration()
            .build()
    }}
}}
''')

    # 4.6 Mock Entity
    mock_model_path = os.path.join(mocks_dir, f"{entity_pascal}Mock.kt")
    if not os.path.exists(mock_model_path):
        with open(mock_model_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}.data.mocks

data class {entity_pascal}Mock(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val categoria: String,
    val destacado: Boolean = false
)
''')

    # 4.7 Mock DAO con precarga inicial
    mock_dao_path = os.path.join(mocks_dir, f"{entity_pascal}DaoMock.kt")
    if not os.path.exists(mock_dao_path):
        with open(mock_dao_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}.data.mocks

import kotlinx.coroutines.coroutineScope

class {entity_pascal}DaoMock {{

    val {entity_var}s: MutableList<{entity_pascal}Mock> = mutableListOf(
        {entity_pascal}Mock(
            id = 1,
            nombre = "{entity_pascal} Ejemplo 1",
            descripcion = "Descripción detallada del primer {entity_var} de prueba precargado.",
            categoria = "General",
            destacado = true
        ),
        {entity_pascal}Mock(
            id = 2,
            nombre = "{entity_pascal} Ejemplo 2",
            descripcion = "Descripción del segundo {entity_var} de ejemplo con datos iniciales.",
            categoria = "General",
            destacado = false
        ),
        {entity_pascal}Mock(
            id = 3,
            nombre = "{entity_pascal} Especial 3",
            descripcion = "Tercer {entity_var} de ejemplo para pruebas de listas y filtros.",
            categoria = "Especial",
            destacado = true
        )
    )

    suspend fun insert({entity_var}: {entity_pascal}Mock) = coroutineScope {{
        {entity_var}s.add({entity_var})
    }}

    suspend fun update({entity_var}: {entity_pascal}Mock) = coroutineScope {{
        val idx = {entity_var}s.indexOfFirst {{ it.id == {entity_var}.id }}
        if (idx != -1) {entity_var}s[idx] = {entity_var}
    }}

    suspend fun delete(id: Int) = coroutineScope {{
        {entity_var}s.removeIf {{ it.id == id }}
    }}

    suspend fun count(): Int = coroutineScope {{ {entity_var}s.size }}

    suspend fun getTodas(): List<{entity_pascal}Mock> = coroutineScope {{ {entity_var}s }}

    suspend fun getPorId(id: Int): {entity_pascal}Mock = coroutineScope {{
        {entity_var}s.find {{ it.id == id }} ?: throw NoSuchElementException("{entity_pascal} no encontrado")
    }}

    suspend fun getPorCategoria(categoria: String): List<{entity_pascal}Mock> = coroutineScope {{
        {entity_var}s.filter {{ it.categoria == categoria }}
    }}

    suspend fun getDestacados(): List<{entity_pascal}Mock> = coroutineScope {{
        {entity_var}s.filter {{ it.destacado }}
    }}

    suspend fun getCategorias(): List<String> = coroutineScope {{
        {entity_var}s.map {{ it.categoria }}.distinct().sorted()
    }}
}}
''')

    # 4.8 RepositoryConverter (Extension functions de mapeo)
    converter_path = os.path.join(data_dir, "RepositoryConverter.kt")
    if not os.path.exists(converter_path):
        with open(converter_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}.data

import com.pmdm.{pkg_name}.data.mocks.{entity_pascal}Mock
import com.pmdm.{pkg_name}.data.room.{entity_pascal}Entity
import com.pmdm.{pkg_name}.model.{entity_pascal}

fun {entity_pascal}Mock.a{entity_pascal}(): {entity_pascal} = {entity_pascal}(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    categoria = categoria,
    destacado = destacado
)

fun {entity_pascal}.a{entity_pascal}Mock(): {entity_pascal}Mock = {entity_pascal}Mock(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    categoria = categoria,
    destacado = destacado
)

fun {entity_pascal}Entity.a{entity_pascal}(): {entity_pascal} = {entity_pascal}(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    categoria = categoria,
    destacado = destacado
)

fun {entity_pascal}.a{entity_pascal}Entity(): {entity_pascal}Entity = {entity_pascal}Entity(
    id = id,
    nombre = nombre,
    descripcion = descripcion,
    categoria = categoria,
    destacado = destacado
)
''')

    # 4.9 Repositorio
    repo_path = os.path.join(data_dir, f"{pascal_name}Repository.kt")
    if not os.path.exists(repo_path):
        with open(repo_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}.data

import com.pmdm.{pkg_name}.data.room.{entity_pascal}Dao
import com.pmdm.{pkg_name}.model.{entity_pascal}
import javax.inject.Inject

class {pascal_name}Repository @Inject constructor(
    private val dao: {entity_pascal}Dao
) {{
    suspend fun insert({entity_var}: {entity_pascal}) = dao.insert({entity_var} = {entity_var}.a{entity_pascal}Entity())

    suspend fun update({entity_var}: {entity_pascal}) = dao.update({entity_var} = {entity_var}.a{entity_pascal}Entity())

    suspend fun delete(id: Int) = dao.delete(id)

    suspend fun count(): Int = dao.count()

    suspend fun getTodas(): List<{entity_pascal}> = dao.getTodas().map {{ it.a{entity_pascal}() }}

    suspend fun getPorId(id: Int): {entity_pascal} = dao.getPorId(id).a{entity_pascal}()

    suspend fun getPorCategoria(categoria: String): List<{entity_pascal}> =
        dao.getPorCategoria(categoria).map {{ it.a{entity_pascal}() }}

    suspend fun getDestacados(): List<{entity_pascal}> = dao.getDestacados().map {{ it.a{entity_pascal}() }}

    suspend fun getCategorias(): List<String> = dao.getCategorias()
}}
''')

    # 4.10 Módulo Hilt (di/ModuleApp.kt)
    module_app_path = os.path.join(di_dir, "ModuleApp.kt")
    if not os.path.exists(module_app_path):
        with open(module_app_path, "w", encoding="utf-8") as fh:
            fh.write(f'''package com.pmdm.{pkg_name}.di

import android.content.Context
import com.pmdm.{pkg_name}.data.{pascal_name}Repository
import com.pmdm.{pkg_name}.data.mocks.{entity_pascal}DaoMock
import com.pmdm.{pkg_name}.data.room.{entity_pascal}Dao
import com.pmdm.{pkg_name}.data.room.{pascal_name}Db
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class ModuleApp {{

    @Provides
    @Singleton
    fun provide{entity_pascal}DaoMock(): {entity_pascal}DaoMock = {entity_pascal}DaoMock()

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context
    ): {pascal_name}Db = {pascal_name}Db.getDatabase(context)

    @Provides
    @Singleton
    fun provide{entity_pascal}Dao(
        db: {pascal_name}Db
    ): {entity_pascal}Dao = db.{entity_var}Dao()

    @Provides
    @Singleton
    fun provideRepository(
        dao: {entity_pascal}Dao
    ): {pascal_name}Repository = {pascal_name}Repository(dao)
}}
''')

    print("Proyecto creado y configurado correctamente con Room, Repositorio y Mocks de precarga.")

    # 5. Gradle sync / comprobación si se solicita
    if sync_gradle:
        gradlew = os.path.join(target_dir, "gradlew.bat" if sys.platform == "win32" else "gradlew")
        if os.path.exists(gradlew):
            if sys.platform != "win32":
                os.chmod(gradlew, 0o755)
            print("Ejecutando comprobación de Gradle...")
            try:
                subprocess.run([gradlew, "tasks", "--no-daemon"], cwd=target_dir, check=True)
                print("Sincronización/Verificación de Gradle completada.")
            except Exception as e:
                print(f"Advertencia: No se pudo completar la sincronización automática de Gradle: {e}")

def main():
    parser = argparse.ArgumentParser(description="Crear proyecto Android desde plantilla con Room y Repositorios")
    parser.add_argument("name", help="Nombre del nuevo proyecto")
    parser.add_argument("--target", default=".", help="Directorio destino (por defecto el actual)")
    parser.add_argument("--entity", default="Elemento", help="Nombre de la entidad base de Room (por defecto Elemento)")
    parser.add_argument("--zip", default=None, help="Ruta al archivo proyectobase.zip")
    parser.add_argument("--sync", action="store_true", help="Ejecutar comprobación de Gradle tras crear el proyecto")

    args = parser.parse_args()

    zip_path = args.zip
    if not zip_path:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        zip_path = os.path.normpath(os.path.join(script_dir, "..", "resources", "proyectobase.zip"))

    if not os.path.exists(zip_path):
        print(f"Error: No se encuentra la plantilla en {zip_path}")
        sys.exit(1)

    target_dir = os.path.abspath(args.target)
    create_project(args.name, target_dir, zip_path, args.entity, args.sync)

if __name__ == "__main__":
    main()
