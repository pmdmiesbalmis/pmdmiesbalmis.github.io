package com.pmdm.gestorcolecciones.data

import com.pmdm.gestorcolecciones.data.mocks.PiezaMock
import com.pmdm.gestorcolecciones.data.mocks.UsuarioMock
import com.pmdm.gestorcolecciones.model.Pieza
import com.pmdm.gestorcolecciones.model.Usuario


fun PiezaMock.aPieza(): Pieza = Pieza(
    id = id,
    titulo = titulo,
    categoria = categoria,
    epoca = epoca,
    autor = autor,
    valorEstimado = valorEstimado,
    notas = notas,
    foto = foto
)

fun UsuarioMock.aUsuario(): Usuario = Usuario(
    id = id,
    correo = correo,
    nick = nick,
    contrasena = contrasena,
    recordarSesion = recordarSesion
)

fun Usuario.aUsuarioMock(): UsuarioMock = UsuarioMock(
    id = id,
    correo = correo,
    nick = nick,
    contrasena = contrasena,
    recordarSesion = recordarSesion
)