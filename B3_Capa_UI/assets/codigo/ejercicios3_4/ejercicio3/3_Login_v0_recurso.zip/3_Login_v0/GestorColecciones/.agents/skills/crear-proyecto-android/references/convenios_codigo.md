# Convenios de Código y Nomenclatura Android (PMDM)

Esta guía resume las reglas de estilo y convenios de nombres obligatorios para el desarrollo de aplicaciones Android en la asignatura PMDM según el proyecto de referencia `@ejemplo_app_android`.

---

## 1. Regla Fundamental de Idioma y Nomenclatura

> [!IMPORTANT]
> **Convenio de Idioma Obligatorio**:
> Además de seguir los convenios de nombres de paquetes, clases, funciones y variables, **todos los nombres irán en Español salvo las raíces y terminaciones que se usan en inglés**.
>
> * **Términos de dominio / negocio / funcionalidad**: Se escriben siempre en **Español** (por ejemplo: `receta`, `ingrediente`, `usuario`, `producto`, `tarea`, `coche`, `favorita`, `cargando`, `detalle`, `lista`, `seleccion`).
> * **Raíces, prefijos y terminaciones técnicas estándar de Android/Kotlin**: Se conservan en **inglés** por convenio de la plataforma (por ejemplo: `Entity`, `Dao`, `Db`, `Repository`, `ViewModel`, `Screen`, `Event`, `Route`, `State`, `Mock`, `Application`, `Activity`, `Dialog`, `Item`, `Row`, `TopBar`, `NavHost`, `Destination`, prefijo `on...`, terminación `...Click`).

### Tabla Resumen de Nombres (Correcto vs Incorrecto)

| Tipo de Elemento | ❌ Incorrecto (Todo en inglés) | ❌ Incorrecto (Español forzado) | ✅ Correcto (Español + Terminación técnica en inglés) |
| :--- | :--- | :--- | :--- |
| **Entidad Room** | `RecipeEntity` | `EntidadReceta` | `RecetaEntity` |
| **DAO Room** | `RecipeDao` | `DaoReceta` | `RecetaDao` |
| **Base de Datos** | `RecipeBookDb` | `BaseDatosRecetario` | `RecetarioDb` |
| **Mock DAO** | `RecipeDaoMock` | `DaoMockReceta` | `RecetaDaoMock` |
| **Repositorio** | `RecipeRepository` | `RepositorioRecetario` | `RecetarioRepository` |
| **ViewModel** | `RecipeViewModel` | `ModeloVistaRecetario` | `RecetarioViewModel` |
| **Evento Sealed** | `RecipeEvent` | `EventoRecetario` | `RecetarioEvent` |
| **Acción de Evento** | `OnDeleteClick` | `AlHacerClicEnBorrar` | `OnBorrarClick` |
| **Ruta Navigation** | `RecipeDetailRoute` | `RutaDetalleReceta` | `DetalleRecetaRoute` |
| **Pantalla Composable**| `RecipeDetailScreen` | `PantallaDetalleReceta` | `DetalleRecetaScreen` |
| **Elemento de Lista** | `RecipeItemRow` | `FilaReceta` | `RecetaItem` / `ItemReceta` |
| **Diálogo Composable** | `SelectChefDialog` | `DialogoSeleccionChef` | `SeleccionChefDialog` |
| **Variable de Estado**| `recipeListState` | `estadoListaRecetas` | `listaRecetasState` |
| **Estado Booleano** | `isLoading` | `estadoCargando` | `cargandoState` |
| **Callback Navegar** | `onNavigateToDetail` | `alNavegarDetalle` | `onNavegarVerDetalle` |
| **Función Repositorio**| `getAll()` / `getById()` | `obtenerTodas()` | `getTodas()` / `getPorId(id: Int)` |

---

## 2. Nombres de Paquetes y Módulos

Los paquetes se nombran en minúsculas, sin guiones ni caracteres especiales, utilizando nombres en español salvo términos técnicos de arquitectura:

| Paquete | Formato / Convenio | Ejemplo |
| :--- | :--- | :--- |
| **Paquete base** | `com.pmdm.<nombre_en_minúsculas>` | `com.pmdm.recetario`, `com.pmdm.tareas` |
| **Capa de datos** | `com.pmdm.<nombre>.data` | `com.pmdm.recetario.data` |
| **Persistencia Room** | `com.pmdm.<nombre>.data.room` | `com.pmdm.recetario.data.room` |
| **Mocks de prueba** | `com.pmdm.<nombre>.data.mocks` | `com.pmdm.recetario.data.mocks` |
| **Inyección (DI)** | `com.pmdm.<nombre>.di` | `com.pmdm.recetario.di` |
| **Modelos dominio** | `com.pmdm.<nombre>.model` | `com.pmdm.recetario.model` |
| **Características UI**| `com.pmdm.<nombre>.ui.features.<caracteristica>` | `com.pmdm.recetario.ui.features.listarecetas`, `...fichareceta` |
| **Navegación** | `com.pmdm.<nombre>.ui.navigation` | `com.pmdm.recetario.ui.navigation` |
| **Tema Compose** | `com.pmdm.<nombre>.ui.theme` | `com.pmdm.recetario.ui.theme` |
| **Vistas/Activity** | `com.pmdm.<nombre>.ui.views` | `com.pmdm.recetario.ui.views` |

---

## 3. Clases, Interfaces y Objetos

Formato PascalCase: concepto en **Español** + rol técnico o terminación en **inglés**:

| Tipo de Componente | Formato | Ejemplo |
| :--- | :--- | :--- |
| **Clase Application** | `<Proyecto>Application` | `RecetarioApplication` |
| **MainActivity** | `MainActivity` | `MainActivity` |
| **Entidad de Dominio** | `<Entidad>` (dominio puro en español) | `Receta`, `Usuario`, `Coche`, `Tarea` |
| **Entidad Room** | `<Entidad>Entity` | `RecetaEntity`, `TareaEntity` |
| **DAO Room** | `<Entidad>Dao` | `RecetaDao`, `TareaDao` |
| **Database Room** | `<Proyecto>Db` | `RecetarioDb`, `TareasDb` |
| **Modelo Mock** | `<Entidad>Mock` | `RecetaMock`, `TareaMock` |
| **DAO Mock** | `<Entidad>DaoMock` | `RecetaDaoMock`, `TareaDaoMock` |
| **Repositorio** | `<Proyecto>Repository` | `RecetarioRepository` |
| **Conversores / Mappers**| `RepositoryConverter.kt` | `RepositoryConverter.kt` |
| **Módulo Hilt** | `ModuleApp` | `ModuleApp` |
| **ViewModel** | `<Caracteristica>ViewModel` | `RecetarioViewModel`, `DetalleRecetaViewModel` |
| **Sealed Event** | `<Caracteristica>Event` | `RecetarioEvent`, `DetalleRecetaEvent` |
| **Rutas Navegación** | `<Caracteristica>Route` | `RecetarioRoute`, `DetalleRecetaRoute` |

---

## 4. Composables y Componentes de UI

Funciones `@Composable` en PascalCase: término en **Español** + sufijo técnico en **inglés**:

| Componente | Formato | Ejemplo |
| :--- | :--- | :--- |
| **Tema Composable** | `<Proyecto>Theme` | `RecetarioTheme`, `TiendaTheme` |
| **Pantalla completa** | `<Caracteristica>Screen` | `RecetarioScreen`, `DetalleRecetaScreen` |
| **Elemento de lista** | `Item<Entidad>` o `<Entidad>Item` | `ItemReceta`, `RecetaItem`, `ChefItemRow` |
| **Diálogos** | `<Accion>Dialog` | `SeleccionChefDialog`, `ConfirmarBorradoDialog` |
| **Barras superiores** | `BarraAplicacion`, `<Caracteristica>TopBar` | `BarraAplicacion`, `TopBarTransparente` |
| **NavHost** | `<Proyecto>NavHost` | `RecetarioNavHost` |
| **Destino NavGraph** | `<caracteristica>Destination` | `recetarioDestination`, `detalleRecetaDestination` |

---

## 5. Variables, Estados y Funciones

* **Variables de Estado en ViewModel**:
  - Nombre descriptivo en **Español** con sufijo en inglés **`State`**.
  - Setter siempre `private set` y uso exclusivo de `mutableStateOf`.
  - Ejemplos: `var listaRecetasState by mutableStateOf(emptyList())`, `var recetaSeleccionadaState: Receta? by mutableStateOf(null)`, `var cargandoState by mutableStateOf(false)`.
* **Callbacks de Navegación en ViewModel**:
  - Prefijo en inglés **`onNavegar`** + destino o acción en **Español**.
  - Ejemplos: `var onNavegarVerDetalle: (() -> Unit) = { }`, `var onNavegarSeleccionarChef: (() -> Unit) = { }`, `var onNavegarAtras: (() -> Unit) = { }`.
* **Eventos en Sealed Interface**:
  - Prefijo **`On`** + acción en **Español** + sufijo de evento en inglés (como `Click` o parámetro si procede).
  - Ejemplos: `OnMarcarFavoritaClick`, `OnBorrarClick`, `OnSeleccionarReceta(val id: Int)`, `OnFiltrarPorChef(val chef: String)`.
* **Manejador de Eventos en ViewModel**:
  - Formato `fun on<Caracteristica>Event(e: <Caracteristica>Event)`.
  - Ejemplo: `fun onRecetarioEvent(e: RecetarioEvent)`.
* **Funciones de Extensión para Mapeo (`RepositoryConverter.kt`)**:
  - Prefijo **`a`** en español + nombre del modelo/entidad destino.
  - Ejemplos: `fun RecetaEntity.aReceta(): Receta`, `fun Receta.aRecetaEntity(): RecetaEntity`, `fun RecetaMock.aReceta(): Receta`.

---

## 6. Persistencia de Datos Obligatoria

* **Persistencia Exclusiva con Room**: Todo almacenamiento local debe estructurarse mediante Room Database y la capa de repositorios (`<Proyecto>Repository`).
* **PROHIBICIÓN ESTRICTA**: Está **terminantemente prohibido** el uso de `SharedPreferences` o Jetpack `DataStore` (Preferences / Proto).
* **Precarga de Datos (Mocks)**: Todo proyecto debe implementar un mock de datos iniciales en `<Entidad>DaoMock` y precargarlo en la base de datos Room mediante `runBlocking` en `Application.onCreate()` si `repository.count() == 0`, garantizando que la aplicación disponga de datos de ejemplo al arrancar.
