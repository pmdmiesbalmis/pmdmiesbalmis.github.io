package com.pmdm.gestorcolecciones.ui.features.login

sealed interface LoginEvent {
    data class OnCorreoCambiado(val correo: String) : LoginEvent
    data class OnContrasenaCambiado(val contrasena: String) : LoginEvent

}
