package com.pmdm.gestorcolecciones.ui.features.registro

data class RegistroUiState(
    val correo: String = "",
    val nick: String = "",
    val contrasena: String = "",
    val confirmarContrasena: String = "",
    val terminosAceptados: Boolean = false,
    val cargando: Boolean = false,
    val mensajeError: String? = null,
    val acreditadoConExito: Boolean = false,
    val validacion: ValidacionRegistroUiState = ValidacionRegistroUiState()
)
