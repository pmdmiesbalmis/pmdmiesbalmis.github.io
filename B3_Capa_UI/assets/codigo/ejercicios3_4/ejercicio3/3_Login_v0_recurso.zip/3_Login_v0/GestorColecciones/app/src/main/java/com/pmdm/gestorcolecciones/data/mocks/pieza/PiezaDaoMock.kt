package com.pmdm.gestorcolecciones.data.mocks

import com.pmdm.gestorcolecciones.model.CategoriaColeccion

class PiezaDaoMock constructor() {

    val urlBase = "http://10.0.2.2:80/coleccion/"
    val piezas = listOf(
        PiezaMock(
            id = 1,
            titulo = "Patek Philippe Calatrava",
            categoria = CategoriaColeccion.ALTA_HOROLOGIA,
            epoca = "1954",
            autor = "Patek Philippe",
            valorEstimado = 34500.0,
            notas = "Esfera de esmalte blanco cocido, caja de oro amarillo 18k. Calibre de cuerda manual intacto.",
            foto = "${urlBase}philippe.png"
        ),
        PiezaMock(
            id = 2,
            titulo = "Óleo 'Nocturno en Siena'",
            categoria = CategoriaColeccion.PINTURA,
            epoca = "S. XVII",
            autor = "Escuela Florentina",
            valorEstimado = 18200.0,
            notas = "Óleo sobre lienzo original, bastidor y barniz de época con craquelado noble y marco dorado.",
            foto = "${urlBase}2_nocturno_siena.png"
        ),
        PiezaMock(
            id = 3,
            titulo = "Áureo de Adriano",
            categoria = CategoriaColeccion.NUMISMATICA,
            epoca = "117-138 d.C.",
            autor = "Roma Imperial",
            valorEstimado = 12850.0,
            notas = "Roma Imperial, reverso Salus alimentando serpiente. Calidad de acuñación impecable.",
            foto = "${urlBase}3_aureo_adriano.png"
        ),
        PiezaMock(
            id = 4,
            titulo = "Don Quijote de la Mancha",
            categoria = CategoriaColeccion.LIBROS_RAROS,
            epoca = "1917",
            autor = "Editorial Saturnino Calleja",
            valorEstimado = 4600.0,
            notas = "Encuadernación de lujo en piel chagrín, Madrid 1917, cortes dorados y papel hilo.",
            foto = "${urlBase}4_quijote_1917.png"
        ),
        PiezaMock(
            id = 5,
            titulo = "Tourbillon Esqueleto Oro 18k",
            categoria = CategoriaColeccion.ALTA_HOROLOGIA,
            epoca = "c. 1968",
            autor = "Atelier de Ginebra",
            valorEstimado = 52000.0,
            notas = "Mecanismo visto con platina calada a mano, escape de tourbillon volante y agujas azuladas.",
            foto = "${urlBase}5_tourbillon_esqueleto.png"
        ),
        PiezaMock(
            id = 6,
            titulo = "El Pensador (Reducción en Bronce)",
            categoria = CategoriaColeccion.ESCULTURA,
            epoca = "c. 1904",
            autor = "Auguste Rodin",
            valorEstimado = 29000.0,
            notas = "Pátina marrón verdosa original, fundición de taller europeo con sello en base.",
            foto = "${urlBase}6_escultura_bronce.png"
        )
    ).toMutableList()

    fun getTodos(): List<PiezaMock> = piezas.toList()

    fun getPorId(id: Int): PiezaMock? = piezas.firstOrNull { it.id == id }

    fun insert(pieza: PiezaMock) {
        piezas.removeAll { it.id == pieza.id }
        piezas.add(pieza)
    }

    fun count(): Int = piezas.size
}
