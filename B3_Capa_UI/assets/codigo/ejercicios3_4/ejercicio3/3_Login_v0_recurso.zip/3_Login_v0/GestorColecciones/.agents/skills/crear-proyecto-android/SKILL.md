---
name: crear-proyecto-android
description: >-
  Crea proyectos Android desde la plantilla base proyectobase.zip, aplicando renombrado automático de paquetes, configuración Gradle, temas de Compose y manifiesto. Guía la arquitectura siguiendo los patrones de ejemplo_app_android (Hilt, Room, repositorios, mutableStateOf, desacoplamiento de ViewModels, mock de precarga al arrancar y navegación por callbacks; sin SharedPreferences ni DataStore).
---

# Creación de Proyectos Android desde Plantilla (PMDM)

Esta habilidad permite inicializar nuevos proyectos Android a partir de la plantilla base `proyectobase.zip`, configurando automáticamente la identidad del proyecto y garantizando el cumplimiento de la arquitectura y los convenios del curso.

---

## 1. Procedimiento de Creación del Proyecto

### Paso 1: Comprobación y Configuración del Entorno Python (Windows)
Dado que la Skill ejecuta sus scripts de automatización en Python, el agente debe verificar que el entorno esté correctamente configurado ejecutando los siguientes comandos en Windows:

```cmd
rem Ver si Python ya está instalado
winget list --id Python.Python

rem Listar versiones disponibles de Python
winget search Python.Python

rem Instalar la última versión disponible si no está instalado (ej. Python.Python.3.14)
winget install --id Python.Python.<ultima_version_disponible>

rem Comprobar versión instalada
python --version
```

### Paso 2: Obtener el Nombre del Proyecto
Si el usuario no ha especificado un nombre para el nuevo proyecto, solicítaselo antes de proceder.
A partir del nombre (por ejemplo: `MiRecetario` o `GestorTareas`):
* **Nombre PascalCase**: `MiRecetario` (para clases, temas y `settings.gradle.kts`).
* **Nombre en minúsculas**: `mirecetario` (para el paquete `com.pmdm.mirecetario` y directorios).
* **Nombre de visualización**: `MiRecetario` (para `app_name` en `strings.xml`).

### Paso 3: Ejecutar el Script de Inicialización en Python
Ejecuta el script de automatización en Python para extraer la plantilla y aplicar todas las transformaciones de forma atómica:

```powershell
python .agents/skills/crear-proyecto-android/scripts/crear_proyecto.py <NombreDelProyecto> --target <DirectorioDestino>
```

### Paso 4: Transformaciones Aplicadas
El script realiza automáticamente los puntos requeridos:
1. **Paquete**: Renombra `com.pmdm.proyectobase2425` a `com.pmdm.<nombre_en_minúsculas>` en las rutas de directorios (`main`, `androidTest`, `test`), declaraciones `package` e `imports`, así como `namespace` y `applicationId` en `app/build.gradle.kts`.
2. **Settings**: Modifica `settings.gradle.kts` asignando `rootProject.name = "<NombrePascalCase>"`.
3. **Tema Compose**: En `ui/theme/Theme.kt`, renombra la función a `<NombrePascalCase>Theme` y actualiza todas sus referencias (en `MainActivity.kt`, Previews, etc.).
4. **Tema en Manifest**: Actualiza `AndroidManifest.xml` con `@style/Theme.<NombrePascalCase>` y ajusta `res/values/themes.xml`.
5. **Strings**: Modifica `res/values/strings.xml` para que `app_name` contenga el nombre del proyecto.
6. **Persistencia Room y Repositorio**: Activa en `app/build.gradle.kts` los plugins y dependencias de Room, KSP y Hilt, añade `android:name=".<NombrePascalCase>Application"` en `AndroidManifest.xml`, anota `MainActivity` con `@AndroidEntryPoint`, y genera el andamiaje inicial de base de datos Room (`Db`, `Dao`, `Entity`), repositorio (`Repository`), conversores (`RepositoryConverter`), inyección (`ModuleApp`), y mock de datos con precarga en `Application.onCreate()`.
7. **Sincronización Gradle**: Ejecuta una verificación/sincronización con `./gradlew tasks` si se especifica la opción `--sync`.

---

## 2. Reglas de Arquitectura y Convenios Obligatorios

Al desarrollar o ampliar código dentro del proyecto creado, debes aplicar estrictamente los patrones definidos en `ejemplo_app_android`:

* **Convenios de Nombres e Idioma**: Además de seguir los convenios de nombres de paquetes, clases, funciones y variables, **todos los nombres irán en Español salvo las raíces y terminaciones que se usan en inglés** (`Entity`, `Dao`, `Db`, `Repository`, `ViewModel`, `Screen`, `Event`, `Route`, `State`, `Mock`, `Application`, `Activity`, `Dialog`, etc.). Consulta [Convenios de Código y Nomenclatura](./references/convenios_codigo.md).

### 2.1 Gestión de Estado y ViewModels
* **Uso exclusivo de `mutableStateOf`**: Está **estrictamente prohibido usar Kotlin Flows** (`StateFlow`, `SharedFlow`, `Flow`, `collectAsStateWithLifecycle`).
* **Declaración de estados**: En el `ViewModel`, cada estado se declara con sufijo `State` y setter privado:
  ```kotlin
  var miListaState: List<Elemento> by mutableStateOf(emptyList())
      private set
  ```
* **Desacoplamiento de Pantallas**: **NUNCA** pases el objeto `ViewModel` al Composable de la pantalla. Pasa los estados descompuestos y lambdas para eventos:
  ```kotlin
  @Composable
  fun MiPantallaScreen(
      miListaState: List<Elemento>,
      cargandoState: Boolean,
      onMiEvento: (MiEvent) -> Unit
  )
  ```

### 2.2 Esquema de Navegación
* **Callbacks en el ViewModel**: El `ViewModel` declara propiedades lambda para navegación (ej. `var onNavegarVerDetalle: (() -> Unit) = {}`).
* **NavHost**: El `NavHost` asigna las acciones de navegación a los callbacks del `ViewModel`.
* **Sin NavController en Pantallas**: **NUNCA** pases el objeto `NavController` a las funciones composables de pantalla ni a diálogos.
* **Rutas Type-Safe**: Usa Compose Navigation 2.8+ con objetos `@Serializable object MiRuta` y funciones de extensión `fun NavGraphBuilder.miDestino(...)`.

### 2.3 Inyección de Dependencias
* Usa **Hilt** (`@HiltAndroidApp` en Application, `@AndroidEntryPoint` en MainActivity, `@HiltViewModel` en ViewModels, `@Inject constructor` en repositorios y DAOs, y `ModuleApp` en el paquete `di/`).

### 2.4 Formularios y Componentes
* Cuando la aplicación requiera formularios con validación, utiliza la biblioteca de GitHub:
  `https://github.com/pmdmiesbalmis/components.git` (`libs.pmdm.ies.balmis.components`).
* Emplea los wrappers sobre `TextField` provistos para gestionar la validación y errores reactivos.

### 2.5 Persistencia de Datos (Room y Repositorios)
* **Persistencia Exclusiva con Room**: Todo almacenamiento persistente debe realizarse mediante **Room Database** y la capa de repositorios definida en `ejemplo_app_android`.
* **PROHIBICIÓN ESTRICTA**: Está **terminantemente prohibido usar `SharedPreferences` o Jetpack `DataStore`** (tanto Preferences como Proto DataStore). Toda persistencia se gestiona en SQLite a través de Room.
* **Capa de Repositorio**: El repositorio (`<Proyecto>Repository`) centraliza el acceso a datos inyectando el DAO con `@Inject constructor(private val dao: <Entidad>Dao)`. Sus métodos son `suspend` y manejan exclusivamente modelos de dominio limpios (`model.<Entidad>`).
* **Conversores (`RepositoryConverter.kt`)**: Funciones de extensión de Kotlin para mapear bidireccionalmente entre entidades Room (`Entity`), modelos de dominio (`Model`) y mocks (`Mock`).
* **Mock de Precarga al Arrancar**:
  - Implementa `<Entidad>DaoMock` y `<Entidad>Mock` en `data/mocks/` con un conjunto de datos iniciales representativo.
  - En la clase `<Proyecto>Application.kt`, inyecta el repositorio y el DAO mock, y realiza la precarga en `onCreate()` con `runBlocking`:
    ```kotlin
    runBlocking {
        if (repository.count() == 0) {
            daoMock.getTodas().forEach { repository.insert(it.aModelo()) }
        }
    }
    ```
  - Esto garantiza que al ejecutar el proyecto por primera vez, la base de datos Room contenga datos de prueba inmediatamente disponibles.

---

## 3. Documentación y Referencias de Consulta

Para detalles y ejemplos completos de código, consulta las referencias de la skill:
* [Arquitectura y Patrones](./references/arquitectura_y_patrones.md)
* [Persistencia: Room, Repositorios y Precarga](./references/persistencia_room_y_repositorio.md)
* [Navegación y ViewModels](./references/navegacion_y_viewmodel.md)
* [Formularios y Validación con Componentes Balmis](./references/formularios_y_componentes.md)
* [Convenios de Código y Nomenclatura](./references/convenios_codigo.md)

