package com.pmdm.gestorcolecciones.ui.features.registro

import com.github.pmdmiesbalmis.components.validacion.Validacion
import com.github.pmdmiesbalmis.components.validacion.Validador
import com.github.pmdmiesbalmis.components.validacion.ValidadorCompuesto
import com.github.pmdmiesbalmis.components.validacion.validadores.ValidadorCorreo
import com.github.pmdmiesbalmis.components.validacion.validadores.ValidadorLongitudMinimaTexto
import com.github.pmdmiesbalmis.components.validacion.validadores.ValidadorTextoNoVacio

class ValidadorRegistro(
    var mensajeErrorGlobal: String? = "Por favor, complete los datos obligatorios"
) : Validador<RegistroUiState> {

    val validadorCorreo = ValidadorCompuesto<String>()
        .add(ValidadorTextoNoVacio("El correo oficial es obligatorio"))
        .add(ValidadorCorreo("El correo no tiene un formato válido"))

    val validadorContrasena = ValidadorCompuesto<String>()
        .add(ValidadorTextoNoVacio("La contraseña es obligatoria"))
        .add(ValidadorLongitudMinimaTexto(8, "La contraseña debe tener al menos 8 caracteres"))

    fun validarNick(nick: String): Validacion {
        val trimNick = nick.trim()
        val regex = Regex("^@[a-zA-Z0-9_]{3,20}$")
        val error = !regex.matches(trimNick)
        return object : Validacion {
            override val hayError: Boolean = error
            override val mensajeError: String? = if (error) {
                "Debe comenzar con @ y tener entre 3 y 20 caracteres"
            } else null
        }
    }

    fun validarConfirmarContrasena(contrasena: String, confirmar: String): Validacion {
        val noCoincide = contrasena != confirmar || confirmar.isEmpty()
        return object : Validacion {
            override val hayError: Boolean = noCoincide
            override val mensajeError: String? = if (noCoincide) "Las contraseñas no coinciden" else null
        }
    }

    fun validarTerminos(aceptados: Boolean): Validacion {
        return object : Validacion {
            override val hayError: Boolean = !aceptados
            override val mensajeError: String? = if (!aceptados) "Debe aceptar los términos de curador" else null
        }
    }

    override fun valida(datos: RegistroUiState): ValidacionRegistroUiState {
        val valCorreo = validadorCorreo.valida(datos.correo)
        val valNick = validarNick(datos.nick)
        val valPass = validadorContrasena.valida(datos.contrasena)
        val valConfirm = validarConfirmarContrasena(datos.contrasena, datos.confirmarContrasena)
        val valTerminos = validarTerminos(datos.terminosAceptados)

        return ValidacionRegistroUiState(
            mensajeErrorGlobal = mensajeErrorGlobal,
            validacionCorreo = valCorreo,
            validacionNick = valNick,
            validacionContrasena = valPass,
            validacionConfirmarContrasena = valConfirm,
            validacionTerminos = valTerminos
        )
    }
}
