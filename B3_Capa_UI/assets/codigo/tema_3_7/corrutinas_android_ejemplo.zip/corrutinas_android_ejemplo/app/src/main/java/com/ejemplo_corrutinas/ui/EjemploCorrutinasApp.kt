package com.ejemplo_corrutinas.ui

import android.app.Application

class EjemploCorrutinasApp : Application()