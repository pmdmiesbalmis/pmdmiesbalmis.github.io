package com.ahorcado.ui.features.juego

data class AhorcadoUiState(
    val letraIntroducida: String = "",
    val palabra: String = "",
    val letrasFalladas: String = "",
    val letrasAcertadas: String = "",
    val estado: EstadoJuego = EstadoJuego.EMPEZAR
) {
    enum class EstadoJuego { EMPEZAR, JUGANDO, GANADO, PERDIDO }
}
