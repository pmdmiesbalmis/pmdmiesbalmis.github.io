package com.ahorcado.ui.features.juego

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.ahorcado.R
import com.ahorcado.ui.theme.AhorcadoTheme
import kotlin.random.Random

@Composable
fun MuestraAhorcado(
    modifier: Modifier = Modifier,
    fallos: Int
) {
    val idRecurso = when (fallos) {
        0 -> R.drawable.ahorcado0
        1 -> R.drawable.ahorcado1
        2 -> R.drawable.ahorcado2
        3 -> R.drawable.ahorcado3
        4 -> R.drawable.ahorcado4
        5 -> R.drawable.ahorcado5
        6 -> R.drawable.ahorcado6
        else -> throw Exception("Número de fallos incorrecto")
    }
    Image(
        modifier = modifier.then(Modifier.fillMaxSize()),
        painter = painterResource(idRecurso),
        contentDescription = "Dibujo del ahorcado",
        colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.primary)
    )
}

@Composable
fun BotonEmpezar(
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(modifier = modifier.then(Modifier.fillMaxSize())) {
        Button(
            modifier = Modifier.align(Alignment.Center),
            onClick = onClick
        ) {
            Text(text = "Empezar")
        }
    }
}

@Composable
fun Palabra(palabra: String, letrasAcertadas: String) = Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.Center
) {
    palabra.forEach { letra ->
        val letra = if (letrasAcertadas.contains(letra)) letra else '_'
        Text(
            modifier = Modifier.padding(start = 5.dp, end = 5.dp),
            text = letra.toString(),
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun Fallos(letrasFalladas: String) = Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.Start
) {
    Text(
        modifier = Modifier.padding(start = 5.dp, end = 5.dp),
        text = "Fallos:",
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.tertiary
    )
    Spacer(modifier = Modifier.size(5.dp))
    letrasFalladas.forEach { letra ->
        Text(
            modifier = Modifier.padding(start = 5.dp, end = 5.dp),
            text = letra.toString(),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.tertiary
        )
    }
}

@Composable
fun EstadoJuego(
    palabra: String,
    letrasAcertadas: String,
    letrasFalladas: String
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.Top,
    ) {
        Spacer(modifier = Modifier.size(20.dp))
        Palabra(palabra, letrasAcertadas)
        Spacer(modifier = Modifier.size(20.dp))
        Fallos(letrasFalladas)
    }
}

@Composable
fun JuegaLetra(
    letraState: String,
    onCambiaLetraIntroducida: (String) -> Unit,
    onLetraEnviada: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val focusRequester = remember { FocusRequester() }
        OutlinedTextField(
            modifier = Modifier
                .width(100.dp)
                .padding(start = 5.dp, end = 5.dp)
                .focusRequester(focusRequester),
            value = letraState,
            singleLine = true,
            onValueChange = { onCambiaLetraIntroducida(it.uppercase()) },
            label = { Text(text = "Letra") },
        )
        LaunchedEffect(Unit) {
            focusRequester.requestFocus()
        }
        if (letraState.isNotEmpty()) {
            val controller = LocalSoftwareKeyboardController.current
            Button(
                modifier = Modifier.padding(start = 5.dp, end = 5.dp),
                onClick = {
                    controller?.hide()
                    onLetraEnviada()
                }
            ) {
                Text(text = "Jugar")
            }
        }
    }
}

@Composable
fun ResultadoFinalJuego(
    modifier: Modifier = Modifier,
    estadoJuego: AhorcadoUiState.EstadoJuego,
    onAceptarResultadoFinalJuego: () -> Unit
) {
    Column(
        modifier = modifier.then(Modifier.fillMaxWidth()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            modifier = Modifier.padding(start = 5.dp, end = 5.dp),
            text = if (estadoJuego == AhorcadoUiState.EstadoJuego.GANADO) "Has ganado" else "Has perdido",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.size(20.dp))
        Button(
            modifier = Modifier.padding(start = 5.dp, end = 5.dp),
            onClick = onAceptarResultadoFinalJuego
        ) {
            Text(text = "Aceptar")
        }
    }
}

@Composable
fun MuestraInterface(
    modifier: Modifier = Modifier,
    ahorcadoState: AhorcadoUiState,
    onEventSent: (AhorcadoEvent) -> Unit
) {
    if (ahorcadoState.estado == AhorcadoUiState.EstadoJuego.EMPEZAR) {
        BotonEmpezar(
            modifier = modifier,
            onClick = { onEventSent(AhorcadoEvent.OnEmpezarJuego) }
        )
    } else {
        val scrollState: ScrollState = rememberScrollState()
        Column(
            verticalArrangement = Arrangement.Top,
            modifier = modifier.then(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
            )
        ) {
            EstadoJuego(
                palabra = ahorcadoState.palabra,
                letrasAcertadas = ahorcadoState.letrasAcertadas,
                letrasFalladas = ahorcadoState.letrasFalladas
            )
            Spacer(modifier = Modifier.size(20.dp))
            if (ahorcadoState.estado == AhorcadoUiState.EstadoJuego.JUGANDO) {
                JuegaLetra(
                    letraState = ahorcadoState.letraIntroducida,
                    onCambiaLetraIntroducida = { letra ->
                        onEventSent(AhorcadoEvent.OnCambiaLetraIntroducida(letra))
                    },
                    onLetraEnviada = { onEventSent(AhorcadoEvent.OnLetraEnviada) })
            } else {
                ResultadoFinalJuego(
                    estadoJuego = ahorcadoState.estado,
                    onAceptarResultadoFinalJuego = { onEventSent(AhorcadoEvent.OnAceptarResultadoFinalJuego) }
                )
            }
        }
    }
}

@Composable
fun AhorcadoPortrait(
    ahorcadoState: AhorcadoUiState,
    onEventSent: (AhorcadoEvent) -> Unit
) {
    Column {
        MuestraAhorcado(
            modifier = Modifier.weight(0.4f),
            fallos = ahorcadoState.letrasFalladas.length
        )
        MuestraInterface(
            modifier = Modifier.weight(0.6f),
            ahorcadoState = ahorcadoState,
            onEventSent = onEventSent
        )
    }
}

@Composable
fun AhorcadoLandsacape(
    ahorcadoState: AhorcadoUiState,
    onEventSent: (AhorcadoEvent) -> Unit
) {
    Row {
        MuestraAhorcado(
            modifier = Modifier.weight(0.4f),
            fallos = ahorcadoState.letrasFalladas.length
        )
        MuestraInterface(
            modifier = Modifier.weight(0.6f),
            ahorcadoState = ahorcadoState,
            onEventSent = onEventSent
        )
    }
}

@Composable
fun AhorcaDoScreen(
    ahorcadoState: AhorcadoUiState,
    onEventSent: (AhorcadoEvent) -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        if (maxWidth < 600.dp) {
            AhorcadoPortrait(
                ahorcadoState = ahorcadoState,
                onEventSent = onEventSent
            )
        } else {
            AhorcadoLandsacape(
                ahorcadoState = ahorcadoState,
                onEventSent = onEventSent
            )
        }
    }
}

@Preview(showBackground = true, device = "id:pixel_3a", showSystemUi = true)
@Preview(
    showBackground = true,
    device = "spec:parent=pixel_3a,orientation=landscape", showSystemUi = true,
    uiMode = Configuration.UI_MODE_NIGHT_YES or Configuration.UI_MODE_TYPE_NORMAL
)
@Composable
fun AhorcaDoScreenPreview() {
    val MAXIMO_FALLOS = 6

    var ahorcadoState by remember { mutableStateOf(AhorcadoUiState()) }

    val palabraAcertada: (String, String) -> Boolean = { palabra, letrasAcertadas ->
        var acertada = true
        for (letra in palabra) {
            if (!letrasAcertadas.contains(letra)) {
                acertada = false
                break
            }
        }
        acertada
    }

    AhorcadoTheme {
        AhorcaDoScreen(ahorcadoState = ahorcadoState, onEventSent = { evento ->
            when (evento) {
                is AhorcadoEvent.OnEmpezarJuego -> {
                    val palabras = listOf("XUSA", "JUANJO", "PEPE", "COMPOSABLE")
                    ahorcadoState = ahorcadoState.copy(
                        palabra = palabras[Random.nextInt(0, palabras.size)],
                        estado = AhorcadoUiState.EstadoJuego.JUGANDO
                    )
                }

                is AhorcadoEvent.OnAceptarResultadoFinalJuego -> {
                    ahorcadoState = AhorcadoUiState()
                }

                is AhorcadoEvent.OnCambiaLetraIntroducida -> {
                    ahorcadoState = if (evento.letra.length == 1
                        && !ahorcadoState.letrasAcertadas.contains(evento.letra[0])
                        && !ahorcadoState.letrasFalladas.contains(evento.letra[0])
                        && Regex("^[A-ZÑ]$").matches(evento.letra)
                    )
                        ahorcadoState.copy(letraIntroducida = evento.letra)
                    else
                        ahorcadoState.copy(letraIntroducida = "")
                }

                is AhorcadoEvent.OnLetraEnviada -> {
                    if (ahorcadoState.palabra.contains(ahorcadoState.letraIntroducida[0])) {
                        val letrasAcertadas =
                            ahorcadoState.letrasAcertadas + ahorcadoState.letraIntroducida
                        ahorcadoState = ahorcadoState.copy(
                            letraIntroducida = "",
                            letrasAcertadas = letrasAcertadas,
                            estado = if (palabraAcertada(ahorcadoState.palabra, letrasAcertadas))
                                AhorcadoUiState.EstadoJuego.GANADO
                            else
                                AhorcadoUiState.EstadoJuego.JUGANDO
                        )
                    } else {
                        val letrasFalladas =
                            ahorcadoState.letrasFalladas + ahorcadoState.letraIntroducida
                        ahorcadoState = ahorcadoState.copy(
                            letraIntroducida = "",
                            letrasFalladas = letrasFalladas,
                            estado = if (letrasFalladas.length == MAXIMO_FALLOS)
                                AhorcadoUiState.EstadoJuego.PERDIDO
                            else
                                AhorcadoUiState.EstadoJuego.JUGANDO
                        )
                    }
                }
            }
        })
    }
}

