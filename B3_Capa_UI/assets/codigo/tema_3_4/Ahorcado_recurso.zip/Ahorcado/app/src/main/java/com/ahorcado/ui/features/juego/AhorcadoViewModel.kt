package com.ahorcado.ui.features.juego

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import kotlin.random.Random

class AhorcadoViewModel : ViewModel() {
    companion object {
        private val MAXIMO_FALLOS = 6

        fun palabraAcertada(palabra: String, letrasAcertadas: String): Boolean {
            var acertada = true
            for (letra in palabra) {
                if (!letrasAcertadas.contains(letra)) {
                    acertada = false
                    break
                }
            }
            return acertada
        }
    }

    var ahorcadoState by mutableStateOf(AhorcadoUiState())

    private fun empiezaJuego() {
        val palabras = listOf("XUSA", "JUANJO", "PEPE", "COMPOSABLE")
        ahorcadoState = ahorcadoState.copy(
            palabra = palabras[Random.nextInt(0, palabras.size)],
            estado = AhorcadoUiState.EstadoJuego.JUGANDO
        )
    }

    private fun reiniciaJuego() {
        ahorcadoState = AhorcadoUiState()
    }

    private fun gestionaLetraIntroducida(letra: String) {
        ahorcadoState = if (letra.length == 1
            && !ahorcadoState.letrasAcertadas.contains(letra[0])
            && !ahorcadoState.letrasFalladas.contains(letra[0])
            && Regex("^[A-ZÑ]$").matches(letra)
        )
            ahorcadoState.copy(letraIntroducida = letra)
        else
            ahorcadoState.copy(letraIntroducida = "")
    }

    private fun juegaLetraIntroducida() {
        if (ahorcadoState.palabra.contains(ahorcadoState.letraIntroducida[0])) {
            val letrasAcertadas = ahorcadoState.letrasAcertadas + ahorcadoState.letraIntroducida
            ahorcadoState = ahorcadoState.copy(
                letraIntroducida = "",
                letrasAcertadas = letrasAcertadas,
                estado = if (palabraAcertada(ahorcadoState.palabra, letrasAcertadas))
                    AhorcadoUiState.EstadoJuego.GANADO
                else
                    AhorcadoUiState.EstadoJuego.JUGANDO
            )
        } else {
            val letrasFalladas = ahorcadoState.letrasFalladas + ahorcadoState.letraIntroducida
            ahorcadoState = ahorcadoState.copy(
                letraIntroducida = "",
                letrasFalladas = letrasFalladas,
                estado = if (letrasFalladas.length == MAXIMO_FALLOS)
                    AhorcadoUiState.EstadoJuego.PERDIDO
                else
                    AhorcadoUiState.EstadoJuego.JUGANDO
            )
        }
    }

    fun onEventoAhorcado(evento : AhorcadoEvent) {
        when (evento) {
            is AhorcadoEvent.OnEmpezarJuego -> empiezaJuego()
            is AhorcadoEvent.OnAceptarResultadoFinalJuego -> reiniciaJuego()
            is AhorcadoEvent.OnCambiaLetraIntroducida -> gestionaLetraIntroducida(evento.letra)
            is AhorcadoEvent.OnLetraEnviada -> juegaLetraIntroducida()
        }
    }
}