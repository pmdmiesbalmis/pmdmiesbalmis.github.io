package com.ahorcado.ui.features.juego

sealed interface AhorcadoEvent {
    object OnEmpezarJuego : AhorcadoEvent
    object OnAceptarResultadoFinalJuego : AhorcadoEvent
    object OnLetraEnviada : AhorcadoEvent
    data class OnCambiaLetraIntroducida(val letra: String) : AhorcadoEvent
}