package com.ahorcado.ui.views

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ahorcado.ui.features.juego.AhorcaDoScreen
import com.ahorcado.ui.features.juego.AhorcadoViewModel
import com.ahorcado.ui.theme.AhorcadoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AhorcadoTheme {
                val ahorcadoViewModel: AhorcadoViewModel = viewModel()
                AhorcaDoScreen(
                    ahorcadoViewModel.ahorcadoState,
                    ahorcadoViewModel::onEventoAhorcado
                )
            }
        }
    }
}
