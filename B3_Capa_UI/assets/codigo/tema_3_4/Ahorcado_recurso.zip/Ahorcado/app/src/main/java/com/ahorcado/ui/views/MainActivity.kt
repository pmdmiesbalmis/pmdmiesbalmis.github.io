package com.ahorcado.ui.views

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.ahorcado.ui.features.juego.AhorcaDoScreen
import com.ahorcado.ui.theme.AhorcadoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AhorcadoTheme {
                Aviso()
            }
        }
    }
}

@Composable
fun Aviso() {
    Text(text = "Aquí debería ir el composable raíz del ahorcado!")
}