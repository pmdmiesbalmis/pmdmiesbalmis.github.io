package com.intents_permisos_caso_estudio.ui.views

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.intents_permisos_caso_estudio.ui.features.prueba_intents.PruebaIntentsScreen
import com.intents_permisos_caso_estudio.ui.theme.EjemploIntentsTheme
import com.github.pmdmiesbalmis.utilities.device.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EjemploIntentsTheme {
                var telefono by rememberSaveable {
                    mutableStateOf("")
                }
                val registroSeleccionContacto = registroSelectorTelefonoContacto {
                    telefono = it
                }
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PruebaIntentsScreen(telefono) {
                        registroSeleccionContacto.launch(android.Manifest.permission.READ_CONTACTS)
                    }
                }
            }
        }
    }
}
