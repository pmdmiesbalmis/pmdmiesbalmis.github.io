package com.pmdm.tienda.ui.features.newuser.datospersonales

data class DatosPersonalesUiState(
    val dni: String = "",
    val nombre: String = "",
    val telefono: String = ""
)


