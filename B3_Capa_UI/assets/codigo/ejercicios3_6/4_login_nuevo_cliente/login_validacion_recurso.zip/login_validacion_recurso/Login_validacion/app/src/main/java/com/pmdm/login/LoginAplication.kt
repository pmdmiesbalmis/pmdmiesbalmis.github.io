package com.pmdm.login

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class LoginAplication  : Application() {

}
