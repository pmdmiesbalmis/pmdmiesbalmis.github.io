package com.pmdm.utilities.validacion

fun interface Validador {
    fun valida(texto: String): Validacion
}

