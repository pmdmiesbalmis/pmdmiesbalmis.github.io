package com.pmdm.login.models

data class Usuario(val login:String, val password:String)
