package com.pmdm.login.data.mocks.usuario

data class UsuarioMock(
    val login:String,
    val password:String
    )
