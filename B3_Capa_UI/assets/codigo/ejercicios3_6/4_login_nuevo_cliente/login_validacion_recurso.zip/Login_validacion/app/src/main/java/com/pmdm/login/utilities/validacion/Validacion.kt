package com.pmdm.utilities.validacion

data class Validacion(
    val hayError: Boolean,
    val mensajeError: String? = null
)