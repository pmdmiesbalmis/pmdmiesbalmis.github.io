private var clientes = mutableListOf(
        ClienteMock(
            "11111111K", "juanjo@gmail.com", "Juanjo Perez", "654897584",
            Direccion("Los Molinos, 24Bajo", "Sevilla", "09882"), emptyList<Int>().toMutableList()
        ),
        ClienteMock(
            "22222222L", "pepe@gmail.com", "Pepe Lopez", "145678974",
            Direccion("Los Molinos, 22Bajo", "Sevilla", "09882"), emptyList<Int>().toMutableList()
        ),
        ClienteMock(
            "33333333M", "xusa@gmail.com", "Xusa Rico", "457845698",
            Direccion("Los Molinos, 22Bajo", "Sevilla", "09882"), emptyList<Int>().toMutableList()
        )
    )