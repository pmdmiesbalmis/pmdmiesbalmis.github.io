package com.pmdm.agenda

import android.app.Application

class AgendaApplication : Application()