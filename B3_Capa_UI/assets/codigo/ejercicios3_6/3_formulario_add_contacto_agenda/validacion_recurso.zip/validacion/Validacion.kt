package com.pmdm.agenda.utilities.validacion

// Validacion.kt -----------------------------------------------
// Describe el resultado de una validación.
// Si hay error, se indica el mensaje de error.
// Será el UIState que reciben nuestros TextField para indicar si hay error o no.
data class Validacion(
    val hayError: Boolean,
    val mensajeError: String? = null
)