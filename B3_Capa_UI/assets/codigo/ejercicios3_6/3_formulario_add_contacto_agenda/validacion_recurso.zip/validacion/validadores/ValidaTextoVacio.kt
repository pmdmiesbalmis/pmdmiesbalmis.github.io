package com.pmdm.agenda.utilities.validacion.validadores

import com.pmdm.agenda.utilities.validacion.Validacion
import com.pmdm.agenda.utilities.validacion.Validador

class ValidaTextoVacio(
    val mensajeError: String = "El campo no puede estar vacío"
) : Validador {
    override fun valida(texto: String): Validacion =
        if (texto.isEmpty())
            Validacion(true, mensajeError)
        else
            Validacion(false)
}
 