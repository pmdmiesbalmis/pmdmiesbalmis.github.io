package com.pmdm.agenda.utilities.validacion.validadores

import com.pmdm.agenda.utilities.validacion.Validacion
import com.pmdm.agenda.utilities.validacion.Validador

class ValidaCorreo(
    val mensajeError: String = "Correo no válido"
) : Validador {
    override fun valida(texto: String): Validacion =
        if (Regex("^[A-Za-z](.*)([@]{1})(.{1,})(\\.)(.{1,})$").matches(texto))
            Validacion(false)
        else
            Validacion(true, mensajeError)
}