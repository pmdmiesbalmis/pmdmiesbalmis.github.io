package com.pmdm.agenda.utilities.validacion

// Validador.kt -----------------------------------------------
// Abstracción (SAM) de una función de validación de campos de formulario
// como por ejemplo un email, un teléfono, etc.
// Devuelve un objeto Validacion que devolverá un estado de validación para un TextField.
fun interface Validador {
    fun valida(texto: String): Validacion
}

