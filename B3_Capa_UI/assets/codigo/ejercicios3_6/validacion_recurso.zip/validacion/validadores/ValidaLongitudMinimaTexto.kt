package com.pmdm.agenda.utilities.validacion.validadores

import com.pmdm.agenda.utilities.validacion.Validacion
import com.pmdm.agenda.utilities.validacion.Validador

class ValidaLongitudMinimaTexto(
    val tamañoMinimo: Int,
    val mensajeError: String = "El texto debe mayor o igual a ${tamañoMinimo}"
) : Validador {
    override fun valida(texto: String): Validacion =
        if (texto.length >= tamañoMinimo)
            Validacion(false)
        else
            Validacion(true, mensajeError)
}
