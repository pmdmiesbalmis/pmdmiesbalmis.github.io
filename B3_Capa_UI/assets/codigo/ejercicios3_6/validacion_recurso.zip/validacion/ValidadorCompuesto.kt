package com.pmdm.agenda.utilities.validacion

// ValidadorCompuesto.kt -----------------------------------------------
// Implementa la interfaz Validador y es una clase de utilidad que tiene
// una lista de validadores que debemos pasar para un único TextField
// antes de dar po válido el dato introducido.
// Por ejemplo para un teléfono, podemos tener una validación que compruebe
// que no está vacío, otra que compruebe que tiene una longitud mínima.
// Nota: Las validaciones se ejecutan en orden y si alguna de ellas tiene error
// se devuelve el error y no se ejecutan las siguientes.
class ValidadorCompuesto(validador: Validador) : Validador {
    private val validadores = mutableListOf(validador)
    fun add(validador: Validador): ValidadorCompuesto {
        validadores.add(validador)
        return this
    }

    override fun valida(texto: String): Validacion =
        validadores.firstOrNull { it.valida(texto).hayError }?.valida(texto)
            ?: Validacion(false)
}
