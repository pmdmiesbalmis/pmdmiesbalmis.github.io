package com.pmdm.gestorcolecciones.data

import com.pmdm.gestorcolecciones.data.mocks.UsuarioDaoMock
import com.pmdm.gestorcolecciones.model.Usuario
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UsuarioRepository @Inject constructor(
    private val usuarioDaoMock: UsuarioDaoMock
) {
    fun getUsuarioPorCorreo(correo: String): Usuario? {
        return usuarioDaoMock.getPorCorreo(correo)?.aUsuario()
    }

    fun guardarUsuario(usuario: Usuario) {
        usuarioDaoMock.insert(usuario.aUsuarioMock())
    }


    fun countUsuarios(): Int {
        return usuarioDaoMock.count()
    }
}
