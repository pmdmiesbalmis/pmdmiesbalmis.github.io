package com.pmdm.gestorcolecciones

import android.app.Application
import com.pmdm.gestorcolecciones.data.PiezaRepository
import com.pmdm.gestorcolecciones.data.UsuarioRepository
import com.pmdm.gestorcolecciones.data.aPieza
import com.pmdm.gestorcolecciones.data.aUsuario
import com.pmdm.gestorcolecciones.data.mocks.PiezaDaoMock
import com.pmdm.gestorcolecciones.data.mocks.UsuarioDaoMock
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@HiltAndroidApp
class GestorColeccionesApplication : Application() {


}
