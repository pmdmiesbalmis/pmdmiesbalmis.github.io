package com.pmdm.gestorcolecciones.ui.views

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pmdm.gestorcolecciones.data.PiezaRepository
import com.pmdm.gestorcolecciones.ui.features.login.LoginEvent
import com.pmdm.gestorcolecciones.ui.features.login.LoginScreen
import com.pmdm.gestorcolecciones.ui.features.login.LoginUiState
import com.pmdm.gestorcolecciones.ui.features.login.LoginViewModel
import com.pmdm.gestorcolecciones.ui.features.login.ValidadorLogin
import com.pmdm.gestorcolecciones.ui.features.presentacion.PresentacionScreen
import com.pmdm.gestorcolecciones.ui.features.presentacion.PresentacionViewModel
import com.pmdm.gestorcolecciones.ui.features.registro.RegistroEvent
import com.pmdm.gestorcolecciones.ui.features.registro.RegistroScreen
import com.pmdm.gestorcolecciones.ui.features.registro.RegistroUiState
import com.pmdm.gestorcolecciones.ui.features.registro.RegistroViewModel
import com.pmdm.gestorcolecciones.ui.features.registro.ValidadorRegistro
import com.pmdm.gestorcolecciones.ui.theme.GestorColeccionesTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GestorColeccionesTheme {
                var viewModelRegistro: RegistroViewModel = viewModel()
                var viewModelLogin: LoginViewModel = viewModel()
                var viewModelPresentacion: PresentacionViewModel = viewModel()
                /*       PresentacionScreen(
                           viewModelPresentacion.piezaMostrarState,
                           {},
                           {}
                       )*/
               // RegistroScreen(viewModelRegistro.uiState, viewModelRegistro::onRegistroEvent)
                  LoginScreen(viewModelLogin.uiState, viewModelLogin::onLoginEvent)

            }

        }
    }
}