package com.pmdm.gestorcolecciones.di

import com.pmdm.gestorcolecciones.data.PiezaRepository
import com.pmdm.gestorcolecciones.data.UsuarioRepository
import com.pmdm.gestorcolecciones.data.mocks.PiezaDaoMock
import com.pmdm.gestorcolecciones.data.mocks.UsuarioDaoMock
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object ModuleApp {



    @Provides
    @Singleton
    fun providePiezaDaoMock(): PiezaDaoMock {
        return PiezaDaoMock()
    }

    @Provides
    @Singleton
    fun provideUsuarioDaoMock(): UsuarioDaoMock {
        return UsuarioDaoMock()
    }

    @Provides
    @Singleton
    fun provideUsuarioRepository(
        usuarioDaoMock: UsuarioDaoMock
    ): UsuarioRepository =
        UsuarioRepository(usuarioDaoMock)

    @Provides
    @Singleton
    fun providePiezaRepository(
        piezaDaoMock: PiezaDaoMock
    ): PiezaRepository =
        PiezaRepository(piezaDaoMock)
}
