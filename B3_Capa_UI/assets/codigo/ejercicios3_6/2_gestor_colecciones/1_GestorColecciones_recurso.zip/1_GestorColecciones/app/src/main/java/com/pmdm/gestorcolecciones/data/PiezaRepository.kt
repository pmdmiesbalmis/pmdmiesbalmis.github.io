package com.pmdm.gestorcolecciones.data


import com.pmdm.gestorcolecciones.data.mocks.PiezaDaoMock
import com.pmdm.gestorcolecciones.data.mocks.PiezaMock
import com.pmdm.gestorcolecciones.model.CategoriaColeccion
import com.pmdm.gestorcolecciones.model.Pieza
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PiezaRepository @Inject constructor(
    private val piezaDaoMock: PiezaDaoMock
) {
    fun getPiezas(): List<Pieza> {
        return piezaDaoMock.getTodos().map { it.aPieza() }
    }
    fun getPiezaPorId(id: Int): Pieza? {
        return piezaDaoMock.getPorId(id)?.aPieza()
    }
    fun guardarPieza(pieza: Pieza) {
        return piezaDaoMock.insert(pieza.aPiezaMock())
    }

    fun countPiezas(): Int {
        return piezaDaoMock.count()
    }
}
