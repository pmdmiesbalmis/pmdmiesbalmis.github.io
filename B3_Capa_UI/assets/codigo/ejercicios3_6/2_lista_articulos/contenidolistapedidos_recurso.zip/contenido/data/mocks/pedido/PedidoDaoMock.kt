package com.pmdm.tienda.data.mocks.pedido

import android.os.Build
import androidx.annotation.RequiresApi
import java.time.LocalDateTime
import java.time.ZoneOffset
import javax.inject.Inject


@RequiresApi(Build.VERSION_CODES.O)
class PedidoDaoMock @Inject constructor() {
    private var pedidoMocks = mutableListOf<PedidoMock>()
    private var articuloConPedidoMocks = mutableListOf<ArticuloDePedidoMock>()

    fun insert(pedido: PedidoMock, articulos: List<ArticuloDePedidoMock>) {
        pedidoMocks.add(pedido)
        articulos.forEach { a ->
            articuloConPedidoMocks.add(
                ArticuloDePedidoMock(
                    a.articuloId,
                    pedido.pedidoId,
                    a.tamaño,
                    a.cantidad
                )
            )
        }
    }

    fun delete(pedido: PedidoMock) {
        val p = pedidoMocks.find { pedido.pedidoId == it.pedidoId }
        if (p != null) pedidoMocks.remove(p)
    }

    fun update(pedido: PedidoMock) {
        val p = pedidoMocks.find { pedido.pedidoId == it.pedidoId }
        if (p != null) {
            val i = pedidoMocks.lastIndexOf(p)
            if (i != -1) pedidoMocks.removeAt(i)
        }
    }

    fun getPedidos(): List<PedidoMock> = pedidoMocks
    fun getPedido(pedidoId: Long): PedidoMock? {
        return pedidoMocks.find { pedidoId == it.pedidoId }
    }

    fun getPedidos(dniCliente: String): List<PedidoMock> =
        pedidoMocks.filter { p -> p.dniCliente == dniCliente }

    fun getArticulosPedido(pedidoId: Long): List<ArticuloDePedidoMock> {
        return articuloConPedidoMocks.filter { pedidoId == it.pedidoId }
    }

    fun guardarArticuloPedido(pedido: ArticuloDePedidoMock) {
        articuloConPedidoMocks.add(pedido)
    }

    fun getCantidadArticulosEnPedido(pedidoId: Long): Int {
        return articuloConPedidoMocks.filter { pedidoId == it.pedidoId }.count()
    }

    init {
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 4, pedidoId = 1, tamaño = 1,
                cantidad = 1
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 6, pedidoId = 1, tamaño = 1,
                cantidad = 1
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 8, pedidoId = 1, tamaño = 1,
                cantidad = 1
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 13, pedidoId = 1, tamaño = 2,
                cantidad = 1
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 14, pedidoId = 1, tamaño = 1,
                cantidad = 2
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 6, pedidoId = 1, tamaño = 3,
                cantidad = 1
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 11, pedidoId = 1, tamaño = 1,
                cantidad = 3
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 16, pedidoId = 1, tamaño = 2,
                cantidad = 1
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 10, pedidoId = 1, tamaño = 2,
                cantidad = 2
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 14, pedidoId = 2, tamaño = 2,
                cantidad = 1
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 8, pedidoId = 2, tamaño = 2,
                cantidad = 1
            )
        )
        articuloConPedidoMocks.add(
            ArticuloDePedidoMock(
                articuloId = 6, pedidoId = 3, tamaño = 3,
                cantidad = 2
            )
        )
        pedidoMocks.add(
            PedidoMock(
                pedidoId = 1, dniCliente = "22222222L",
                total = 800f, fecha = LocalDateTime.now().toInstant(ZoneOffset.UTC).toEpochMilli()
            )
        )
        pedidoMocks.add(
            PedidoMock(
                pedidoId = 2, dniCliente = "22222222L",
                total = 300f, fecha = LocalDateTime.now().toInstant(ZoneOffset.UTC).toEpochMilli()
            )
        )
        pedidoMocks.add(
            PedidoMock(
                pedidoId = 3, dniCliente = "22222222L",
                total = 150f, fecha = LocalDateTime.now().toInstant(ZoneOffset.UTC).toEpochMilli()
            )
        )

    }

}
