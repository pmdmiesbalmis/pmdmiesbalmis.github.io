package com.pmdm.lista_articulos.data.mocks

import com.pmdm.lista_articulos.ui.features.pedidos.ArticuloConPedido
import com.pmdm.lista_articulos.ui.features.pedidos.PedidoConArticuloUiState
import com.pmdm.tienda.data.mocks.articulo.ArticuloMock
import com.pmdm.tienda.models.Articulo
import com.pmdm.tienda.models.ArticuloDePedido
import com.pmdm.tienda.models.Pedido

fun ArticuloMock.toArticulo(): Articulo =
    Articulo(this.id, this.url, this.precio, this.descripcion)

fun MutableList<ArticuloMock>.toArticulos(): List<Articulo> =
    this.map { it.toArticulo() }

fun Articulo.toArticuloMock(): ArticuloMock =
    ArticuloMock(this.id, this.url, this.precio, this.descripcion)






