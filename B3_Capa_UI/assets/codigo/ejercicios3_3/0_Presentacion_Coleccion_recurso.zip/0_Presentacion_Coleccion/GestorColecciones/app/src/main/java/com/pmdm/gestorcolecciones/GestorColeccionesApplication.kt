package com.pmdm.gestorcolecciones

import android.app.Application



class GestorColeccionesApplication : Application() {


}
