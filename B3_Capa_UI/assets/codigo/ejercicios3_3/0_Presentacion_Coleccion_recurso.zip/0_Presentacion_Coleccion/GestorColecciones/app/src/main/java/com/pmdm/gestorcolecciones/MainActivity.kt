package com.pmdm.gestorcolecciones

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import com.pmdm.gestorcolecciones.data.PiezaRepository
import com.pmdm.gestorcolecciones.ui.features.presentacion.PresentacionScreen
import com.pmdm.gestorcolecciones.ui.theme.GestorColeccionesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //  enableEdgeToEdge()
        setContent {
            GestorColeccionesTheme {
                val piezaMostrar by remember {
                    mutableStateOf(PiezaRepository().getPiezas().random())
                }
                PresentacionScreen(
                    piezaMostrar = piezaMostrar,
                    onCrearCuentaClick = {},
                    onIniciarSesionClick = {}
                )
            }
        }
    }
}