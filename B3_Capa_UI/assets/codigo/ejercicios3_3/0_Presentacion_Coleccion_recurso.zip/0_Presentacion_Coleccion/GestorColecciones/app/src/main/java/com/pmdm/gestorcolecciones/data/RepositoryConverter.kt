package com.pmdm.gestorcolecciones.data

import com.pmdm.gestorcolecciones.data.mocks.PiezaMock

import com.pmdm.gestorcolecciones.model.CategoriaColeccion
import com.pmdm.gestorcolecciones.model.Pieza



fun Pieza.aPiezaMock(): PiezaMock= PiezaMock(
    id = id,
    titulo = titulo,
    categoria = categoria,
    epoca = epoca,
    autor = autor,
    valorEstimado = valorEstimado,
    notas = notas,
    foto = foto
)



fun PiezaMock.aPieza(): Pieza = Pieza(
    id = id,
    titulo = titulo,
    categoria = categoria,
    epoca = epoca,
    autor = autor,
    valorEstimado = valorEstimado,
    notas = notas,
    foto = foto
)

