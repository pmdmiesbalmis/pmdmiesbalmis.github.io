package com.pmdm.gestorcolecciones.data

import com.pmdm.gestorcolecciones.data.mocks.PiezaDaoMock
import com.pmdm.gestorcolecciones.model.Pieza



class PiezaRepository (
) {
    private var piezaDao= PiezaDaoMock()
    fun getPiezas(): List<Pieza> {
        return piezaDao.getTodos().map { it.aPieza() }
    }


    fun countPiezas(): Int {
        return piezaDao.count()
    }
}
