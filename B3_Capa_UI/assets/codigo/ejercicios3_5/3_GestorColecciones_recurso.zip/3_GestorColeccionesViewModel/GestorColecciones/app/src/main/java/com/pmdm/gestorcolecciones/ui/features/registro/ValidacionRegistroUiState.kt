package com.pmdm.gestorcolecciones.ui.features.registro

import com.github.pmdmiesbalmis.components.validacion.Validacion

data class ValidacionRegistroUiState(
    val mensajeErrorGlobal: String? = null,
    val validacionCorreo: Validacion = object : Validacion {},
    val validacionNick: Validacion = object : Validacion {},
    val validacionContrasena: Validacion = object : Validacion {},
    val validacionConfirmarContrasena: Validacion = object : Validacion {},
    val validacionTerminos: Validacion = object : Validacion {}
) : Validacion {
    override val hayError: Boolean
        get() = validacionCorreo.hayError ||
                validacionNick.hayError ||
                validacionContrasena.hayError ||
                validacionConfirmarContrasena.hayError ||
                validacionTerminos.hayError

    override val mensajeError: String?
        get() = when {
            validacionCorreo.hayError -> validacionCorreo.mensajeError
            validacionNick.hayError -> validacionNick.mensajeError
            validacionContrasena.hayError -> validacionContrasena.mensajeError
            validacionConfirmarContrasena.hayError -> validacionConfirmarContrasena.mensajeError
            validacionTerminos.hayError -> validacionTerminos.mensajeError
            else -> mensajeErrorGlobal
        }
}
