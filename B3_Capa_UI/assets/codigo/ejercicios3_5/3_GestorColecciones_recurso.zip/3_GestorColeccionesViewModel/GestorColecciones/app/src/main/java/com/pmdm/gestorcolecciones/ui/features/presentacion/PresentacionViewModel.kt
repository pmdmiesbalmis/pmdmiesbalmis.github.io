package com.pmdm.gestorcolecciones.ui.features.presentacion

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pmdm.gestorcolecciones.data.PiezaRepository
import com.pmdm.gestorcolecciones.model.Pieza
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch

import kotlin.random.Random

class PresentacionViewModel(

) : ViewModel() {
    private val piezaRepository: PiezaRepository = PiezaRepository()
    var piezaMostrarState: Pieza? by mutableStateOf(null)


    init {
        viewModelScope.launch {
            piezaMostrarState =
                piezaRepository.getPiezas().get(Random.nextInt(0, piezaRepository.countPiezas()))
        }
    }


}
