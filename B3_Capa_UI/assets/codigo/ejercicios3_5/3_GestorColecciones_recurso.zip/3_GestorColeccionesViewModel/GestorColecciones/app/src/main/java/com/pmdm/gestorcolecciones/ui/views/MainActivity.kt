package com.pmdm.gestorcolecciones.ui.views

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pmdm.gestorcolecciones.ui.features.login.LoginScreen
import com.pmdm.gestorcolecciones.ui.features.login.LoginViewModel
import com.pmdm.gestorcolecciones.ui.features.presentacion.PresentacionScreen
import com.pmdm.gestorcolecciones.ui.features.presentacion.PresentacionViewModel
import com.pmdm.gestorcolecciones.ui.features.registro.RegistroScreen
import com.pmdm.gestorcolecciones.ui.features.registro.RegistroViewModel
import com.pmdm.gestorcolecciones.ui.theme.GestorColeccionesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //  enableEdgeToEdge()
        setContent {
            GestorColeccionesTheme {
                var viewModelRegistro: RegistroViewModel = viewModel()
                var viewModelLogin: LoginViewModel = viewModel()
                var viewModelPresentacion: PresentacionViewModel = viewModel()
         /*       PresentacionScreen(
                    viewModelPresentacion.piezaMostrarState,
                    {},
                    {}
                )*/
                RegistroScreen(viewModelRegistro.uiState, viewModelRegistro::onRegistroEvent)
              //  LoginScreen(viewModelLogin.uiState, viewModelLogin::onLoginEvent)

            }
        }
    }
}