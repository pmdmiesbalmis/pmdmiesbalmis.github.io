package com.pmdm.gestorcolecciones.data.mocks


class UsuarioDaoMock {
    val usuarioPrueba = UsuarioMock(
        id = 1,
        correo = "curador@colectionist.art",
        nick = "@curador_art",
        contrasena = "curador123",
        recordarSesion = true
    )
    private val usuarios = mutableListOf(usuarioPrueba)

    fun getTodos(): List<UsuarioMock> = usuarios.toList()

    fun getPorCorreo(correo: String): UsuarioMock? =
        usuarios.firstOrNull { it.correo.equals(correo, ignoreCase = true) }

    fun insert(usuario: UsuarioMock) {
        usuarios.removeAll { it.correo.equals(usuario.correo, ignoreCase = true) }
        usuarios.add(usuario)
    }
    fun update(usuario: UsuarioMock) {
        val index = usuarios.indexOfFirst { it.correo.equals(usuario.correo, ignoreCase = true) }
        if (index != -1) {
            usuarios[index] = usuario
        }
    }

    fun getSesionActiva(): UsuarioMock? = usuarios.firstOrNull { it.recordarSesion }

    fun count(): Int = usuarios.size
}
