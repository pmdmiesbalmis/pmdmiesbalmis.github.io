package com.pmdm.gestorcolecciones.model

data class Usuario(
    val id: Int = 0,
    val correo: String,
    val nick: String,
    val contrasena: String,
    val recordarSesion: Boolean = false
)
