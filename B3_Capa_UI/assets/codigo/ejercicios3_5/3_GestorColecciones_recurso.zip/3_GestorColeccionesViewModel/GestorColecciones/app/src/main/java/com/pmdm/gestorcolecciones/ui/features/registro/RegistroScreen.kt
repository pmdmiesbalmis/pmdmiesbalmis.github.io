package com.pmdm.gestorcolecciones.ui.features.registro

import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.github.pmdmiesbalmis.components.ui.composables.CheckboxWithLabel
import com.github.pmdmiesbalmis.components.ui.composables.OutlinedTextFieldEmail
import com.github.pmdmiesbalmis.components.ui.composables.OutlinedTextFieldName
import com.github.pmdmiesbalmis.components.ui.composables.OutlinedTextFieldPassword
import com.github.pmdmiesbalmis.components.ui.composables.SnackbarError
import com.pmdm.gestorcolecciones.ui.theme.GestorColeccionesTheme
import com.pmdm.gestorcolecciones.ui.theme.GlacierPrimary
import com.pmdm.gestorcolecciones.ui.theme.GlacierSecondary

@Composable
fun RegistroScreen(
    uiState: RegistroUiState,
    onRegistroEvent: (RegistroEvent) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            EncabezadoRegistro()
            TarjetaFormularioRegistro(uiState = uiState, onRegistroEvent = onRegistroEvent)
            PieRegistro(
                onIniciarSesionClick = { onRegistroEvent(RegistroEvent.OnIniciarSesionClick) },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }

        uiState.mensajeError?.let { msg ->
            SnackbarErrorRegistro(
                mensajeError = msg,
                onDismissError = { onRegistroEvent(RegistroEvent.OnErrorDescartado) },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
private fun EncabezadoRegistro() {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = "Acreditación Oficial",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "Cree su libreta de coleccionista independiente para acceder a la colección de piezas",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun TarjetaFormularioRegistro(
    uiState: RegistroUiState,
    onRegistroEvent: (RegistroEvent) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        border = BorderStroke(1.dp, GlacierSecondary.copy(alpha = 0.15f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextFieldEmail(
                modifier = Modifier.fillMaxWidth(),
                label = "Correo Electrónico Oficial",
                emailState = uiState.correo,
                validacionState = uiState.validacion.validacionCorreo,
                onValueChange = { onRegistroEvent(RegistroEvent.OnCorreoCambiado(it)) }
            )

            OutlinedTextFieldName(
                modifier = Modifier.fillMaxWidth(),
                label = "Identificador / Nick (@ejemplo)",
                nameState = uiState.nick,
                validacionState = uiState.validacion.validacionNick,
                onValueChange = { onRegistroEvent(RegistroEvent.OnNickCambiado(it)) }
            )

            OutlinedTextFieldPassword(
                modifier = Modifier.fillMaxWidth(),
                passwordState = uiState.contrasena,
                validacionState = uiState.validacion.validacionContrasena,
                onValueChange = { onRegistroEvent(RegistroEvent.OnContrasenaCambiado(it)) },
                label = "Contraseña de Seguridad"
            )

            OutlinedTextFieldPassword(
                modifier = Modifier.fillMaxWidth(),
                passwordState = uiState.confirmarContrasena,
                validacionState = uiState.validacion.validacionConfirmarContrasena,
                onValueChange = { onRegistroEvent(RegistroEvent.OnConfirmarContrasenaCambiado(it)) },
                label = "Reiterar Contraseña"
            )

            CheckboxWithLabel(
                label = "Acepto los términos de registro, el código ético sobre procedencia verificada y la política de inventario.",
                modifier = Modifier.fillMaxWidth(),
                checkedState = uiState.terminosAceptados,
                onStateChange = { onRegistroEvent(RegistroEvent.OnTerminosCambiado(it)) }
            )

            if (uiState.validacion.validacionTerminos.hayError) {
                Text(
                    text = uiState.validacion.validacionTerminos.mensajeError ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(start = 4.dp)
                )
            }

            Button(
                onClick = { onRegistroEvent(RegistroEvent.OnRegistrarClick) },
                enabled = !uiState.cargando,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GlacierPrimary,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                if (uiState.cargando) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp
                    )
                } else if (uiState.acreditadoConExito) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Cuenta Creada",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Crear Cuenta de Coleccionista",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        }
    }
}

@Composable
private fun PieRegistro(
    onIniciarSesionClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "¿Ya tiene credenciales de acceso?",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        TextButton(onClick = onIniciarSesionClick) {
            Text(
                text = "Iniciar Sesión en el Gabinete",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                color = GlacierSecondary
            )
        }
    }
}

@Composable
private fun SnackbarErrorRegistro(
    mensajeError: String,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        SnackbarError(
            mensajeError = mensajeError,
            onDismissError = onDismissError
        )
    }
}

@Preview(showBackground = true)
@Composable
fun VistaPreviaPantallaRegistro() {
    GestorColeccionesTheme {
        RegistroScreen(
            uiState = RegistroUiState(),
            onRegistroEvent = {}
        )
    }
}
