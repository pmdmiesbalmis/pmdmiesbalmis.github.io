package com.pmdm.gestorcolecciones.ui.features.login

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pmdm.gestorcolecciones.data.UsuarioRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch

class LoginViewModel (

) : ViewModel() {
    val usuarioRepository: UsuarioRepository= UsuarioRepository()
    private val validador = ValidadorLogin()

    var uiState by mutableStateOf(LoginUiState())
        private set



    fun onLoginEvent(e: LoginEvent) {
        when (e) {
            is LoginEvent.OnCorreoCambiado -> {
                val valCorreo = validador.validadorCorreo.valida(e.correo)
                uiState = uiState.copy(
                    correo = e.correo,
                    mensajeError = null,
                    validacion = uiState.validacion.copy(validacionCorreo = valCorreo)
                )
            }

            is LoginEvent.OnContrasenaCambiado -> {
                val valContrasena = validador.validadorContrasena.valida(e.contrasena)
                uiState = uiState.copy(
                    contrasena = e.contrasena,
                    mensajeError = null,
                    validacion = uiState.validacion.copy(validacionContrasena = valContrasena)
                )
            }

            is LoginEvent.OnRecordarSesionCambiado -> {
                uiState = uiState.copy(recordarSesion = e.recordar)
            }

            LoginEvent.OnIniciarSesionClick -> {
                iniciarSesion()
            }

            LoginEvent.OnRegistrarseClick -> {
            }

            LoginEvent.OnErrorDescartado -> {
                uiState = uiState.copy(mensajeError = null)
            }
        }
    }

    private fun iniciarSesion() {
        val validacionTotal = validador.valida(uiState)
        if (validacionTotal.hayError) {
            uiState = uiState.copy(
                validacion = validacionTotal,
                mensajeError = validacionTotal.mensajeError
            )
        }
        else {
            viewModelScope.launch {
                uiState = uiState.copy(cargando = true, mensajeError = null)
                val usuario = usuarioRepository.getUsuarioPorCorreo(uiState.correo.trim())
                if (usuario == null) {
                    uiState = uiState.copy(
                        cargando = false,
                        mensajeError = "No existe ninguna cuenta con este correo"
                    )
                } else if (usuario.contrasena != uiState.contrasena) {
                    uiState = uiState.copy(
                        cargando = false,
                        mensajeError = "La clave de acceso ingresada es incorrecta"
                    )
                } else {
                    usuarioRepository.actualizarUsuario(usuario.copy(recordarSesion = uiState.recordarSesion))
                    uiState = uiState.copy(cargando = false)

                }
            }
        }
    }
}
