package com.pmdm.gestorcolecciones.ui.features.login

data class LoginUiState(
    val correo: String = "",
    val contrasena: String = "",
    val recordarSesion: Boolean = true,
    val cargando: Boolean = false,
    val mensajeError: String? = null,
    val validacion: ValidacionLoginUiState = ValidacionLoginUiState()
)
