package com.pmdm.gestorcolecciones.data


import com.pmdm.gestorcolecciones.data.mocks.PiezaDaoMock
import com.pmdm.gestorcolecciones.model.CategoriaColeccion
import com.pmdm.gestorcolecciones.model.Pieza

class PiezaRepository(

) {
    private val piezaDaoMock: PiezaDaoMock = PiezaDaoMock()
     fun getPiezas(): List<Pieza> {
        return piezaDaoMock.getTodos().map { it.aPieza() }
    }

    fun getPiezaPorId(id: Int): Pieza? {
        return piezaDaoMock.getPorId(id)?.aPieza()
    }


    suspend fun countPiezas(): Int {
        return piezaDaoMock.count()
    }
}
