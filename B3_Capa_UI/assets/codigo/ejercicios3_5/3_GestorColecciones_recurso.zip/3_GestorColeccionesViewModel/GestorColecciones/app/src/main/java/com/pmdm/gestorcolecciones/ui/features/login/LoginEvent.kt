package com.pmdm.gestorcolecciones.ui.features.login

sealed interface LoginEvent {
    data class OnCorreoCambiado(val correo: String) : LoginEvent
    data class OnContrasenaCambiado(val contrasena: String) : LoginEvent
    data class OnRecordarSesionCambiado(val recordar: Boolean) : LoginEvent
    data object OnIniciarSesionClick : LoginEvent
    data object OnRegistrarseClick : LoginEvent
    data object OnErrorDescartado : LoginEvent
}
