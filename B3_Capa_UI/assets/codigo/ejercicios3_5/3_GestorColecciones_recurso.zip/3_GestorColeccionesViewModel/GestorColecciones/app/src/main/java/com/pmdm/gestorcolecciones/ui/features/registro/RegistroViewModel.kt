package com.pmdm.gestorcolecciones.ui.features.registro

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pmdm.gestorcolecciones.data.UsuarioRepository
import com.pmdm.gestorcolecciones.model.Usuario
import kotlinx.coroutines.launch

class RegistroViewModel(

) : ViewModel() {
    private val usuarioRepository: UsuarioRepository  = UsuarioRepository()
    private val validador = ValidadorRegistro()

    var uiState by mutableStateOf(RegistroUiState())
        private set


    fun onRegistroEvent(e: RegistroEvent) {
        when (e) {
            is RegistroEvent.OnCorreoCambiado -> {
                val valCorreo = validador.validadorCorreo.valida(e.correo)
                uiState = uiState.copy(
                    correo = e.correo,
                    mensajeError = null,
                    validacion = uiState.validacion.copy(validacionCorreo = valCorreo)
                )
            }

            is RegistroEvent.OnNickCambiado -> {
                val formatted = if (e.nick.isNotEmpty() && !e.nick.startsWith("@")) {
                    "@" + e.nick.replace("@", "")
                } else e.nick
                val valNick = validador.validarNick(formatted)
                uiState = uiState.copy(
                    nick = formatted,
                    mensajeError = null,
                    validacion = uiState.validacion.copy(validacionNick = valNick)
                )
            }

            is RegistroEvent.OnContrasenaCambiado -> {
                val valPass = validador.validadorContrasena.valida(e.contrasena)
                val valConfirm = validador.validarConfirmarContrasena(e.contrasena, uiState.confirmarContrasena)
                uiState = uiState.copy(
                    contrasena = e.contrasena,
                    mensajeError = null,
                    validacion = uiState.validacion.copy(
                        validacionContrasena = valPass,
                        validacionConfirmarContrasena = valConfirm
                    )
                )
            }

            is RegistroEvent.OnConfirmarContrasenaCambiado -> {
                val valConfirm = validador.validarConfirmarContrasena(uiState.contrasena, e.confirmar)
                uiState = uiState.copy(
                    confirmarContrasena = e.confirmar,
                    mensajeError = null,
                    validacion = uiState.validacion.copy(validacionConfirmarContrasena = valConfirm)
                )
            }

            is RegistroEvent.OnTerminosCambiado -> {
                val valTerm = validador.validarTerminos(e.aceptados)
                uiState = uiState.copy(
                    terminosAceptados = e.aceptados,
                    validacion = uiState.validacion.copy(validacionTerminos = valTerm)
                )
            }

            RegistroEvent.OnRegistrarClick -> {
                registrarColeccionista()
            }

            RegistroEvent.OnIniciarSesionClick -> {

            }

            RegistroEvent.OnErrorDescartado -> {
                uiState = uiState.copy(mensajeError = null)
            }
        }
    }

    private fun registrarColeccionista() {
        val validacionTotal = validador.valida(uiState)
        if (validacionTotal.hayError) {
            uiState = uiState.copy(
                validacion = validacionTotal,
                mensajeError = validacionTotal.mensajeError
            )
            return
        }

        viewModelScope.launch {
            uiState = uiState.copy(cargando = true, mensajeError = null)
            val existente = usuarioRepository.getUsuarioPorCorreo(uiState.correo.trim())
            if (existente != null) {
                uiState = uiState.copy(
                    cargando = false,
                    mensajeError = "Ya existe un curador registrado con este correo"
                )
                return@launch
            }

            val nuevoUsuario = Usuario(
                id = 0,
                correo = uiState.correo.trim(),
                nick = uiState.nick.trim(),
                contrasena = uiState.contrasena,
                recordarSesion = true
            )
            usuarioRepository.guardarUsuario(nuevoUsuario)
            uiState = uiState.copy(cargando = false, acreditadoConExito = true)

        }
    }
}
