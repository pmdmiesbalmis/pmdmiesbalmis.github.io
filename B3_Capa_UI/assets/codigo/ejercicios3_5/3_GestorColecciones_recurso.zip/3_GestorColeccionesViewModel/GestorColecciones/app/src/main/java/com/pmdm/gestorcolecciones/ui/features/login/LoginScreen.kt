package com.pmdm.gestorcolecciones.ui.features.login

import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.github.pmdmiesbalmis.components.ui.composables.CheckboxWithLabel
import com.github.pmdmiesbalmis.components.ui.composables.OutlinedTextFieldEmail
import com.github.pmdmiesbalmis.components.ui.composables.OutlinedTextFieldPassword
import com.github.pmdmiesbalmis.components.ui.composables.SnackbarError
import com.pmdm.gestorcolecciones.ui.theme.GestorColeccionesTheme
import com.pmdm.gestorcolecciones.ui.theme.GlacierPrimary
import com.pmdm.gestorcolecciones.ui.theme.GlacierSecondary

@Composable
fun LoginScreen(
    uiState: LoginUiState,
    onLoginEvent: (LoginEvent) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            EncabezadoLogin()

            Spacer(modifier = Modifier.height(24.dp))

            TarjetaFormularioLogin(uiState = uiState, onLoginEvent = onLoginEvent)

            Spacer(modifier = Modifier.height(16.dp))

            PieLogin(onLoginEvent = onLoginEvent)
        }

        uiState.mensajeError?.let { msg ->
            SnackbarErrorLogin(
                mensajeError = msg,
                onDismissError = { onLoginEvent(LoginEvent.OnErrorDescartado) },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
private fun EncabezadoLogin() {
    Box(
        modifier = Modifier
            .size(64.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .border(1.dp, GlacierSecondary.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Security,
            contentDescription = null,
            tint = GlacierSecondary,
            modifier = Modifier.size(34.dp)
        )
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
        text = "Acceso al Archivo",
        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
        text = "Ingresa tus credenciales para acceder a la colección.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(horizontal = 16.dp)
    )
}

@Composable
private fun TarjetaFormularioLogin(
    uiState: LoginUiState,
    onLoginEvent: (LoginEvent) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        border = BorderStroke(1.dp, GlacierSecondary.copy(alpha = 0.15f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextFieldEmail(
                modifier = Modifier.fillMaxWidth(),
                label = "Correo Electrónico",
                emailState = uiState.correo,
                validacionState = uiState.validacion.validacionCorreo,
                onValueChange = { onLoginEvent(LoginEvent.OnCorreoCambiado(it)) }
            )

            OutlinedTextFieldPassword(
                modifier = Modifier.fillMaxWidth(),
                passwordState = uiState.contrasena,
                validacionState = uiState.validacion.validacionContrasena,
                onValueChange = { onLoginEvent(LoginEvent.OnContrasenaCambiado(it)) },
                label = "Clave de Acceso"
            )

            CheckboxWithLabel(
                label = "Recordar sesión",
                modifier = Modifier.fillMaxWidth(),
                checkedState = uiState.recordarSesion,
                onStateChange = { onLoginEvent(LoginEvent.OnRecordarSesionCambiado(it)) }
            )

            Button(
                onClick = { onLoginEvent(LoginEvent.OnIniciarSesionClick) },
                enabled = !uiState.cargando,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GlacierPrimary,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                if (uiState.cargando) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Ingresar a mi Colección",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        }
    }
}

@Composable
private fun PieLogin(
    onLoginEvent: (LoginEvent) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "¿No tiene credenciales de acceso?",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        TextButton(
            onClick = { onLoginEvent(LoginEvent.OnRegistrarseClick) }
        ) {
            Text(
                text = "Solicitar Acreditación",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                color = GlacierSecondary
            )
        }
    }
}

@Composable
private fun SnackbarErrorLogin(
    mensajeError: String,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        SnackbarError(
            mensajeError = mensajeError,
            onDismissError = onDismissError
        )
    }
}

@Preview(showBackground = true)
@Composable
fun VistaPreviaPantallaLogin() {
    GestorColeccionesTheme {
        LoginScreen(
            uiState = LoginUiState(correo = "pepe@colectionist.art"),
            onLoginEvent = {}
        )
    }
}
