package com.pmdm.gestorcolecciones.data


import com.pmdm.gestorcolecciones.data.mocks.UsuarioDaoMock
import com.pmdm.gestorcolecciones.model.Usuario



class UsuarioRepository (

) {
    private var usuarioDaoMock: UsuarioDaoMock= UsuarioDaoMock()
    fun getUsuarioPorCorreo(correo: String): Usuario? {
        return usuarioDaoMock.getPorCorreo(correo)?.aUsuario()
    }

    fun guardarUsuario(usuario: Usuario) {
        usuarioDaoMock.insert(usuario.aUsuarioMock())
    }

    fun actualizarUsuario(usuario: Usuario) {
        usuarioDaoMock.update(usuario.aUsuarioMock())
    }

    fun getSesionActiva(): Usuario? {
        return usuarioDaoMock.getSesionActiva()?.aUsuario()
    }

    fun countUsuarios(): Int {
        return usuarioDaoMock.count()
    }
}
