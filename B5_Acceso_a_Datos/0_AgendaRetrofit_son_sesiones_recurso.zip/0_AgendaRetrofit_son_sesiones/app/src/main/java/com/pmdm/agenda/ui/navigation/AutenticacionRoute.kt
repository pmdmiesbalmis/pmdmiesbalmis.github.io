package com.pmdm.agenda.ui.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.compose.composable
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionScreen
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionViewModel

const val AutenticacionGraphRoute = "autenticacion"

fun NavController.navigateToAutenticacion(navOptions: NavOptions? = null) {
    this.navigate(AutenticacionGraphRoute, navOptions)
}

fun NavGraphBuilder.autenticacionScreen(
    vm : AutenticacionViewModel,
    onNavigateTrasLogin: () -> Unit
) {
    composable(
        route = AutenticacionGraphRoute,
        arguments = emptyList()
    ) {
        AutenticacionScreen(
            autenticacionUiState = vm.autenticacionUiState,
            informacionEstadoState = vm.informacionEstadoState,
            validationAutenticacionUiState = vm.validacionAutenticacionUiState,
            onAutenicacionEvent = vm::onAutenticacionEvent,
            onNavigateTrasLogin = onNavigateTrasLogin
        )
    }
}