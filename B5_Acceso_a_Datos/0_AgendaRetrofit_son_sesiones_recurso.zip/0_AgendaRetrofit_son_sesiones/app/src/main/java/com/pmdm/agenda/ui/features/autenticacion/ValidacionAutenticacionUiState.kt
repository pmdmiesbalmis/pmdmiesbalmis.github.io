package com.pmdm.agenda.ui.features.autenticacion

import com.pmdm.agenda.utilities.validacion.Validacion
import com.pmdm.agenda.utilities.validacion.ValidacionCompuesta

data class ValidacionAutenticacionUiState(
    val validacionUserName: Validacion = object : Validacion {},
    val validacionPassword: Validacion = object : Validacion {},
) : Validacion {
    private var validacionCompuesta: ValidacionCompuesta? = null

    private fun componerValidacion(): ValidacionCompuesta {
        validacionCompuesta = ValidacionCompuesta()
            .add(validacionUserName)
            .add(validacionPassword)
        return validacionCompuesta!!
    }

    override val hayError: Boolean
        get() = validacionCompuesta?.hayError ?: componerValidacion().hayError
    override val mensajeError: String?
        get() = validacionCompuesta?.mensajeError ?: componerValidacion().mensajeError
}
