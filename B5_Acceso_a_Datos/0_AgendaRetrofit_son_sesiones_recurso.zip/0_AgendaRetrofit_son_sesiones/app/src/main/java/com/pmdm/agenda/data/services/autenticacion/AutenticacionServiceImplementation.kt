package com.pmdm.agenda.data.services.autenticacion

import android.util.Log
import com.pmdm.agenda.data.services.ApiServicesException
import javax.inject.Inject

class AutenticacionServiceImplementation @Inject constructor(
    private val autenticacionService: AutenticacionService
) {
    private val logTag: String = "OkHttp"

    suspend fun login(
        userName : String,
        password : String
    ): RespuestaAutenticacionApi {
        val mensajeError = "Error al loguear a $userName"
        try {
            val response = autenticacionService.login(
                usuario = userName,
                password = password
            )
            if (response.isSuccessful) {
                Log.d(logTag, response.toString())
                val dato = response.body()
                return dato ?: throw ApiServicesException("No hay datos")
            } else {
                val body = response.errorBody()?.string()
                Log.e(logTag, "$mensajeError (código ${response.code()}): $this\n${body}")
                throw ApiServicesException(mensajeError)
            }
        } catch (e: Exception) {
            Log.e(logTag, "Error: ${e.localizedMessage}")
            throw ApiServicesException(mensajeError)
        }
    }

    suspend fun logout(): RespuestaAutenticacionApi {
        val mensajeError = "Error al cerrar sesión"
        try {
            val response = autenticacionService.logout()
            if (response.isSuccessful) {
                Log.d(logTag, response.toString())
                val dato = response.body()
                return dato ?: throw ApiServicesException("No hay datos")
            } else {
                val body = response.errorBody()?.string()
                Log.e(logTag, "$mensajeError (código ${response.code()}): $this\n${body}")
                throw ApiServicesException(mensajeError)
            }
        } catch (e: Exception) {
            Log.e(logTag, "Error: ${e.localizedMessage}")
            throw ApiServicesException(mensajeError)
        }
    }
}