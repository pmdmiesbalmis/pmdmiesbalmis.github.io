package com.pmdm.agenda.ui.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.pmdm.agenda.ui.features.formcontacto.ContactoViewModel
import com.pmdm.agenda.ui.features.formcontacto.FormContactoScreen

private const val FormContactoGraphRoute = "form_contacto"
private const val FormContactoParameterName = "idContacto"

fun NavController.navigateToEditarContacto(
    idContacto: Int,
    navOptions: NavOptions? = null) {
    this.navigate("$FormContactoGraphRoute/$idContacto", navOptions)
}

fun NavController.navigateToCrearContacto(
    navOptions: NavOptions? = null) {
    this.navigate("$FormContactoGraphRoute/-1", navOptions)
}

fun NavGraphBuilder.formContactosScreen(
    vm : ContactoViewModel,
    onNavigateTrasFormContacto: (actualizaContactos : Boolean) -> Unit
) {
    composable(
        route = "$FormContactoGraphRoute/{$FormContactoParameterName}",
        arguments = listOf(
            navArgument(FormContactoParameterName) {
                type = NavType.IntType
            }
        )
    ) { backStackEntry ->
        val idContacto :Int? = backStackEntry.arguments?.getInt(FormContactoParameterName, -1)
        if (idContacto != null
            && idContacto != -1
            && vm.contactoState.id != idContacto) {
            vm.setContactoState(idContacto!!)
        }

        FormContactoScreen(
            contactoState = vm.contactoState,
            validacionContactoState = vm.validacionContactoState,
            informacionEstado = vm.informacionEstadoState,
            onContactoEvent = vm::onContactoEvent,
            onNavigateTrasFormContacto = onNavigateTrasFormContacto
        )
    }
}