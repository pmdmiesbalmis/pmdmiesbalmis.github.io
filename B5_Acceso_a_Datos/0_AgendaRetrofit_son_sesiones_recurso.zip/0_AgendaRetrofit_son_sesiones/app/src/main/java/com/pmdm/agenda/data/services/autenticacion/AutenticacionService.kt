package com.pmdm.agenda.data.services.autenticacion

import retrofit2.Response
import retrofit2.http.*

interface AutenticacionService {
    @GET(".")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun login(
        @Query("usu") usuario : String,
        @Query("pass") password : String): Response<RespuestaAutenticacionApi>

    @GET(".")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun logout(
        @Query("logout") usuario : String = ""): Response<RespuestaAutenticacionApi>
}