package com.pmdm.agenda.ui.navigation

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionViewModel
import com.pmdm.agenda.ui.features.formcontacto.ContactoViewModel
import com.pmdm.agenda.ui.features.vercontactos.ListaContactosViewModel

@Composable
fun AgendaNavHost() {
    val navController = rememberNavController()
    val vmAuth = hiltViewModel<AutenticacionViewModel>()
    val vmLc = hiltViewModel<ListaContactosViewModel>()
    val vmFc = hiltViewModel<ContactoViewModel>()

    NavHost(
        navController = navController,
        startDestination = AutenticacionGraphRoute
    ) {
        autenticacionScreen(
            vm = vmAuth,
            onNavigateTrasLogin = {
                navController.navigateToListaContactos()
                // No puedo cargar contactos hasta que no me haya autenticado,
                vmLc.cargaContactos()
            }
        )
        listaContactosScreen(
            vm = vmLc,
            vmAuth = vmAuth,
            onNavigateTrasLogout = {
                navController.navigate(AutenticacionGraphRoute) {
                    popUpTo(AutenticacionGraphRoute) {
                        inclusive = false
                    }
                }
            },
            onNavigateCrearContacto = {
                vmFc.clearContactoState()
                navController.navigateToCrearContacto()
            },
            onNavigateEditarContacto = { idContacto ->
                vmFc.clearContactoState()
                navController.navigateToEditarContacto(idContacto)
            }
        )
        formContactosScreen(
            vm = vmFc,
            onNavigateTrasFormContacto = { actualizaContactos ->
                navController.popBackStack()
                if (actualizaContactos) {
                    vmLc.cargaContactos()
                }
            }
        )
    }
}