package com.pmdm.agenda.ui.navigation

import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.compose.composable
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionEvent
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionViewModel
import com.pmdm.agenda.ui.features.vercontactos.ItemListaContactosEvent
import com.pmdm.agenda.ui.features.vercontactos.ListaContactosScreen
import com.pmdm.agenda.ui.features.vercontactos.ListaContactosViewModel

const val ListaContactosGraphRoute = "lista_contactos"

fun NavController.navigateToListaContactos(navOptions: NavOptions? = null) {
    this.navigate(ListaContactosGraphRoute, navOptions)
}

fun NavGraphBuilder.listaContactosScreen(
    vm : ListaContactosViewModel,
    vmAuth : AutenticacionViewModel,
    onNavigateTrasLogout: () -> Unit,
    onNavigateCrearContacto: () -> Unit,
    onNavigateEditarContacto: (idContacto: Int) -> Unit
) {
    composable(
        route = ListaContactosGraphRoute,
        arguments = emptyList()
    ) {
        ListaContactosScreen(
            contactosState = vm.contactosState,
            contactoSeleccionadoState = vm.contatoSleccionadoState,
            filtradoActivoState = vm.filtradoActivoState,
            filtroCategoriaState = vm.filtroCategoriaState,
            informacionEstadoState = vm.informacionEstadoState,
            onActualizaContactos =  { vm.cargaContactos() },
            onLogout = {
                vmAuth.onAutenticacionEvent(AutenticacionEvent.OnLogoutPulsado(onNavigateTrasLogout))
            },
            onActivarFiltradoClicked = { vm.onActivarFiltradoClicked() },
            onFiltroModificado = { categorias -> vm.onFiltroModificado(categorias) },
            onContactoClicked = { c ->
                vm.onItemListaContatoEvent(ItemListaContactosEvent.OnClickContacto(c))
            },
            onAddClicked = {
                vm.onItemListaContatoEvent(
                    ItemListaContactosEvent.OnCrearContacto(
                        onNavigateCrearContacto
                    )
                )
            },
            onEditClicked = {
                vm.onItemListaContatoEvent(
                    ItemListaContactosEvent.OnEditContacto(
                        onNavigateEditarContacto
                    )
                )
            },
            onDeleteClicked = {
                vm.onItemListaContatoEvent(ItemListaContactosEvent.OnDeleteContacto)
            }
        )
    }
}