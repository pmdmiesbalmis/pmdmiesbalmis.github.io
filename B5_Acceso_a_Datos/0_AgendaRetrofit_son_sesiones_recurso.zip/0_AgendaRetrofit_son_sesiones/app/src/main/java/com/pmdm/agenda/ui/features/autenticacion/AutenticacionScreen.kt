package com.pmdm.agenda.ui.features.autenticacion

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pmdm.agenda.R
import com.pmdm.agenda.ui.composables.CorrutinaGestionSnackBar
import com.pmdm.agenda.ui.composables.OutlinedTextFieldPassword
import com.pmdm.agenda.ui.composables.OutlinedTextFieldWithErrorState
import com.pmdm.agenda.ui.composables.SnackbarCommon
import com.pmdm.agenda.ui.theme.AgendaTheme
import com.pmdm.agenda.utilities.manejo_errores.InformacionEstadoUiState
import com.pmdm.agenda.utilities.validacion.Validacion

@Composable
fun FormUserYPassword(
    userNameState: String,
    userNameValidationState: Validacion,
    passwordState: String,
    passwordValidationState: Validacion,
    onUsuarioCambiado: (String) -> Unit,
    onPasswordCambiado: (String) -> Unit,
    onBotonLoginPulsado: () -> Unit
) {
    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
    ) {

        Text(
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 16.dp),
            style = MaterialTheme.typography.titleLarge,
            text = "Introduce tus credenciales"
        )

        OutlinedTextFieldWithErrorState(
            modifier = Modifier.fillMaxWidth(),
            label = "Usuario",
            textoState = userNameState,
            validacionState = userNameValidationState,
            onValueChange = onUsuarioCambiado
        )

        OutlinedTextFieldPassword(
            modifier = Modifier.fillMaxWidth(),
            label = "Clave",
            passwordState = passwordState,
            validacionState = passwordValidationState,
            onValueChange = onPasswordCambiado
        )

        Button(
            onClick = onBotonLoginPulsado,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Verificar")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormAutenticacionTopAppBar(
    scrollBehavior: TopAppBarScrollBehavior = TopAppBarDefaults.pinnedScrollBehavior(),
) {
    CenterAlignedTopAppBar(
        scrollBehavior = scrollBehavior,
        title = {
            Text(text = stringResource(id = R.string.app_name))
        }
    )
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutenticacionScreen(
    autenticacionUiState: AutenticacionUiState,
    validationAutenticacionUiState: ValidacionAutenticacionUiState,
    informacionEstadoState: InformacionEstadoUiState,
    onAutenicacionEvent: (AutenticacionEvent) -> Unit,
    onNavigateTrasLogin: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }

    CorrutinaGestionSnackBar(
        informacionEstado = informacionEstadoState,
        snackbarHostState = snackbarHostState
    )

    Scaffold(
        modifier = Modifier.padding(12.dp),
        topBar = { FormAutenticacionTopAppBar() },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) {
                SnackbarCommon(informacionEstado = informacionEstadoState)
            }
        }
    )
    {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(it),
            contentAlignment = Alignment.Center
        ) {
            FormUserYPassword(
                userNameState = autenticacionUiState.userName,
                userNameValidationState = validationAutenticacionUiState.validacionUserName,
                passwordState = autenticacionUiState.password,
                passwordValidationState = validationAutenticacionUiState.validacionPassword,
                onUsuarioCambiado = { onAutenicacionEvent(AutenticacionEvent.OnChangeUserName(it)) },
                onPasswordCambiado = { onAutenicacionEvent(AutenticacionEvent.OnChangePassword(it)) },
                onBotonLoginPulsado = {
                    onAutenicacionEvent(
                        AutenticacionEvent.OnLoginPulsado(
                            autenticacionUiState.userName,
                            autenticacionUiState.password,
                            onNavigateTrasLogin
                        )
                    )
                }
            )
        }
    }
}

@Preview(
    name = "PORTRAIT",
    device = "spec:width=360dp,height=800dp,dpi=480",
    showBackground = true
)
@Composable
fun AutenticacionScreenTest() {

    var autenticacionState by remember { mutableStateOf(AutenticacionUiState()) }
    var InformacionEstadoUiState by remember { mutableStateOf(InformacionEstadoUiState.Oculta()) }
    var validationAutenticacionState by remember { mutableStateOf(ValidacionAutenticacionUiState()) }

    AgendaTheme {
        AutenticacionScreen(
            autenticacionUiState = autenticacionState,
            informacionEstadoState = InformacionEstadoUiState,
            validationAutenticacionUiState = validationAutenticacionState,
            onAutenicacionEvent = {},
            onNavigateTrasLogin = {}
        )
    }
}
