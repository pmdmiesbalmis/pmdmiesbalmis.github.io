package com.pmdm.agenda.data.services.contactos

import com.pmdm.agenda.data.services.RespuestaApi
import com.pmdm.agenda.data.services.TotalRegistrosApi
import retrofit2.Response
import retrofit2.http.*

interface ContactoService {
    @GET("contactos")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun contactos(): Response<List<ContactoApi>>

    // Caso especial del API REST de Vicente Rico con php
    // en lugar de devolver un único objeto, devuelve un array con un único objeto
    @GET("contactos/{id}")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun contacto(@Path("id") id: Int): Response<List<ContactoApi>>

    @GET("contactos/count")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun count(): Response<TotalRegistrosApi>

    @POST("contactos")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun insert(@Body c : ContactoApi): Response<RespuestaApi>

    @PUT("contactos/{id}")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun update(@Path("id") id: Int, @Body c : ContactoApi): Response<RespuestaApi>

    @DELETE("contactos/{id}")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun delete(@Path("id") id: Int): Response<RespuestaApi>
}