package com.pmdm.agenda.data.services.interceptors

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AlmacenDeCookies @Inject constructor() {
    private var cookies: HashSet<String>? = null
    fun getCookies(): HashSet<String>?  = cookies
    fun setCookies(cookies: HashSet<String>) {
        this.cookies = cookies
    }
}