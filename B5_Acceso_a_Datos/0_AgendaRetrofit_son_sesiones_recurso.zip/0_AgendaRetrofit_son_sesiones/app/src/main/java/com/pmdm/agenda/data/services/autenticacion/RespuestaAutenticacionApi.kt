package com.pmdm.agenda.data.services.autenticacion

data class RespuestaAutenticacionApi(
    val mensaje : String,
    val usuario : String
)
