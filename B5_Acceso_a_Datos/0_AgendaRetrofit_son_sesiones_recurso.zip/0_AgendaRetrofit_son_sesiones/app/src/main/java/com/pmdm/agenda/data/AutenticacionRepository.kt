package com.pmdm.agenda.data

import com.pmdm.agenda.data.services.autenticacion.AutenticacionServiceImplementation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class AutenticacionRepository @Inject constructor(
    private val autenticacionService: AutenticacionServiceImplementation
) {
    suspend fun login(
        userName: String,
        password: String
    ): Boolean = withContext(Dispatchers.IO) {
        autenticacionService.login(
            userName = userName,
            password = password
        ).usuario.isNotEmpty()
    }

    suspend fun logout(): Unit = withContext(Dispatchers.IO) {
        autenticacionService.logout()
    }
}