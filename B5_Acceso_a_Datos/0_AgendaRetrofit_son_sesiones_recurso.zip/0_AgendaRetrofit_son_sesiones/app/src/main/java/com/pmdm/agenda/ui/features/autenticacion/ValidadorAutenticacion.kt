package com.pmdm.agenda.ui.features.autenticacion

import com.pmdm.agenda.utilities.validacion.Validador
import com.pmdm.agenda.utilities.validacion.ValidadorCompuesto
import com.pmdm.agenda.utilities.validacion.validadores.ValidadorLongitudMaximaTexto
import com.pmdm.agenda.utilities.validacion.validadores.ValidadorLongitudMinimaTexto
import com.pmdm.agenda.utilities.validacion.validadores.ValidadorPassword
import com.pmdm.agenda.utilities.validacion.validadores.ValidadorTextoNoVacio
import javax.inject.Inject

class ValidadorAutenticacion @Inject constructor() : Validador<AutenticacionUiState> {
    val validadorUserName = ValidadorCompuesto<String>()
        .add(ValidadorTextoNoVacio("El usuario puede estar vacío"))
        .add(ValidadorLongitudMinimaTexto(4))
        .add(ValidadorLongitudMaximaTexto(20))
    val validadorPassword = ValidadorCompuesto<String>()
        .add(ValidadorPassword())

    override fun valida(credenciales : AutenticacionUiState): ValidacionAutenticacionUiState {
        val validacionUserName = validadorUserName.valida(credenciales.userName)
        val validacionPassword = validadorPassword.valida(credenciales.password)

        return ValidacionAutenticacionUiState(
            validacionUserName = validacionUserName,
            validacionPassword = validacionPassword
        )
    }
}