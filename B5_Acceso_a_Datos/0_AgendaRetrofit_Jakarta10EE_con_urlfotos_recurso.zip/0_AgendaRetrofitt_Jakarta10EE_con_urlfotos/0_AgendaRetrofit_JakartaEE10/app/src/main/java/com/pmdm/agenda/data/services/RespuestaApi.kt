package com.pmdm.agenda.data.services

data class RespuestaApi (
    val mensaje: String? = null,
)