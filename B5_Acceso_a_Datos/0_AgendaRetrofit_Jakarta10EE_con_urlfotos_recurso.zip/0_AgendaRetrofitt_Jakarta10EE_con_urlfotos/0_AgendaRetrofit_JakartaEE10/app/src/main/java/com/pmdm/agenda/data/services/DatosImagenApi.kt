package com.pmdm.agenda.data.services

data class DatosImagenApi (
    val extension: String = "png",
    val base64Image: String?
)