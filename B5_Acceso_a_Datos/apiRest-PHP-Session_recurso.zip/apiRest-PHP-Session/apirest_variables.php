<?php

	// CONFIGURACIÓN BASE DE DATOS MYSQL
	$servername = "127.0.0.1";
	$username = "root";
	$password = "";
	
	// BASE DE DATOS
	$dbname = "agenda";

	// ACCESO USUARIOS (si está vacío funciona sin usuarios)
	$usuarios = array();
    // $usuarios["juanjo"]="_IesBalmis1";
    // $usuarios["xusa"]="_IesBalmis2";
    // $usuarios["pepe"]="_IesBalmis3";
	
	// TABLAS Y SU CLAVE
	$tablas = array();
	$tablas["contactos"]="id";
	
	


