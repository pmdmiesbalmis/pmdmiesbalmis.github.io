package com.pmdm.agenda.data.services
class ApiServicesException(mensaje: String) : Exception(mensaje)
