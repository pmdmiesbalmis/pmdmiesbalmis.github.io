package com.pmdm.agenda.data.services

import retrofit2.Response
import retrofit2.http.*

interface ContactoService {
    @GET("contactos")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun contactos(): Response<List<ContactoApi>>

    @GET("contactos/{id}")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun contacto(@Path("id") id: Int): Response<ContactoApi>

    @GET("contactos/count")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun count(): Response<TotalRegistrosApi>

    @POST("contactos")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun insert(@Body c : ContactoApi): Response<RespuestaApi>

    @PUT("contactos/{id}")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun update(@Path("id") id: Int, @Body c : ContactoApi): Response<RespuestaApi>

    @DELETE("contactos/{id}")
    @Headers("Accept: application/json", "Content-Type: application/json")
    suspend fun delete(@Path("id") id: Int): Response<RespuestaApi>
}