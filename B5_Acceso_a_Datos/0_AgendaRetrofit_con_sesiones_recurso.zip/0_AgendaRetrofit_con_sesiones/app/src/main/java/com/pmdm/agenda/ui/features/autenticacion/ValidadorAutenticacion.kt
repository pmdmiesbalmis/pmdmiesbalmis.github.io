package com.pmdm.agenda.ui.features.autenticacion

import com.github.pmdmiesbalmis.components.validacion.Validador
import com.github.pmdmiesbalmis.components.validacion.ValidadorCompuesto
import com.github.pmdmiesbalmis.components.validacion.validadores.ValidadorLongitudMaximaTexto
import com.github.pmdmiesbalmis.components.validacion.validadores.ValidadorLongitudMinimaTexto
import com.github.pmdmiesbalmis.components.validacion.validadores.ValidadorPassword
import com.github.pmdmiesbalmis.components.validacion.validadores.ValidadorTextoNoVacio
import javax.inject.Inject

class ValidadorAutenticacion @Inject constructor() : Validador<AutenticacionUiState> {
    val validadorUserName = ValidadorCompuesto<String>()
        .add(ValidadorTextoNoVacio("El usuario puede estar vacío"))
        .add(ValidadorLongitudMinimaTexto(4))
        .add(ValidadorLongitudMaximaTexto(20))
    val validadorPassword = ValidadorCompuesto<String>()
        .add(ValidadorPassword())

    override fun valida(credenciales : AutenticacionUiState): ValidacionAutenticacionUiState {
        val validacionUserName = validadorUserName.valida(credenciales.userName)
        val validacionPassword = validadorPassword.valida(credenciales.password)

        return ValidacionAutenticacionUiState(
            validacionUserName = validacionUserName,
            validacionPassword = validacionPassword
        )
    }
}