package com.pmdm.agenda.ui.features.autenticacion

data class AutenticacionUiState(
    val autenticado: Boolean = false,
    val userName: String = "",
    val password: String = ""
)
