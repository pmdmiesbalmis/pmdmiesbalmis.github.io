package com.pmdm.agenda.ui.features.autenticacion

sealed class AutenticacionEvent {
    data class OnChangeUserName(val userName: String) : AutenticacionEvent()
    data class OnChangePassword(val password: String) : AutenticacionEvent()
    data class OnLoginPulsado(val userName: String, val password: String, val onNavigateTrasLogin: () -> Unit) : AutenticacionEvent()
    data class OnLogoutPulsado(val onNavigateTrasLogout: () -> Unit) : AutenticacionEvent()
}
