package com.pmdm.agenda.ui.features.autenticacion

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pmdm.agenda.data.AutenticacionRepository
import com.github.pmdmiesbalmis.components.manejo_errores.InformacionEstadoUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AutenticacionViewModel @Inject constructor(
    private val autenticacionRepository: AutenticacionRepository,
    private val validadorAutenticacion: ValidadorAutenticacion
) : ViewModel() {
    var autenticacionUiState by mutableStateOf(AutenticacionUiState())
        private set
    var validacionAutenticacionUiState by mutableStateOf(ValidacionAutenticacionUiState())
        private set
    var informacionEstadoState: InformacionEstadoUiState by mutableStateOf(InformacionEstadoUiState.Oculta())
        private set

    fun onAutenticacionEvent(e: AutenticacionEvent) {
        when (e) {
            is AutenticacionEvent.OnChangeUserName -> {
                autenticacionUiState = autenticacionUiState.copy(
                    userName = e.userName,
                )
                validacionAutenticacionUiState = validacionAutenticacionUiState.copy(
                    validacionUserName = validadorAutenticacion.validadorUserName.valida(e.userName)
                )
            }

            is AutenticacionEvent.OnChangePassword -> {
                autenticacionUiState = autenticacionUiState.copy(
                    password = e.password,
                )
                validacionAutenticacionUiState = validacionAutenticacionUiState.copy(
                    validacionPassword = validadorAutenticacion.validadorPassword.valida(e.password)
                )
            }

            is AutenticacionEvent.OnLogoutPulsado -> {
                viewModelScope.launch {
                    try {
                        informacionEstadoState = InformacionEstadoUiState.Informacion(
                            mensaje = "Cerrando sesión ...",
                            muestraProgreso = true
                        )
                        autenticacionRepository.logout()
                        informacionEstadoState = InformacionEstadoUiState.Oculta()
                    } catch (e: Exception) {
                        Log.d("AutenticacionViewModel", "Cerrando sesión: ${e.localizedMessage}")
                        informacionEstadoState = InformacionEstadoUiState.Error(
                            mensaje = "Error cerrando sesión remota.",
                            onDismiss = {
                                informacionEstadoState = InformacionEstadoUiState.Oculta()
                            }
                        )
                    } finally {
                        autenticacionUiState = AutenticacionUiState()
                        e.onNavigateTrasLogout()
                    }
                }
            }

            is AutenticacionEvent.OnLoginPulsado -> {
                validacionAutenticacionUiState = validadorAutenticacion.valida(autenticacionUiState)
                if (!validacionAutenticacionUiState.hayError) {
                    viewModelScope.launch {
                        try {
                            informacionEstadoState = InformacionEstadoUiState.Informacion(
                                mensaje = "Autenticando credenciales...",
                                muestraProgreso = true
                            )
                            val autenticado = autenticacionRepository.login(
                                autenticacionUiState.userName,
                                autenticacionUiState.password
                            )

                            if (autenticado) {
                                autenticacionUiState =
                                    autenticacionUiState.copy(autenticado = autenticado)
                                e.onNavigateTrasLogin()
                                informacionEstadoState = InformacionEstadoUiState.Oculta()
                            }
                            else {
                                informacionEstadoState = InformacionEstadoUiState.Error(
                                    mensaje = "Credenciales incorrectas.",
                                    onDismiss = {
                                        informacionEstadoState = InformacionEstadoUiState.Oculta()
                                    }
                                )
                            }
                        } catch (e: Exception) {
                            Log.d("AutenticacionViewModel", "Logging out: ${e.localizedMessage}")
                            informacionEstadoState = InformacionEstadoUiState.Error(
                                mensaje = "Error al hacer logout remoto.",
                                onDismiss = {
                                    informacionEstadoState = InformacionEstadoUiState.Oculta()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
