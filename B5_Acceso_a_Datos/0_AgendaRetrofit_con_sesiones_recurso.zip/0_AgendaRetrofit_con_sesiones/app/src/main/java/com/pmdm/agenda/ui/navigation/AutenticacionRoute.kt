package com.pmdm.agenda.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionScreen
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionViewModel
import kotlinx.serialization.Serializable

@Serializable
object AutenticacionRoute

fun NavGraphBuilder.autenticacionDestination(
    vmAuth : AutenticacionViewModel,
    onNavigateTrasLogin : () -> Unit,
) {
    composable<AutenticacionRoute> {
        AutenticacionScreen(
            autenticacionUiState = vmAuth.autenticacionUiState,
            informacionEstadoState = vmAuth.informacionEstadoState,
            validationAutenticacionUiState = vmAuth.validacionAutenticacionUiState,
            onAutenicacionEvent = vmAuth::onAutenticacionEvent,
            onNavigateTrasLogin = onNavigateTrasLogin
        )
    }
}