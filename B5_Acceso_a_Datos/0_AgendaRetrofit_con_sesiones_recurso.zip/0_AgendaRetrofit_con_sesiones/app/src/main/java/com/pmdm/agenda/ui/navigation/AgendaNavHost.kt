package com.pmdm.agenda.ui.navigation

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionViewModel
import com.pmdm.agenda.ui.features.formcontacto.ContactoViewModel
import com.pmdm.agenda.ui.features.vercontactos.ListaContactosViewModel

@Composable
fun AgendaNavHost() {
    val navController = rememberNavController()
    val vmAuth = hiltViewModel<AutenticacionViewModel>()
    val vmLc = hiltViewModel<ListaContactosViewModel>()
    val vmFc = hiltViewModel<ContactoViewModel>()

    NavHost(
        navController = navController,
        startDestination = AutenticacionRoute
    ) {
        autenticacionDestination(
            vmAuth = vmAuth,
            onNavigateTrasLogin = {
                navController.navigate(ListaContactosRoute)
                // No puedo cargar contactos hasta que no me haya autenticado,
                vmLc.cargaContactos()
            }
        )

        listaContactosDestination(
            vmLc = vmLc,
            vmAuth = vmAuth,
            onNavigateTrasLogout = {
                navController.navigate(AutenticacionRoute) {
                    popUpTo(AutenticacionRoute) {
                        inclusive = false
                    }
                }
            },
            onNavigateCrearContacto = {
                vmFc.clearContactoState()
                navController.navigate(FormContactoRoute())
            },
            onNavigateEditarContacto = { idContacto ->
                vmFc.clearContactoState()
                navController.navigate(FormContactoRoute(idContacto))
            }
        )

        formContactoDestination(
            vm = vmFc,
            onNavigateTrasFormContacto = { actualizaContactos ->
                navController.popBackStack()
                if (actualizaContactos) {
                    vmLc.cargaContactos()
                }
            }
        )
    }
}





