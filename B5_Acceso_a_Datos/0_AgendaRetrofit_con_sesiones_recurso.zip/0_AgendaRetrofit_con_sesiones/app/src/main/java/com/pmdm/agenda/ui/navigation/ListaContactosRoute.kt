package com.pmdm.agenda.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionEvent
import com.pmdm.agenda.ui.features.autenticacion.AutenticacionViewModel
import com.pmdm.agenda.ui.features.vercontactos.ItemListaContactosEvent
import com.pmdm.agenda.ui.features.vercontactos.ListaContactosScreen
import com.pmdm.agenda.ui.features.vercontactos.ListaContactosViewModel
import kotlinx.serialization.Serializable

@Serializable
object ListaContactosRoute

fun NavGraphBuilder.listaContactosDestination(
    vmLc : ListaContactosViewModel,
    vmAuth : AutenticacionViewModel,
    onNavigateTrasLogout: () -> Unit,
    onNavigateCrearContacto: () -> Unit,
    onNavigateEditarContacto: (idContacto: Int) -> Unit
) {
    composable<ListaContactosRoute> {
        ListaContactosScreen(
            contactosState = vmLc.contactosState,
            contactoSeleccionadoState = vmLc.contatoSleccionadoState,
            filtradoActivoState = vmLc.filtradoActivoState,
            filtroCategoriaState = vmLc.filtroCategoriaState,
            informacionEstadoState = vmLc.informacionEstadoState,
            onActualizaContactos =  { vmLc.cargaContactos() },
            onLogout = {
                vmAuth.onAutenticacionEvent(AutenticacionEvent.OnLogoutPulsado(onNavigateTrasLogout))
            },
            onActivarFiltradoClicked = { vmLc.onActivarFiltradoClicked() },
            onFiltroModificado = { categorias -> vmLc.onFiltroModificado(categorias) },
            onContactoClicked = { c ->
                vmLc.onItemListaContatoEvent(ItemListaContactosEvent.OnClickContacto(c))
            },
            onAddClicked = {
                vmLc.onItemListaContatoEvent(
                    ItemListaContactosEvent.OnCrearContacto(
                        onNavigateCrearContacto
                    )
                )
            },
            onEditClicked = {
                vmLc.onItemListaContatoEvent(
                    ItemListaContactosEvent.OnEditContacto(
                        onNavigateEditarContacto
                    )
                )
            },
            onDeleteClicked = {
                vmLc.onItemListaContatoEvent(ItemListaContactosEvent.OnDeleteContacto)
            }
        )
    }
}