package com.pmdm.recetas

import android.app.Application

class MyApplication: Application (){
}