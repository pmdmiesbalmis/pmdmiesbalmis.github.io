
package com.pmdm.tienda.ui.features.login

data class LoginUiState(
    val login: String,
    val password: String,
    val estaLogeado: Boolean,
    val likeds:MutableList<Int>
) {
    constructor() : this(
        login = "",
        password = "",
        estaLogeado=false,
        likeds= mutableListOf()
    )
}
