package com.pmdm.recetas.data.room

import android.graphics.Bitmap
import androidx.room.TypeConverter
import com.github.pmdmiesbalmis.utilities.imagetools.base64ToByteArray
import com.github.pmdmiesbalmis.utilities.imagetools.toBase64
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken



class RoomConverters {
    @TypeConverter
    fun toBlob(value: ByteArray?): String? = value?.toBase64()

    @TypeConverter
    fun fromBlob(value: String?): ByteArray? = value?.base64ToByteArray()

   @TypeConverter
        fun deListaDeEnterosAString(lista: List<Int>?): String {
            return Gson().toJson(lista)
        }
   @TypeConverter
        fun deStringAListaDeEnteros(cadena: String?): List<Int>? {
            val tipo = object : TypeToken<List<Int>>() {}.type
            return Gson().fromJson(cadena, tipo)
        }
}
