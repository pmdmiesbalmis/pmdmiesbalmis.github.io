package com.pmdm.recetas.ui.views

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import com.github.pmdmiesbalmis.utilities.imagetools.toBase64
import com.pmdm.recetas.R
import com.pmdm.recetas.models.Recipe
import com.pmdm.recetas.ui.features.recipe.RecipeScreen
import com.pmdm.recetas.ui.features.recipe.RecipeViewModel
import com.pmdm.recetas.ui.navigation.RecetasNavHost
import com.pmdm.recetas.ui.theme.RecetasTheme
import com.pmdm.tienda.ui.features.login.LoginViewModel
import dagger.hilt.EntryPoint
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
           recetas = inicializaBDRecetasEjemplo()
            RecetasTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {

                    RecetasNavHost()
                }
            }
        }
    }

    companion object {
        var recetas: MutableList<Recipe> = mutableListOf()
    }

    fun inicializaBDRecetasEjemplo(): MutableList<Recipe> {

        var recipes = mutableListOf(
            Recipe(
                id = 1,
                name = "Magdalenas de la abuela",
                description = "Fabulosas magdalenas con pepitas de chocolate y un suave sabor a naranja.",
                chef = "Carlos Arguiñano",
                photo = BitmapFactory.decodeResource(resources,R.drawable.magdalenas).asImageBitmap().toBase64(),
                likedsNumbers = 8,
            ),
            Recipe(
                id = 2,
                name = "Pan casero con tomates secos",
                description = "Novedoso pan casero con un estimulante sabor a tomates secos, perfecto para acompañar platos de cuchara",
                chef = "Carlos Arguiñano",
                photo = BitmapFactory.decodeResource(resources,R.drawable.panx).asImageBitmap().toBase64(),
                likedsNumbers = 3,
            ),
            Recipe(
                id = 3,
                name = "Ensalada multicolor con nueces",
                description = "Receta sencilla y rápida que dejará impresionados a todos tus invitados.",
                chef = "Sonia de la Oz",
                photo = BitmapFactory.decodeResource(resources,R.drawable.ensalada).asImageBitmap().toBase64(),
                likedsNumbers = 5,
            ),
            Recipe(
                id = 4,
                name = "Caldo de almendras, pasas y calabaza",
                description = "Estupenda sopa vegetal de invierno, con un sabor exótico inmejorable",
                chef = "Mohamed Aldalay",
                photo = null,
                likedsNumbers = 12,
            ),
        )
        return recipes
    }
}


