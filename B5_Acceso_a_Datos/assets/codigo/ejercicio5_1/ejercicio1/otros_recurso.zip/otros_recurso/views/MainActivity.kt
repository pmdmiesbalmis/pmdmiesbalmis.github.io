package com.pmdm.recetas.ui.views

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import com.pmdm.agenda.utilities.imagenes.Imagenes
import com.pmdm.recertas.ui.features.login.LoginScreen
import com.pmdm.recetas.models.Recipe
import com.pmdm.recetas.ui.features.recipe.RecipeScreen
import com.pmdm.recetas.ui.features.recipe.RecipeViewModel
import com.pmdm.recetas.ui.navigation.RecetasNavHost
import com.pmdm.recetas.ui.theme.RecetasTheme
import com.pmdm.tienda.ui.features.login.LoginViewModel
import dagger.hilt.EntryPoint
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            recetas = inicializaBDRecetasEjemplo()
            RecetasTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {

                    RecetasNavHost()
                }
            }
        }
    }

    companion object {
        var recetas: MutableList<Recipe> = mutableListOf()
    }

    fun inicializaBDRecetasEjemplo(): MutableList<Recipe> {
        val imageResource =
            resources.getIdentifier("magdalenas", "drawable", packageName)
        var recipes = mutableListOf(
            Recipe(
                id = 1,
                name = "Magdalenas de la abuela",
                description = "Fabulosas magdalenas con pepitas de chocolate y un suave sabor a naranja.",
                chef = "Carlos Arguiñano",
                photo = Imagenes.bitmapToBase64(
                    Imagenes.androidBitmapFromRerouceId(
                        resources.getIdentifier("magdalenas", "drawable", packageName),
                        this
                    ).asImageBitmap()
                ),
                likedsNumbers = 8,
            ),
            Recipe(
                id = 2,
                name = "Pan casero con tomates secos",
                description = "Novedoso pan casero con un estimulante sabor a tomates secos, perfecto para acompañar platos de cuchara",
                chef = "Carlos Arguiñano",
                photo = Imagenes.bitmapToBase64(
                    Imagenes.androidBitmapFromRerouceId(
                        resources.getIdentifier("panx", "drawable", packageName),
                        this
                    ).asImageBitmap()
                ),
                likedsNumbers = 3,
            ),
            Recipe(
                id = 3,
                name = "Ensalada multicolor con nueces",
                description = "Receta sencilla y rápida que dejará impresionados a todos tus invitados.",
                chef = "Sonia de la Oz",
                photo = Imagenes.bitmapToBase64(
                    Imagenes.androidBitmapFromRerouceId(
                        resources.getIdentifier("ensalada", "drawable", packageName),
                        this
                    ).asImageBitmap()
                ),
                likedsNumbers = 5,
            ),
            Recipe(
                id = 4,
                name = "Caldo de almendras, pasas y calabaza",
                description = "Estupenda sopa vegetal de invierno, con un sabor exótico inmejorable",
                chef = "Mohamed Aldalay",
                photo = null,
                likedsNumbers = 12,
            ),
        )
        return recipes
    }
}


