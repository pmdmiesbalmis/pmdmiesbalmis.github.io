package com.pmdm.agenda.data.room

import androidx.room.TypeConverter
import com.pmdm.agenda.utilities.imagenes.Imagenes

class RoomConverters {
    @TypeConverter
    fun toBlob(value: ByteArray?): String? = Imagenes.blobToBase64(value)

    @TypeConverter
    fun fromBlob(value: String?): ByteArray? = Imagenes.base64ToBlob(value)
}
