package com.pmdm.tienda.data.mocks.articulo

data class ArticuloMock(val id:Int, val url:String, val precio:Float, val descripcion:String)
