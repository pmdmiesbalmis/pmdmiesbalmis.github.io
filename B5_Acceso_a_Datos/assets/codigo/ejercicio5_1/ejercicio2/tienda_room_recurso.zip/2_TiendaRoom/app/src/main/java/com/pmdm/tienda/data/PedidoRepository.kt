package com.pmdm.tienda.data

import com.pmdm.tienda.data.mocks.pedido.ArticuloConPedidoMock
import com.pmdm.tienda.data.mocks.pedido.PedidoDaoMock
import com.pmdm.tienda.data.mocks.pedido.PedidoMock
import com.pmdm.tienda.data.room.pedido.PedidoDao
import com.pmdm.tienda.data.room.pedido.PedidoEntity
import com.pmdm.tienda.models.ArticuloDePedido
import com.pmdm.tienda.models.Pedido
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject


class PedidoRepository @Inject constructor(private val proveedorPedido: PedidoDaoMock) {


    fun get(): List<Pedido> = proveedorPedido.getPedidos().toPedidos()
    fun get(dniCliente:String): List<Pedido> = proveedorPedido.getPedidos(dniCliente).toPedidos()
    fun get(id: Long): Pedido? = proveedorPedido.getPedido(id)?.toPedido()
    fun insert(pedido: Pedido) = proveedorPedido.insert(
        pedido.toPedidoMock(),
        pedido.articulos.toList().toArticulosConPedidoMock(pedido.pedidoId)
    )

    fun numeroArticulos(id: Long) = proveedorPedido.getCantidadArticulosEnPedido(id)

    fun generarIdPedido()=(proveedorPedido.getPedidos().size+1).toLong()
    private fun PedidoMock.toPedido(): Pedido {
        val articulos = proveedorPedido.getArticulosPedido(this.pedidoId)
        return Pedido(
            this.pedidoId,
            this.dniCliente,
            this.total,
            this.fecha,
            articulos.toArticuloDePedido(this.pedidoId).toMutableList()
        )
    }

}
