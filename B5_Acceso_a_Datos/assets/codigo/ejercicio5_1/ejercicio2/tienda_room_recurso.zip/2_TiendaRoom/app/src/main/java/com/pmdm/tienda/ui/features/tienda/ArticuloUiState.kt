package com.pmdm.tienda.ui.features.tienda

data class ArticuloUiState(val id:Int, val url:String, val precio:Float,
                           val descripcion:String, val favorito:Boolean) {
}

