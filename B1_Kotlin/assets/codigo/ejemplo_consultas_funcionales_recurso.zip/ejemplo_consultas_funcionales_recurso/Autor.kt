package org.example

import java.time.LocalDate
import java.time.format.DateTimeFormatter

data class Autor(
    val nombre: String,
    val nacionalidad: String,
    val muerte: LocalDate,
    val libros: List<Libro>
) {
    override fun toString(): String =
        "Nombre: ${nombre.padEnd(37)}  Nacionalidad: ${nacionalidad.padEnd(10)} " +
                "Muerte: ${muerte.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}\n" +
                "Libros:\n\t${libros.joinToString("\n\t")}"
}