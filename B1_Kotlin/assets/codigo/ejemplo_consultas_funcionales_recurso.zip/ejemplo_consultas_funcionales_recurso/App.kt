package org.example

import java.time.LocalDate
import java.time.format.DateTimeFormatter

fun separadorDato() = "\n--------------------------------------------------------------------------------\n"

fun autoresConMasDeUnLibro() {
    val snapshot = Datos.autores
        .filter { it.libros.size > 1 }
    println(snapshot.joinToString(separadorDato()) { it.toString() })
}

fun totalLibrosEscritosPorEspañoles() {
    val totalLibros = Datos.autores
        // Filtramos por nacionalidad
        .filter { it.nacionalidad == "Española" }
        // Obtenemos el número de libros de cada autor
        .map { it.libros.size }
        // Sumamos los libros escritos por cada autor
        .sum()
    println("Hay $totalLibros escritos por españoles")
}

fun autoresAgrupadosPorSiglo() {

    // Creamos un DTO para evitar usar objetos anónimos.
    data class AutorMuerte(val nombre: String, val muerte: LocalDate)
    // Nota: Podríamos haber usado un Pair<String, LocalDate> en
    // lugar de un DTO pero el código sería menos legible.

    val snapshot = Datos.autores
        // Mapeamos a un objeto tipado AutorMuerte
        // para hacer la consulta en este ámbito
        .map { a -> AutorMuerte(nombre = a.nombre, muerte = a.muerte) }
        // Ordenamos por fecha de muerte
        .sortedBy { a -> a.muerte }
        // Agrupamos por siglo obteniendo un Map<Int, List<Autor>>
        // donde Int es el siglo y List<AutorMuerte> los autores
        .groupBy { it.muerte.year / 100 + 1 }

    snapshot.forEach { (siglo, autores) ->
        print(separadorDato())
        print("Siglo ${siglo}:\n\t")
        println(autores.joinToString("\n\t") { a ->
            "${a.nombre} ${a.muerte.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}"
        })
    }
}

fun totalPaginasWilliamShakespeare() {
    val totalPaginas = Datos.autores
        // Filtramos por nombre
        .filter { it.nombre == "William Shakespeare" }
        // De cada autor obtenemos la lista de libros
        // En este caso solo tendríamos un autor.
        .flatMap { it.libros }
        // De cada libro obtenemos el número de páginas
        .map { it.paginas }
        // Sumamos las páginas de cada libro
        .sum()
    println("William Shakespeare ha escrito $totalPaginas páginas")
}

fun main() {
    autoresConMasDeUnLibro()
    totalLibrosEscritosPorEspañoles()
    autoresAgrupadosPorSiglo()
    totalPaginasWilliamShakespeare()
}