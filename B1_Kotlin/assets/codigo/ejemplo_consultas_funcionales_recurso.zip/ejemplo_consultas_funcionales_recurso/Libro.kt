package org.example

data class Libro(
    val titulo: String,
    val año: Int,
    val paginas: Int
) {
    override fun toString(): String =
        "Titulo: ${titulo.padEnd(37)}  Año: ${año.toString().padEnd(4)}  Páginas: $paginas"
}