package org.example

import java.time.LocalDate

object Datos {
    val autores: List<Autor> = listOf(
        Autor(
            "William Shakespeare",
            "Inglesa",
            LocalDate.of(1616, 5, 3),
            listOf(
                Libro("Macbeth", 1623, 128),
                Libro("La tempestad", 1611, 160)
            )
        ),
        Autor(
            "Miguel de Cervantes",
            "Española",
            LocalDate.of(1616, 6, 22),
            listOf(
                Libro("Don Quijote de la Mancha", 1605, 1376),
                Libro("La Galatea", 1585, 664),
                Libro("Los trabajos de Persiles y Sigismunda", 1617, 888),
                Libro("Novelas ejemplares", 1613, 1160)
            )
        ),
        Autor(
            "Fernando de Rojas",
            "Española",
            LocalDate.of(1541, 2, 7),
            listOf(
                Libro("La Celestina", 1500, 160)
            )
        )
    )
}