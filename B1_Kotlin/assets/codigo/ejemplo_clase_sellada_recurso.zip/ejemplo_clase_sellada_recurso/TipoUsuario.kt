package org.example

enum class TipoUsuario(val tipo: String) {
    Admin("Admin"),
    Personal("Personal"),
    Cliente("Cliente")
}