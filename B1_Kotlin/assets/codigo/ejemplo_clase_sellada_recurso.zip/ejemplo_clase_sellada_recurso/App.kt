package org.example

fun registroAcciones() {
    val acciones = mutableListOf<AccionesUsuario>().apply {
        add(AccionesUsuario.Login(tipoUsuario = TipoUsuario.Admin))
        add(
            AccionesUsuario.Visualizar(
                fileName = "gato mirando cosas",
                tipoUsuario = TipoUsuario.Personal,
                mediaType = TipoArchivo.Video
            )
        )
        add(
            AccionesUsuario.Buscar(
                terminoBusqueda = "perro gracioso",
                tipoUsuario = TipoUsuario.Cliente,
                tipoArchivo = TipoArchivo.Foto,
                tipocategoria = TipoCategoria.Perros
            )
        )
        add(AccionesUsuario.Logout(tipoUsuario = TipoUsuario.Cliente))
    }

    acciones.forEach { println(it.aTexto()) }
}

fun main() {
    println(registroAcciones())
}
