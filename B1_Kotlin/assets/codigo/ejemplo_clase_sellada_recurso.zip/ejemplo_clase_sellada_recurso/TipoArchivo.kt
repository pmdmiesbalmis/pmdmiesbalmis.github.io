package org.example

enum class TipoArchivo(val tipo: String) {
    Foto("Foto"),
    Video("Video"),
    Audio("Audio")
}