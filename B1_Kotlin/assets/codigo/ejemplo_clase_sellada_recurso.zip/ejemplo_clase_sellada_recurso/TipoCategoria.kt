package org.example

enum class TipoCategoria(val tipo: String) {
    Mascotas("Mascotas"),
    Gatos("Gatos"),
    Perros("Perros")
}

