package org.example

sealed class AccionesUsuario {
    // Tipos Login y Logout
    data class Login(val tipoUsuario: TipoUsuario) : AccionesUsuario()
    data class Logout(val tipoUsuario: TipoUsuario) : AccionesUsuario()

    // Tipos Visualizar y Buscar ya definen otras propiedades
    // específicas para definir su propio estado.
    data class Visualizar(
        val fileName: String,
        val tipoUsuario: TipoUsuario,
        val mediaType: TipoArchivo
    ) : AccionesUsuario()

    data class Buscar(
        val terminoBusqueda: String,
        val tipoUsuario: TipoUsuario,
        val tipoArchivo: TipoArchivo,
        val tipocategoria: TipoCategoria
    ) : AccionesUsuario()

    // Defino un método para pasar a cadena que según el tipo
    // generamos una cadena con las características del estado.
    fun aTexto(): String {
        return when (this) {
            is Login ->
                "El usuario $tipoUsuario ha iniciado sesión"

            is Logout ->
                "El usuario $tipoUsuario ha cerrado sesión"

            is Visualizar ->
                "El usuario de tipo $tipoUsuario ha visto " +
                        "el fichero $fileName que es un $mediaType"

            is Buscar ->
                "El usurio de tipo $tipoUsuario ha buscado \"$terminoBusqueda\" " +
                        "de tipo $tipoArchivo en la categoría $tipocategoria"
        }
    }
}