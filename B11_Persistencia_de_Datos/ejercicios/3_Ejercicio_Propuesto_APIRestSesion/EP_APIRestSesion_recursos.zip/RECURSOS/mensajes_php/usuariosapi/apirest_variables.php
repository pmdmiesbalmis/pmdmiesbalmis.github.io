<?php

	// CONFIGURACIÓN BASE DE DATOS MYSQL
	$servername = "127.0.0.1";
	$username = "root";
	$password = "";
	
	// BASE DE DATOS
	$dbname = "usuarios";

	// ACCESO USUARIOS (si está vacío funciona sin usuarios)
	$usuarios = array();
	$usuarios["pedro"]="p1234";
	$usuarios["juan"]="j1234";
	
	// TABLAS Y SU CLAVE
	$tablas = array();
	$tablas["mensajes"]="_id";
	$tablas["usuarios"]="_id";
	
	


