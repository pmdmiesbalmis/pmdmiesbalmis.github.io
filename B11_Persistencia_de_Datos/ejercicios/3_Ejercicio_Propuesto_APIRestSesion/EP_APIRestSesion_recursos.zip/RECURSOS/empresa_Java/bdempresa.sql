CREATE SCHEMA bdempresa DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE bdempresa;


--
-- TABLA departamentos
--
CREATE TABLE departamentos (
  departamento varchar(20) NOT NULL PRIMARY KEY,
  telefono varchar(15) NOT NULL,
  presupuesto double NOT NULL
);


INSERT INTO departamentos (departamento, telefono, presupuesto) VALUES
('Compras', '965452315', 1980500),
('Facturación', '965452300', 560000),
('Ventas', '965452314', 2450950);

--
-- TABLA empleados
--

CREATE TABLE empleados (
  codigo int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  nombre varchar(20) NOT NULL,
  dep varchar(20) NOT NULL,
  email varchar(25) NOT NULL,
  edad int(11) NOT NULL,
  FOREIGN KEY (dep) REFERENCES departamentos(departamento)
);



INSERT INTO empleados (codigo, nombre, dep, email, edad) VALUES
(1, 'Claresta', 'Ventas', 'cwiles0@ning.com', 38),
(2, 'Malinde', 'Ventas', 'mabrahamowitcz1@paypal.or', 30),
(3, 'Lauri', 'Compras', 'lharwood2@bluehost.com', 47),
(4, 'Richie', 'Facturación', 'roxlee3@chronoengine.org', 48),
(5, 'Monti', 'Compras', 'mcraigheid4@bandcamp.com', 31),
(6, 'Rosabel', 'Ventas', 'rverrills5@java.com', 26),
(7, 'Caresa', 'Ventas', 'cterrans6@bravesites.com', 53),
(8, 'Brendis', 'Facturación', 'bburchfield7@cnbc.com', 37),
(9, 'Almeta', 'Compras', 'alow8@dyndns.org', 52),
(10, 'Berkeley', 'Ventas', 'bdacey9@wiley.com', 33);



COMMIT;


SELECT * FROM empleados, departamentos
	WHERE empleados.dep=departamentos.departamento;

