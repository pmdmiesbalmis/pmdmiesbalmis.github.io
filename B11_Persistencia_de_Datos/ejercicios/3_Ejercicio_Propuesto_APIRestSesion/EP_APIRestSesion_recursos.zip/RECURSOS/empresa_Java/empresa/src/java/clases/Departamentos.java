
package clases;

import java.io.Serializable;


public class Departamentos implements Serializable {
    String departamento;
    String telefono;
    double presupuesto;

    public Departamentos() {
    }

    public Departamentos(String departamento, String telefono, double presupuesto) {
        this.departamento = departamento;
        this.telefono = telefono;
        this.presupuesto = presupuesto;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public double getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(double presupuesto) {
        this.presupuesto = presupuesto;
    }

    @Override
    public String toString() {
        return "Departamentos{" + "departamento=" + departamento + ", telefono=" + telefono + ", presupuesto=" + presupuesto + '}';
    }
    
    
}
