package empresa;

import clases.Departamentos;
import clases.Empleados;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DAOEmpresa {

    static Connection con = null;


    /* ------------------- */
 /* CONECTAR */
 /* ------------------- */
    public static void conectar() {
        try {
            // Conexión a la BD
            String url;

            Class.forName("com.mysql.cj.jdbc.Driver");
            url = "jdbc:mysql://localhost:3306/bdempresa";
            url += "?zeroDateTimeBehavior=convertToNull&autoReconnect=true&useSSL=false&serverTimezone=UTC";

            String usuario = "root";
            String password = "1234";
            con = DriverManager.getConnection(url, usuario, password);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DAOEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /* ------------------- */
 /* DESCONECTAR */
 /* ------------------- */
    public static void desconectar() {
        try {
            // Cerrar conexión
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /* ------------------- */
    /* GET ALL DEP         */
    /* ------------------- */
    public static ArrayList<Departamentos> depGetAll() {
        ArrayList<Departamentos> lista = new ArrayList<>();

        if (con == null) {
            conectar();
        }

        String sentenciaSQL = "SELECT * FROM departamentos ORDER BY departamento";
        try (
                Statement statement = con.createStatement();
                ResultSet rs = statement.executeQuery(sentenciaSQL);) {
            while (rs.next()) {
                lista.add(new Departamentos(
                        rs.getString("departamento"),
                        rs.getString("telefono"),
                        rs.getDouble("presupuesto")));
            }

        } catch (SQLException ex) {
            Logger.getLogger(DAOEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }

    /* ------------------- */
    /* GET ONE */
    /* ------------------- */
    public static Empleados empGetOne(int id) {
        Empleados emp = null;

        if (con == null) {
            conectar();
        }

        String sentenciaSQL = "SELECT * FROM empleados,departamentos WHERE empleados.dep=departamentos.departamento AND codigo='" + id + "'";
        try (
                Statement statement = con.createStatement();
                ResultSet rs = statement.executeQuery(sentenciaSQL);) {
            if (rs.next()) {
                emp = new Empleados(
                        rs.getInt("codigo"),
                        rs.getString("nombre"),
                        rs.getString("email"),
                        rs.getInt("edad"),
                        new Departamentos(
                            rs.getString("departamento"),
                            rs.getString("telefono"),
                            rs.getDouble("presupuesto")                               
                        )
                );
            }

        } catch (SQLException ex) {
            Logger.getLogger(DAOEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        }
        return emp;

    }
    
    /* ------------------- */
    /* GET ALL */
    /* ------------------- */
    public static ArrayList<Empleados> empGetAll() {
        ArrayList<Empleados> lista = new ArrayList<>();

        if (con == null) {
            conectar();
        }

        String sentenciaSQL = "SELECT * FROM empleados,departamentos WHERE empleados.dep=departamentos.departamento";
        try (
                Statement statement = con.createStatement();
                ResultSet rs = statement.executeQuery(sentenciaSQL);) {
            while (rs.next()) {
                lista.add(
                    new Empleados(
                        rs.getInt("codigo"),
                        rs.getString("nombre"),
                        rs.getString("email"),
                        rs.getInt("edad"),
                        new Departamentos(
                            rs.getString("departamento"),
                            rs.getString("telefono"),
                            rs.getDouble("presupuesto")                               
                        )
                      )
                    );
            }

        } catch (SQLException ex) {
            Logger.getLogger(DAOEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;

    }
    
      
    
    
    
}
