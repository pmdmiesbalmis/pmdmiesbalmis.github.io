package empresa;

import clases.Empleados;
import clases.Mensaje;
import jakarta.json.Json;
import jakarta.json.JsonObject;
import jakarta.json.JsonObjectBuilder;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.UriInfo;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("empresa")
public class ServiceRESTEmpresa {

    @Context
    private UriInfo context;

    public ServiceRESTEmpresa() {
    }

    @Context
    private HttpServletRequest httpRequest;

    private String getUserIdentificado() {
        String user = "";
        if (httpRequest.getSession().getAttribute("usuario") != null) {
            user = (String) httpRequest.getSession().getAttribute("usuario");
        }
        return user;
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public Response getSession() {
        Response response;

        JsonObjectBuilder jsonOB = Json.createObjectBuilder();
        String user = getUserIdentificado();
        if (user.equals("")) {
            jsonOB.add("mensaje", "Debes identificarte");
        } else {
            jsonOB.add("mensaje", "Usuario identificado");
            jsonOB.add("usuario", user);
        }
        JsonObject json = jsonOB.build();

        response = Response
                .status(Response.Status.OK)
                .entity(json)
                .build();

        return response;
    }

    @GET
    @Path("departamentos")
    @Produces({MediaType.APPLICATION_JSON})
    public Response depGetAll() {
        Response response;

        if (getUserIdentificado().equals("")) {
            response = getSession();
        } else {
            response = Response
                    .status(Response.Status.OK)
                    .entity(DAOEmpresa.depGetAll())
                    .build();
        }

        return response;
    }

    @GET
    @Path("empleados/{id}")
    @Produces({MediaType.APPLICATION_JSON})
    public Response empGetOne(@PathParam("id") int id) {
        Response response;

        if (getUserIdentificado().equals("")) {
            response = getSession();
        } else {
            Mensaje mensaje = new Mensaje();

            Empleados emp = DAOEmpresa.empGetOne(id);

            if (emp != null) {
                response = Response
                        .status(Response.Status.OK)
                        .entity(emp)
                        .build();
            } else {
                mensaje.setMensaje("No existe empleado con ID " + id);
                response = Response
                        .status(Response.Status.NOT_FOUND)
                        .entity(mensaje)
                        .build();
            }
        }

        return response;
    }

    @GET
    @Path("empleados")
    @Produces({MediaType.APPLICATION_JSON})
    public Response empGetAll() {
        Response response;

        if (getUserIdentificado().equals("")) {
            response = getSession();
        } else {
            response = Response
                    .status(Response.Status.OK)
                    .entity(DAOEmpresa.empGetAll())
                    .build();
        }
        return response;
    }

}
