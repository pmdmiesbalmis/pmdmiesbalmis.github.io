
package clases;

import java.io.Serializable;

public class Empleados implements Serializable {
    int codigo;
    String nombre;
    String email;
    int edad;
    Departamentos dep;

    public Empleados() {
    }

    public Empleados(int codigo, String nombre, String email, int edad, Departamentos dep) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.email = email;
        this.edad = edad;
        this.dep = dep;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Departamentos getDep() {
        return dep;
    }

    public void setDep(Departamentos dep) {
        this.dep = dep;
    }

    @Override
    public String toString() {
        return "Empleados{" + "codigo=" + codigo + ", nombre=" + nombre + ", email=" + email + ", edad=" + edad + ", dep=" + dep + '}';
    }
    
    
}
