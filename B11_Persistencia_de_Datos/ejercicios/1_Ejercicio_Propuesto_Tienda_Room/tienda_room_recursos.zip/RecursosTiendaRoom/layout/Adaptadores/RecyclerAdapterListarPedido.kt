package com.ejemplo.b11.ejerciciopropuestotiendaroom.View
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ejemplo.b11.ejerciciopropuestotiendaroom.R
import com.ejemplo.b11.myapplication.database.PedidoEntity
import java.text.SimpleDateFormat
import java.util.*


class RecyclerAdapterListarPedido(var c: List<PedidoEntity>) : RecyclerView.Adapter<SimpleViewHolderListarPedido>(),OnClickListener
{
    lateinit var listener: View.OnClickListener
    lateinit var v:View
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SimpleViewHolderListarPedido {
         v= LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_listar_pedidos_layout, parent, false)
        var holder=  SimpleViewHolderListarPedido(v)
        v.setOnClickListener(this)

        return holder
    }
    override fun onBindViewHolder(holder: SimpleViewHolderListarPedido, position: Int) {
        holder.bind(c.get(position), v)
    }

    override fun getItemCount(): Int {
        return c.size
    }

    fun onClickListener(listener:OnClickListener)
    {
        this.listener=listener
    }



    override fun onClick(v: View?) {
        listener.onClick(v)
    }


}
    class SimpleViewHolderListarPedido(itemView: View) :
                      RecyclerView.ViewHolder(itemView)
    {
        var fecha: TextView
        var precio: TextView

        fun bind(dato: PedidoEntity, v: View) {
            val formatter = SimpleDateFormat("dd/MM/yyyy HH:mm")
            val salida: String = formatter.format(Date(dato.fecha))
            fecha.setText(salida)
            precio.setText(dato.total.toString())
        }
        init {
            fecha = itemView.findViewById(R.id.fechaPedio)
            precio = itemView.findViewById(R.id.totalPedido)

        }

    }



