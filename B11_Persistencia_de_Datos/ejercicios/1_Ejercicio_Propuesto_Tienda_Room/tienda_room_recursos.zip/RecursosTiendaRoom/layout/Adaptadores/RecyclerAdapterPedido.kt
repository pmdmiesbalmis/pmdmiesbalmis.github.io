package com.ejemplo.b11.ejerciciopropuestotiendaroom.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.ImageView
import com.ejemplo.b11.ejerciciopropuestotiendaroom.R
import com.ejemplo.b11.ejerciciopropuestotiendaroom.modelo.ArticulosEnPedido


class RecyclerAdapterPedido(var c: MutableList<ArticulosEnPedido>) : RecyclerView.Adapter<SimpleViewHolderPedido>()
{
    lateinit var listener: View.OnClickListener
    lateinit var v:View
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SimpleViewHolderPedido {
         v= LayoutInflater.from(parent.context)

            .inflate(R.layout.recycler_pedidos_layout, parent, false)
        var holder=  SimpleViewHolderPedido(v)
        holder.onClickListener{
            listener.onClick(it)
        }
        return holder
    }
    override fun onBindViewHolder(holder: SimpleViewHolderPedido, position: Int) {

        holder.bind(c.get(position), v)
    }

    override fun getItemCount(): Int {
        return c.size
    }

    fun onClickListener(listener:OnClickListener)
    {
        this.listener=listener
    }

}
    class SimpleViewHolderPedido(itemView: View) :
                      RecyclerView.ViewHolder(itemView), OnClickListener
    {
        lateinit var listener:OnClickListener
        var articulo: TextView
        var precio: TextView
        var cantidad: TextView
        var anyadir:ImageView
        var eliminar:ImageView
        lateinit var v:View
        fun bind(dato: ArticulosEnPedido, v: View) {
            articulo.setText(dato.descripcion)
            precio.setText(dato.precio.toString())
            cantidad.setText(dato.cantidad.toString())
            this.v=v

        }
        init {
            articulo = itemView.findViewById(R.id.articulolist)
            precio = itemView.findViewById(R.id.preciolist)
            cantidad=itemView.findViewById(R.id.cantidadlist)
            anyadir=itemView.findViewById(R.id.anyadirArticulo)
            eliminar=itemView.findViewById(R.id.quitarArticulo)
            anyadir.setOnClickListener(this)
            eliminar.setOnClickListener(this)
        }

        fun onClickListener(listener: OnClickListener)
        {
            this.listener=listener
        }
        override fun onClick(vista: View?) {
            when(vista?.id) {
                R.id.anyadirArticulo -> cantidad.setText(
                    (cantidad.text.toString().toInt() + 1).toString()
                )
                R.id.quitarArticulo -> {
                    var valor=cantidad.text.toString().toInt()
                    if(valor>0)  {valor--
                    cantidad.setText((cantidad.text.toString().toInt() - 1).toString())}
                }

            }
           listener.onClick(v)
        }

    }



