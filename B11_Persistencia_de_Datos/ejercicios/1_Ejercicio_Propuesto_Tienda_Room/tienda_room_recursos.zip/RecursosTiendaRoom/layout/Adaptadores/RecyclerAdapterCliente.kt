package com.ejemplos.b11.sqlite.ejerciciopropuestocursoresrecycler

import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.View.OnLongClickListener
import android.view.ViewGroup
import com.ejemplo.b11.ejerciciopropuestorecyclerroom.ClienteEntity
import com.ejemplo.b11.ejerciciopropuestotiendaroom.R


class RecyclerAdapter(var c: List<ClienteEntity>) : RecyclerView.Adapter<SimpleViewHolder>(), OnClickListener, OnLongClickListener{
    lateinit var listener: OnClickListener
    lateinit var listenerLargo: OnLongClickListener
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SimpleViewHolder {
        val v: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.recycler_cliente_layout, parent, false)
        v.setOnClickListener(this)
        v.setOnLongClickListener(this)
        return SimpleViewHolder(v)
    }
    override fun onBindViewHolder(holder: SimpleViewHolder, position: Int) {
        holder.bind(c.get(position))
    }

    override fun getItemCount(): Int {
        return c.size
    }

    fun onClickListener(listener: OnClickListener)
    {
        this.listener=listener
    }

    fun onLongClickListener(listener: OnLongClickListener)
    {
        this.listenerLargo=listener
    }
    override fun onClick(v: View?) {
       listener.onClick(v)
    }

    override fun onLongClick(v: View?): Boolean {
        listenerLargo.onLongClick(v)
        return true
    }


}
    class SimpleViewHolder(itemView: View) :
                      RecyclerView.ViewHolder(itemView)
    {
        var nombre: TextView
        var dni: TextView
        var direccion: TextView
        var telefono:TextView
        fun bind(dato: ClienteEntity) {
            nombre.setText(dato.nombre)
            dni.setText(dato.dni)
            direccion.setText(dato.direccion.toString())
            telefono.setText(dato.contacto)
        }
        init {
            nombre = itemView.findViewById(R.id.nombrelist)
            dni = itemView.findViewById(R.id.dnilist)
            direccion = itemView.findViewById(R.id.direccionlist)
            telefono = itemView.findViewById(R.id.telefonolist)
        }
    }



