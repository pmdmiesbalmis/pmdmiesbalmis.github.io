package com.vehiculos.ui.features.galeriacoches


// TODO: Implementar el Scaffold de la pantalla de GaleriaCoches
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun GaleriaCochesScreen(
//    cochesState: List<CocheUiState>,
//    cocheSeleccionadoState: CocheUiState?,
//    ordenacionState: Ordenacion,
//    verSoloOfertasState: Boolean,
//    onGaleriaCochesEvent: (GaleriaCochesEvent) -> Unit,
//    onEditarFichaCoche: (id: Int) -> Unit
//) {
//
//}


