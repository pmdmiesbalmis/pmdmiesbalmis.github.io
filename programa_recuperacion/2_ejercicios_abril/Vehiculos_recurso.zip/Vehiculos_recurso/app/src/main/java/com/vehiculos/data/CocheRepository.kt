package com.vehiculos.data

import com.vehiculos.data.mocks.coche.CocheDaoMock
import com.vehiculos.models.Coche
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CocheRepository {

    private val daoMock = CocheDaoMock()

    suspend fun get(id: Int): Coche = withContext(Dispatchers.IO) {
        daoMock.get(id).toCoche()
    }

    suspend fun get(): List<Coche> = withContext(Dispatchers.IO) {
        daoMock.get().map { it.toCoche() }
    }

    suspend fun getOfertas(): List<Coche> = withContext(Dispatchers.IO) {
        daoMock.getOfertas().map { it.toCoche() }
    }

    suspend fun delete(coche: Coche) = withContext(Dispatchers.IO) {
        daoMock.delete(coche.toCocheMock())
    }

    suspend fun update(coche: Coche) = withContext(Dispatchers.IO) {
        daoMock.update(coche.toCocheMock())
    }
}