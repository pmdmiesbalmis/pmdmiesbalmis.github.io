package com.vehiculos.data.mocks.coche

import com.vehiculos.R

class CocheDaoMock {
    private val coches = mutableListOf(
        CocheMock(
            id = 1,
            fabricante = "Volkswagen",
            modelo = "Passat",
            año = 2016,
            precio = 43210f,
            porcentajeDescuento = 0,
            descripcion = "Volkswagen Passat 2.0 TDI 150CV BMT Advance DSG 4p",
            foto = R.drawable.foto_1),
        CocheMock(
            id = 2,
            fabricante = "Ford",
            modelo = "Mustang",
            año = 2017,
            precio = 55000f,
            porcentajeDescuento = 10,
            descripcion = "Ford Mustang 5.0 Ti-VCT V8 GT 2p",
            foto = R.drawable.foto_2),
        CocheMock(
            id = 3,
            fabricante = "Audi",
            modelo = "A4",
            año = 2018,
            precio = 46000f,
            porcentajeDescuento = 0,
            descripcion = "Audi A4 2.0 TDI 110kW (150CV) S line edition 4p",
            foto = R.drawable.foto_3),
        CocheMock(
            id = 4,
            fabricante = "BMW",
            modelo = "X5",
            año = 2019,
            precio = 86800f,
            porcentajeDescuento = 20,
            descripcion = "BMW X5 xDrive30d 5p",
            foto = R.drawable.foto_4),
        CocheMock(
            id = 5,
            fabricante = "Mercedes",
            modelo = "Clase C",
            año = 2020,
            precio = 50000f,
            porcentajeDescuento = 0,
            descripcion = "Mercedes-Benz Clase C C 220d Estate 9G-Tronic 5p",
            foto = R.drawable.foto_5),
        CocheMock(
            id = 6,
            fabricante = "Volkswagen",
            modelo = "Golf",
            año = 2021,
            precio = 29000f,
            porcentajeDescuento = 0,
            descripcion = "Volkswagen Golf 1.5 TSI 96kW (130CV) Sport 5p",
            foto = R.drawable.foto_6),
        CocheMock(
            id = 7,
            fabricante = "Ford",
            modelo = "Focus",
            año = 2022,
            precio = 30000f,
            porcentajeDescuento = 5,
            descripcion = "Ford Focus 1.0 Ecoboost 92kW (125CV) ST-Line 5p",
            foto = R.drawable.foto_7),
        CocheMock(
            id = 8,
            fabricante = "Audi",
            modelo = "A3",
            año = 2023,
            precio = 32000f,
            porcentajeDescuento = 0,
            descripcion = "Audi A3 Sportback 30 TFSI 81kW (110CV) S tronic 5p",
            foto = R.drawable.foto_8),
        CocheMock(
            id = 9,
            fabricante = "BMW",
            modelo = "Serie 3",
            año = 2020,
            precio = 45200f,
            porcentajeDescuento = 0,
            descripcion = "BMW Serie 3 320d 140kW (190CV) Touring 5p",
            foto = R.drawable.foto_9),
        CocheMock(
            id = 10,
            fabricante = "Mercedes",
            modelo = "Clase A",
            año = 2021,
            precio = 38200f,
            porcentajeDescuento = 0,
            descripcion = "Mercedes-Benz Clase A A 200d 7G-DCT 5p",
            foto = R.drawable.foto_10),
        CocheMock(
            id = 11,
            fabricante = "Audi",
            modelo = "e-tron",
            año = 2022,
            precio = 87310f,
            porcentajeDescuento = 10,
            descripcion = "Audi e-tron 55 quattro 265kW (360CV) Advanced edition 5p",
            foto = R.drawable.foto_11),
        CocheMock(
            id = 12,
            fabricante = "BMW",
            modelo = "Serie 5",
            año = 2023,
            precio = 60000f,
            porcentajeDescuento = 20,
            descripcion = "BMW Serie 5 520d 140kW (190CV) Touring 5p",
            foto = R.drawable.foto_12),
        CocheMock(
            id = 13,
            fabricante = "Mercedes",
            modelo = "Clase G",
            año = 2020,
            precio = 148225f,
            porcentajeDescuento = 0,
            descripcion = "Mercedes-Benz Clase G G 350d 4Matic 180kW (245CV) 5p",
            foto = R.drawable.foto_13),
        CocheMock(
            id = 14,
            fabricante = "Volkswagen",
            modelo = "Tiguan",
            año = 2021,
            precio = 39000f,
            porcentajeDescuento = 0,
            descripcion = "Volkswagen Tiguan 2.0 TDI 110kW (150CV) 4Motion DSG 5p",
            foto = R.drawable.foto_14),
        CocheMock(
            id = 15,
            fabricante = "Ford",
            modelo = "Kuga",
            año = 2022,
            precio = 38250f,
            porcentajeDescuento = 0,
            descripcion = "Ford Kuga 1.5 EcoBoost 110kW (150CV) ST-Line 5p",
            foto = R.drawable.foto_15),
        CocheMock(
            id = 16,
            fabricante = "Audi",
            modelo = "Q3",
            año = 2023,
            precio = 43270f,
            porcentajeDescuento = 0,
            descripcion = "Audi Q3 35 TFSI 110kW (150CV) S tronic 5p",
            foto = R.drawable.foto_16),
        CocheMock(
            id = 17,
            fabricante = "Ford",
            modelo = "Mondeo",
            año = 2021,
            precio = 32000f,
            porcentajeDescuento = 10,
            descripcion = "Ford Mondeo 2.0 TDCi 110kW (150CV) Titanium 5",
            foto = R.drawable.foto_17))

    fun get(): List<CocheMock> {
        return coches
    }

    fun get(id: Int): CocheMock {
        return coches.first { it.id == id }
    }

    fun getOfertas(): List<CocheMock> {
        return coches.filter { it.porcentajeDescuento > 0 }
    }

    fun delete(coche: CocheMock) {
        coches.remove(coche)
    }

    fun update(coche: CocheMock) {
        val index = coches.indexOfFirst { it.id == coche.id }
        coches[index] = coche
    }
}