package com.vehiculos.ui.views

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import com.vehiculos.ui.theme.VehiculosTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VehiculosTheme {
                Surface {
                    // VehiculosNavHost()
                }
            }
        }
    }
}
