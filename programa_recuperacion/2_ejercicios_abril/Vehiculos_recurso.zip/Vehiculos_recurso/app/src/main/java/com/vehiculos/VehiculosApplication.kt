package com.vehiculos

import android.app.Application

class VehiculosApplication : Application() {
}
