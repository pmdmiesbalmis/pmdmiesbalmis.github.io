package com.tareas.ui.features.componens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowOutward
import androidx.compose.material3.Card
import androidx.compose.material3.CardColors
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.tareas.modelos.Tarea
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.TimeZone


@Composable
fun CardNota(
    cardColors: CardColors,
    tarea: Tarea,
) {
    Box(modifier = Modifier.padding(5.dp)) {
        Card(
            colors = cardColors,
            modifier = Modifier
                .fillMaxSize()
                .padding(0.dp)

        ) {
            Column(
                modifier = Modifier.clip(CardDefaults.shape)
            ) {
                Text(
                    modifier = Modifier
                        .padding(start = 12.dp, end = 12.dp)
                        .fillMaxWidth(),
                    text = tarea.titulo,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(modifier = Modifier.size(12.dp))
                val fecha = LocalDateTime.ofInstant(
                    Instant.ofEpochSecond(tarea.fecha),
                    TimeZone.getTimeZone(ZoneOffset.UTC).toZoneId()
                ).format(DateTimeFormatter.ofPattern("dd/MMM/yyyy HH:mm"))
                Text(
                    modifier = Modifier
                        .padding(start = 12.dp, end = 12.dp)
                        .fillMaxWidth(),
                    text = fecha,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.size(12.dp))
            }
        }
        Icon(
            modifier = Modifier
                .align(Alignment.BottomEnd),
            imageVector = Icons.Filled.ArrowOutward,
            contentDescription = "Hecho",
            tint = Color.White
        )
    }
}

