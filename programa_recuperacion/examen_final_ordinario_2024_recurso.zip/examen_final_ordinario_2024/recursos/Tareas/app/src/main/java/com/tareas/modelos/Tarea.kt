package com.tareas.modelos

data class Tarea(
    val id: Int?=null,
    val titulo: String="",
    val descripcion: String="",
    val estado: Int=-1,
    val fecha: Long=0,
    val archivada:Int=0
)
