package com.vehiculos.ui.views

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.vehiculos.ui.features.CocheUiState
import com.vehiculos.ui.features.fichacoche.FichaCocheScreen
import com.vehiculos.ui.theme.VehiculosTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VehiculosTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FichaCocheScreen(
                        cocheState = CocheUiState(
                            id = 1,
                            fabricante = "Volkswagen",
                            modelo = "Passat",
                            año = 2016,
                            precio = 43210f,
                            porcentajeDescuento = 20,
                            descripcion = "Volkswagen Passat 2.0 TDI 150CV BMT Advance DSG 4p",
                            foto = "foto_1"
                        ),
                        verDialogoDescuentoState = false,
                        onVerDialogoDescuento = {},
                        onCancelarDialogoDescuento = {},
                        onAceptarDialogoDescuento = {},
                        onNavigateTrasVerFicha = {}
                    )
                }
            }
        }
    }
}
