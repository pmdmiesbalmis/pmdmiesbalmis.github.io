package com.vehiculos.di

import com.vehiculos.data.CocheRepository
import com.vehiculos.data.mocks.coche.CocheDaoMock
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class ModuleApp {
    @Provides
    @Singleton
    fun provideCocheDaoMock(): CocheDaoMock = CocheDaoMock()

    @Provides
    @Singleton
    fun provideCocheRepository(
        dao: CocheDaoMock
    ): CocheRepository =
        CocheRepository(dao)
}
