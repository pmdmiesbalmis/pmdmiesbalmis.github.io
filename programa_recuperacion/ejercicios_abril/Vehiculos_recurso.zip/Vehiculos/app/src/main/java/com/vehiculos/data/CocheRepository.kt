package com.vehiculos.data

import com.vehiculos.data.mocks.coche.CocheDaoMock
import com.vehiculos.models.Coche
import javax.inject.Inject

class CocheRepository @Inject constructor(
    private var dao : CocheDaoMock
) {
    fun get(): MutableList<Coche> = dao.get().map { it.toCoche() }.toMutableList()
}