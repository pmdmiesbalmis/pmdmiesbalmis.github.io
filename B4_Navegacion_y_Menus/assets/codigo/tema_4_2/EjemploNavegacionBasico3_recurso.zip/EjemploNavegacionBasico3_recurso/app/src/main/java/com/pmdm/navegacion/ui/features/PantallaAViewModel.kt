package com.pmdm.navegacion.ui.features

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class PantallaAViewModel @Inject constructor() : ViewModel() {
    var nombreState by mutableStateOf("anónimo")
        private set
    fun onNombreChange(nombre: String) {
        nombreState = nombre
    }
}