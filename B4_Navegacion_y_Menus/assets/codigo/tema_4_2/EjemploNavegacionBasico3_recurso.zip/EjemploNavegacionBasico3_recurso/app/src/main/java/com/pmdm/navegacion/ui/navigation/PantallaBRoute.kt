package com.pmdm.navegacion.ui.navigation

import androidx.compose.runtime.remember
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import com.pmdm.navegacion.ui.features.PantallaBScreen
import com.pmdm.navegacion.ui.features.PantallaBViewModel
import kotlinx.serialization.Serializable

@Serializable
data class PantallaBRoute(val nombre: String)

fun NavGraphBuilder.pantallaBDestination(
    vm: PantallaBViewModel,
    onNavegarAtras: () -> Unit,
) {
    composable<PantallaBRoute>{ backStackEntry ->
        vm.nombreState = remember { backStackEntry.toRoute<PantallaBRoute>().nombre }
        PantallaBScreen(
            nombre = vm.nombreState,
            onNavegarAtras = onNavegarAtras
        )
    }
}