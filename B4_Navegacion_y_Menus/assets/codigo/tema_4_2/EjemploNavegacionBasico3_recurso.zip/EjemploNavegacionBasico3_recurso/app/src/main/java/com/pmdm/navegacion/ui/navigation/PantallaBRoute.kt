package com.pmdm.navegacion.ui.navigation

import android.util.Log
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.pmdm.navegacion.ui.features.PantallaAViewModel
import com.pmdm.navegacion.ui.features.PantallaBScreen
import com.pmdm.navegacion.ui.features.PantallaBViewModel

const val PantallaBRoute = "pantalla_B"
const val NombreParam = "nombre"

fun NavController.navigateToPantallaB(
    nombre: String,
    navOptions: NavOptions? = null
) {
    val ruta = "$PantallaBRoute/$nombre"
    Log.d("Navegacion", "Navegando a $ruta")
    this.navigate(ruta, navOptions)
}

fun NavGraphBuilder.pantallaBScreen(
    onNavegarAtras: () -> Unit
) {
    composable(
        route = "$PantallaBRoute"
    ) { backStackEntry ->
        PantallaBScreen(
            onNavegarAtras = onNavegarAtras
        )
    }
    composable(
        route = "$PantallaBRoute/{$NombreParam}",
        arguments = listOf(
            navArgument(NombreParam) {
                type = NavType.StringType
            }
        )
    ) { backStackEntry ->
        val nombre :String? = backStackEntry.arguments?.getString(
            NombreParam, "anonimo"
        )
        val vmPantallaB = hiltViewModel<PantallaBViewModel>()
        PantallaBScreen(
            nombre = vmPantallaB.nombreState,
            onNavegarAtras = onNavegarAtras
        )
    }
}