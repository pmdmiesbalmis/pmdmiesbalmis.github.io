package com.pmdm.navegacion.ui.features

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.pmdm.navegacion.ui.navigation.NombreParam
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class PantallaBViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    var nombreState: String = checkNotNull(savedStateHandle[NombreParam])
        private set
}