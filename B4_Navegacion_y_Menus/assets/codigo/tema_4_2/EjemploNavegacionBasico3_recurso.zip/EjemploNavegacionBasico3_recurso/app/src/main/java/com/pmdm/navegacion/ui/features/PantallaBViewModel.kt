package com.pmdm.navegacion.ui.features

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class PantallaBViewModel @Inject constructor() : ViewModel() {
    var nombreState: String = "anónimo"
}