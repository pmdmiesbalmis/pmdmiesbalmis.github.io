package com.pmdm.navegacion.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost

fun AnimatedContentTransitionScope<NavBackStackEntry>
        .entradaDesdeDerecha(duracion: Int) =
    fadeIn(animationSpec = tween(duracion)) +
    slideIntoContainer(
        AnimatedContentTransitionScope.SlideDirection.Left,
        tween(duracion)
    )

fun AnimatedContentTransitionScope<NavBackStackEntry>
        .salidaAlaDerecha(duracion: Int) =
    fadeOut(animationSpec = tween(duracion)) +
            slideOutOfContainer(
                AnimatedContentTransitionScope.SlideDirection.Right,
                tween(duracion)
            )

fun AnimatedContentTransitionScope<NavBackStackEntry>
        .salidaHaciaAbajo(duracion: Int) =
    fadeOut(animationSpec = tween(duracion)) +
            slideOutOfContainer(
                AnimatedContentTransitionScope.SlideDirection.Down,
                tween(duracion)
            )

fun AnimatedContentTransitionScope<NavBackStackEntry>
        .entradaHaciaArriba(duracion: Int) =
    fadeIn(animationSpec = tween(duracion)) +
            slideIntoContainer(
                AnimatedContentTransitionScope.SlideDirection.Up,
                tween(duracion)
            )

@Composable
fun NavHostEjemploBasico(
    navController: NavHostController
) {
    val duracionAnimacion = 1100
    NavHost(
        navController = navController,
        startDestination = PantallaARoute,
        enterTransition = { entradaDesdeDerecha(duracionAnimacion) },
        exitTransition = { salidaHaciaAbajo(duracionAnimacion) },
        popEnterTransition = { entradaHaciaArriba(duracionAnimacion) },
        popExitTransition = { salidaAlaDerecha(duracionAnimacion) }
    ) {
        pantallaAScreen(
            onNavigatePantallaB = { nombre ->
                navController.navigateToPantallaB(nombre)
            }
        )
        pantallaBScreen(
            onNavegarAtras = {
                navController.navigateUp()
            }
        )
    }
}