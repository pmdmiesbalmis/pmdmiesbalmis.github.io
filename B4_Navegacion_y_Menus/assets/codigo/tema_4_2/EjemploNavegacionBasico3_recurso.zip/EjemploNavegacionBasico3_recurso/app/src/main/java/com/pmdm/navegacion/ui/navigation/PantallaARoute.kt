package com.pmdm.navegacion.ui.navigation

import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaAScreen
import com.pmdm.navegacion.ui.features.PantallaAViewModel

const val PantallaARoute = "pantalla_A"

fun NavGraphBuilder.pantallaAScreen(
    onNavigatePantallaB: (String) -> Unit
) {
    composable(
        route = "$PantallaARoute"
    ) { backStackEntry ->
        val vmPantallaA = hiltViewModel<PantallaAViewModel>()
        PantallaAScreen(
            nombreState = vmPantallaA.nombreState,
            onNombreChange = vmPantallaA::onNombreChange,
            onNavigatePantallaB = onNavigatePantallaB
        )
    }
}