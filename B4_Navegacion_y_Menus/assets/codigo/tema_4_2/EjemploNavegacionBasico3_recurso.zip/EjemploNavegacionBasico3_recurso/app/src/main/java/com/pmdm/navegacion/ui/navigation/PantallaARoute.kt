package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaAScreen
import com.pmdm.navegacion.ui.features.PantallaAViewModel
import kotlinx.serialization.Serializable

@Serializable
object PantallaARoute

fun NavGraphBuilder.pantallaADestination(
    vm: PantallaAViewModel,
    onNavigatePantallaB: (String) -> Unit
) {
    composable<PantallaARoute> { backStackEntry ->
        PantallaAScreen(
            nombreState = vm.nombreState,
            onNombreChange = vm::onNombreChange,
            onNavigatePantallaB = onNavigatePantallaB
        )
    }
}