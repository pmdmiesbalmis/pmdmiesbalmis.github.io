package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaAScreen
import kotlinx.serialization.Serializable

// Definimos la ruta y como no recibe parámetros será un data object.
// Debe ser serializable para ser pasado como parámetro en la navegación.
@Serializable
object PantallaARoute

// Definimos un método de extensión de NavGraphBuilder para poder
// usarlo en el contexto de nuestro NavHost
// Fíjate que le hemos añadido el sufijo Destination indicando que es
// un "nodo de destino" en el grafo de navegación.
fun NavGraphBuilder.pantallaADestination(
    onNavigatePantallaB: () -> Unit
) {
    // Aquí es donde realmente definimos el destino de navegación para la
    // ruta que hemos definido en el objeto PantallaARoute
    // y donde realmente se emite la pantalla A dentro del NavHost.
    composable<PantallaARoute> { backStackEntry ->
         PantallaAScreen(onNavigatePantallaB)
    }
}