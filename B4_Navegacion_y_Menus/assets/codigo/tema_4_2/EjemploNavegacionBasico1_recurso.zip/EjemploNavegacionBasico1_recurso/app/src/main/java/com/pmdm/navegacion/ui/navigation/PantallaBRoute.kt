package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaBScreen
import kotlinx.serialization.Serializable

@Serializable
object PantallaBRoute

fun NavGraphBuilder.pantallaBDestination(
    onNavegarAtras: () -> Unit
) {
    composable<PantallaBRoute> { backStackEntry ->
        PantallaBScreen(
            onNavegarAtras = onNavegarAtras
        )
    }
}