package com.pmdm.navegacion.ui.navigation

import android.util.Log
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.pmdm.navegacion.ui.features.PantallaBScreen

const val PantallaBRoute = "pantalla_B"
private const val NombreParam = "nombre"

fun NavController.navigateToPantallaB(
    nombre: String,
    navOptions: NavOptions? = null
) {
    val ruta = "$PantallaBRoute/$nombre"
    Log.d("Navegacion", "Navegando a $ruta")
    this.navigate(ruta, navOptions)
}

fun NavGraphBuilder.pantallaBScreen(
    onNavegarAtras: () -> Unit
) {
    composable(
        route = "$PantallaBRoute"
    ) { backStackEntry ->
        PantallaBScreen(
            onNavegarAtras = onNavegarAtras
        )
    }
    composable(
        route = "$PantallaBRoute/{$NombreParam}",
        arguments = listOf(
            navArgument(NombreParam) {
                type = NavType.StringType
            }
        )
    ) { backStackEntry ->
        val nombre :String? = backStackEntry.arguments?.getString(
            NombreParam, "anonimo"
        )
        PantallaBScreen(
            nombre = nombre,
            onNavegarAtras = onNavegarAtras
        )
    }
}