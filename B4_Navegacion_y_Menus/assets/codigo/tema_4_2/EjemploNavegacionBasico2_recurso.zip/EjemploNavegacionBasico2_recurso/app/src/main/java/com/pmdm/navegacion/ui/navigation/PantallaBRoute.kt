package com.pmdm.navegacion.ui.navigation

import androidx.compose.runtime.remember
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import com.pmdm.navegacion.ui.features.PantallaBScreen
import kotlinx.serialization.Serializable

// Definimos la ruta con un parámetro de tipo String
@Serializable
data class PantallaBRoute(val nombre: String)

fun NavGraphBuilder.pantallaBDestination(
    onNavegarAtras: () -> Unit
) {
    composable<PantallaBRoute> { backStackEntry ->
        // Con el método toRoute podemos recuperar el objeto PantallaBRoute
        // con el parámetro de entrada.
        val datos : PantallaBRoute = remember { backStackEntry.toRoute<PantallaBRoute>() }
        PantallaBScreen(
            nombre = datos.nombre,
            onNavegarAtras = onNavegarAtras
        )
    }
}