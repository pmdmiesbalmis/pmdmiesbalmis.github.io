package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaAScreen
import kotlinx.serialization.Serializable

@Serializable
object PantallaARoute

fun NavGraphBuilder.pantallaADestination(
    onNavigatePantallaB: (String) -> Unit
) {
    composable<PantallaARoute> { backStackEntry ->
         PantallaAScreen(onNavigatePantallaB)
    }
}