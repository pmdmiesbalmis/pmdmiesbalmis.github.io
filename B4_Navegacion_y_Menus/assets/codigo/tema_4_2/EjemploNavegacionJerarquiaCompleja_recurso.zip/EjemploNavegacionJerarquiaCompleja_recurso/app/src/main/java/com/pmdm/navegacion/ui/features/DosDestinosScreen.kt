package com.pmdm.navegacion.ui.features

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pmdm.navegacion.ui.composables.TopAppBarEjemplo
import com.pmdm.navegacion.ui.theme.EjemploNavegacionTheme

@Composable
private fun ContenidoPantalla(
    textoState: String,
    bgColor: Color,
    destino1: String,
    destino2: String,
    onNavegarADestino1: () -> Unit,
    onNavegarADestino2: () -> Unit,
    modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.then(
            Modifier
                .fillMaxSize()
                .background(color = bgColor)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            modifier = Modifier.padding(bottom = 32.dp),
            text = textoState,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.padding(16.dp))
        Row (
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ){
            Button(onClick = onNavegarADestino1) {
                Text(text = destino1)
            }
            Button(onClick = onNavegarADestino2) {
                Text(text = destino2)
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DosDestinosScreen(
    texto: String,
    bgColor: Color,
    destino1: String,
    destino2: String,
    onNavegarADestino1: () -> Unit,
    onNavegarADestino2: () -> Unit,
    onNavegarAtras: (() -> Unit)? = null
) {
    val comportamientoAnteScroll = TopAppBarDefaults.pinnedScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(comportamientoAnteScroll.nestedScrollConnection),
        topBar = {
            TopAppBarEjemplo(
                comportamientoAnteScroll = comportamientoAnteScroll,
                onNavegarAtras = onNavegarAtras
            )
        },
        content = { innerPadding ->
            ContenidoPantalla(
                textoState = texto,
                bgColor = bgColor,
                destino1 = destino1,
                destino2 = destino2,
                onNavegarADestino1 = onNavegarADestino1,
                onNavegarADestino2 = onNavegarADestino2,
                modifier = Modifier.padding(innerPadding)
            )
        }
    )
}

@Preview(showBackground = true)
@Composable
fun DosDestinosScreenPreview() {
    EjemploNavegacionTheme {
        Surface {
            var textoState by remember { mutableStateOf("N1") }

            DosDestinosScreen(
                texto = textoState,
                bgColor = Color.LightGray,
                destino1 = "N2.1",
                destino2 = "N2.2",
                onNavegarADestino1 = { },
                onNavegarADestino2 = { }
            )
        }
    }
}