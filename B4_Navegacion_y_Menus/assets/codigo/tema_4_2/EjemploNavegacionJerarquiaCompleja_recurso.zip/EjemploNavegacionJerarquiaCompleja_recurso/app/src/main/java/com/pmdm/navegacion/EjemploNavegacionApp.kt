package com.pmdm.navegacion

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class EjemploNavegacionApp : Application()