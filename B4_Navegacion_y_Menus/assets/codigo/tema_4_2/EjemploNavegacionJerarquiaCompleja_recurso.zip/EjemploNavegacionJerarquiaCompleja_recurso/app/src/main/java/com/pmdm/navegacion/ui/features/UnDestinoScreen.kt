package com.pmdm.navegacion.ui.features

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pmdm.navegacion.ui.composables.TopAppBarEjemplo
import com.pmdm.navegacion.ui.theme.EjemploNavegacionTheme

@Composable
private fun ContenidoPantalla(
    texto: String,
    bgColor: Color,
    destino: String,
    onNavegarADestino: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.then(
            Modifier
                .fillMaxSize()
                .background(color = bgColor)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            modifier = Modifier.padding(bottom = 32.dp),
            text = texto,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.padding(16.dp))
        Button(onClick = onNavegarADestino) {
            Text(text = destino)
        }

    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnDestinoScreen(
    texto: String,
    bgColor: Color,
    destino: String,
    onNavegarADestino: () -> Unit,
    onNavegarAtras: (() -> Unit)? = null) {
    val comportamientoAnteScroll = TopAppBarDefaults.pinnedScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(comportamientoAnteScroll.nestedScrollConnection),
        topBar = {
            TopAppBarEjemplo(
                comportamientoAnteScroll = comportamientoAnteScroll,
                onNavegarAtras = onNavegarAtras
            )
        },
        content = { innerPadding ->
            ContenidoPantalla(
                texto = texto,
                bgColor = bgColor,
                destino = destino,
                onNavegarADestino = onNavegarADestino,
                modifier = Modifier.padding(innerPadding)
            )
        }
    )
}

@Preview(showBackground = true)
@Composable
fun UnDestinoScreenPreview() {
    EjemploNavegacionTheme {
        Surface {
            UnDestinoScreen(
                texto = "Texto",
                destino = "Destino",
                bgColor = Color.LightGray,
                onNavegarADestino = { },
                onNavegarAtras = { })
        }
    }
}