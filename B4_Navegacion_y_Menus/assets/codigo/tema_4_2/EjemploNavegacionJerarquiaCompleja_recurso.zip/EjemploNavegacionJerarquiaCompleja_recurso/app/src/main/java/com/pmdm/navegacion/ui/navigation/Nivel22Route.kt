package com.pmdm.navegacion.ui.navigation

import android.util.Log
import androidx.compose.runtime.remember
import androidx.compose.ui.res.colorResource
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.R
import com.pmdm.navegacion.ui.features.DosDestinosScreen
import kotlinx.serialization.Serializable

@Serializable
object Nivel22Route

fun NavGraphBuilder.nivel22Destination(
    onNavigateNivel32: () -> Unit,
    onNavigateNivel33: () -> Unit,
    onNavegarAtras: () -> Unit
) {
    composable<Nivel22Route> { backStackEntry ->
        Log.i("Navegacion", backStackEntry.destination.route!!)
        DosDestinosScreen(
            texto = "N1 > N2.2",
            bgColor = colorResource(R.color.nivel2),
            destino1 = "A Nivel 3.2",
            destino2 = "A Nivel 3.3",
            onNavegarADestino1 = onNavigateNivel32,
            onNavegarADestino2 = onNavigateNivel33,
            onNavegarAtras = onNavegarAtras
        )
    }
}