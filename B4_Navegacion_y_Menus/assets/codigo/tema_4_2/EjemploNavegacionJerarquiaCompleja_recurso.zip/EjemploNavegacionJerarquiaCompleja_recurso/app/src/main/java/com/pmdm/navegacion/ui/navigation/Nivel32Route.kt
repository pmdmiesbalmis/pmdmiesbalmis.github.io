package com.pmdm.navegacion.ui.navigation

import android.util.Log
import androidx.compose.runtime.remember
import androidx.compose.ui.res.colorResource
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.R
import com.pmdm.navegacion.ui.features.UnDestinoScreen

import kotlinx.serialization.Serializable

@Serializable
object Nivel32Route

fun NavGraphBuilder.nivel32Destination(
    onNavigateNivel4: () -> Unit,
    onNavegarAtras: () -> Unit
) {
    composable<Nivel32Route> { backStackEntry ->
        Log.i("Navegacion", backStackEntry.destination.route!!)
        UnDestinoScreen(
            texto = "N1 > N2.2 > N3.2",
            bgColor = colorResource(R.color.nivel3),
            destino = "A Nivel 4",
            onNavegarADestino = onNavigateNivel4,
            onNavegarAtras = onNavegarAtras
        )
    }
}