package com.pmdm.navegacion.ui.navigation

import android.util.Log
import androidx.compose.runtime.remember
import androidx.compose.ui.res.colorResource
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.R
import com.pmdm.navegacion.ui.features.FinalScreen
import kotlinx.serialization.Serializable

@Serializable
object Nivel31Route

fun NavGraphBuilder.nivel31Destination(
    onNavegarAtras: () -> Unit
) {
    composable<Nivel31Route>{ backStackEntry ->
        Log.i("Navegacion", backStackEntry.destination.route!!)
        FinalScreen(
            texto = "N1 > N2.1 > N3.1",
            bgColor = colorResource(R.color.nivel3),
            onNavegarAtras = onNavegarAtras
        )
    }
}