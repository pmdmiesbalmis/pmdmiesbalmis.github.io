package com.pmdm.navegacion.ui.navigation

import android.util.Log
import androidx.compose.runtime.remember
import androidx.compose.ui.res.colorResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.R
import com.pmdm.navegacion.ui.features.DosDestinosScreen
import kotlinx.serialization.Serializable

@Serializable
object Nivel1Route

fun NavGraphBuilder.nivel1Destination(
    onNavigateNivel21: () -> Unit,
    onNavigateNivel22: () -> Unit
) {
    composable<Nivel1Route> { backStackEntry ->
        Log.i("Navegacion", backStackEntry.destination.route!!)
        DosDestinosScreen(
            texto = "N1",
            bgColor = colorResource(R.color.nivel1),
            destino1 = "A Nivel 2.1",
            destino2 = "A Nivel 2.2",
            onNavegarADestino1 = onNavigateNivel21,
            onNavegarADestino2 = onNavigateNivel22
        )
    }
}