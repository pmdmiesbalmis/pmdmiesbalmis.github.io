package com.pmdm.navegacion.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost

@Composable
fun NavHostEjemploJerarquiaCompleja(
    navController: NavHostController
) {
    NavHost(
        navController = navController,
        startDestination = Nivel1Route,
    ) {
        nivel1Destination(
            onNavigateNivel21 = { navController.navigate(Nivel21Route) },
            onNavigateNivel22 = { navController.navigate(Nivel22Route) }
        )
        nivel21Destination(
            onNavigateNivel31 = {
                navController.navigate(Nivel31Route) {
                    popUpTo(Nivel1Route) { inclusive = false }
                }
            },
            onNavigateNivel4 = {
                navController.navigate(Nivel4Route("N1 > N2.1")) {
                    popUpTo(Nivel1Route) { inclusive = false }
                }
            },
            onNavegarAtras = { navController.popBackStack() }
        )
        nivel22Destination(
            onNavigateNivel32 = { navController.navigate(Nivel32Route) },
            onNavigateNivel33 = { navController.navigate(Nivel33Route) },
            onNavegarAtras = { navController.popBackStack() }
        )
        nivel31Destination(
            onNavegarAtras = { navController.popBackStack() }
        )
        nivel32Destination(
            onNavigateNivel4 = { navController.navigate(Nivel4Route("N1 > N2.2 > N3.2")) },
            onNavegarAtras = { navController.popBackStack() }
        )
        nivel33Destination(
            onNavegarAtras = { navController.popBackStack(Nivel1Route, inclusive = false) }
        )
        nivel4Destination(
            onNavegarAtras = { navController.popBackStack() }
        )
    }
}