package com.pmdm.navegacion.ui.navigation

import android.util.Log
import androidx.compose.ui.res.colorResource
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import com.pmdm.navegacion.R
import com.pmdm.navegacion.ui.features.FinalScreen
import kotlinx.serialization.Serializable

@Serializable
data class Nivel4Route(val origen: String)

fun NavGraphBuilder.nivel4Destination(
    onNavegarAtras: () -> Unit
) {
    composable<Nivel4Route>{ backStackEntry ->
        Log.i("Navegacion", backStackEntry.destination.route!!)
        FinalScreen(
            texto = backStackEntry.toRoute<Nivel4Route>().origen + " > N4" ,
            bgColor = colorResource(R.color.nivel4),
            onNavegarAtras = onNavegarAtras
        )
    }
}