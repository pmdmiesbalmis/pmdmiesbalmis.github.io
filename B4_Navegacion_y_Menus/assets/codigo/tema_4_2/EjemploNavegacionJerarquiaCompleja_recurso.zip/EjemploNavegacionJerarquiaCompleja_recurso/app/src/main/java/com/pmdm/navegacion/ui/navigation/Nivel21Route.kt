package com.pmdm.navegacion.ui.navigation

import android.util.Log
import androidx.compose.ui.res.colorResource
import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.R
import com.pmdm.navegacion.ui.features.DosDestinosScreen
import kotlinx.serialization.Serializable

@Serializable
object Nivel21Route

fun NavGraphBuilder.nivel21Destination(
    onNavigateNivel31: () -> Unit,
    onNavigateNivel4: () -> Unit,
    onNavegarAtras: () -> Unit
) {
    composable<Nivel21Route> { backStackEntry ->
        Log.i("Navegacion", backStackEntry.destination.route!!)
        DosDestinosScreen(
            texto = "N1 > N2.1",
            bgColor = colorResource(R.color.nivel2),
            destino1 = "A Nivel 3.1",
            destino2 = "A Nivel 4",
            onNavegarADestino1 = onNavigateNivel31,
            onNavegarADestino2 = onNavigateNivel4,
            onNavegarAtras = onNavegarAtras
        )
    }
}