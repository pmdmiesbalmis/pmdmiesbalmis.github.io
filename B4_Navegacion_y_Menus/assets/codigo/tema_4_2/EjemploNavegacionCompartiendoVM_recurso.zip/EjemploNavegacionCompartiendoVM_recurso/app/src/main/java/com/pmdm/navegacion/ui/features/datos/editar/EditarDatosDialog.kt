package com.pmdm.navegacion.ui.features.datos.editar

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pmdm.navegacion.ui.features.datos.DatosUiState
import com.pmdm.navegacion.ui.theme.EjemploNavegacionTheme

@Composable
fun EditarDatosDialog(
    datosState: DatosUiState,
    onPantallaPrincipalEvent: (EditarDatosEvent) -> Unit,
    onAceptar: (DatosUiState) -> Unit,
    onCancelar: () -> Unit
) = AlertDialog(
    title = { Text(text = "Introduce Datos") },
    onDismissRequest = onCancelar,
    confirmButton = {
        TextButton(onClick = { onAceptar(datosState.copy()) }) {
            Text(text = "Aceptar")
        }
    },
    dismissButton = {
        TextButton(onClick = onCancelar) {
            Text(text = "Cancelar")
        }
    },
    text = {
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TextField(
                value = datosState.nombre,
                onValueChange = { onPantallaPrincipalEvent(EditarDatosEvent.OnNombreChanged(it)) },
                placeholder = { Text("Introduce el nombre") },
                label = { Text("Nombre") }
            )
            Spacer(modifier = Modifier.padding(16.dp))
            TextField(
                value = datosState.apellido,
                onValueChange = { onPantallaPrincipalEvent(EditarDatosEvent.OnApellidoChanged(it)) },
                placeholder = { Text("Introduce el apellido") },
                label = { Text("Apellido") }
            )
        }
    }
)

@Preview(showBackground = true)
@Composable
fun EditarDatosScreenPreview() {
    EjemploNavegacionTheme {
        Surface {
            EditarDatosDialog(
                datosState = DatosUiState(),
                onPantallaPrincipalEvent = {},
                onAceptar = {},
                onCancelar = {}
            )
        }
    }
}