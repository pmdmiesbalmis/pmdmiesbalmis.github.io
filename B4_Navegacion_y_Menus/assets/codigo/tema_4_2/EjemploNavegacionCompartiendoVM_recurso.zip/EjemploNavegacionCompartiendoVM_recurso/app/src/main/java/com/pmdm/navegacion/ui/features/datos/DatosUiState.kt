package com.pmdm.navegacion.ui.features.datos

data class DatosUiState(
    val nombre: String = "Jhon",
    val apellido: String = "Doe"
)

