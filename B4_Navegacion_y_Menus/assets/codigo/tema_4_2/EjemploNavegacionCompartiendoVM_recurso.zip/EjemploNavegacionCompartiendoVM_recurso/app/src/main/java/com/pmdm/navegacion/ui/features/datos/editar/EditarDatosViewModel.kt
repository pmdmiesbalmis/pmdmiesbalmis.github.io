package com.pmdm.navegacion.ui.features.datos.editar

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.pmdm.navegacion.ui.features.datos.DatosUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class EditarDatosViewModel @Inject constructor() : ViewModel() {
    var datosState by mutableStateOf(DatosUiState())
        private set

    fun setDatos(datosState: DatosUiState) {
        this.datosState = datosState
    }

    fun onEditarDatosEvent(event: EditarDatosEvent) {
        when (event) {
            is EditarDatosEvent.OnNombreChanged -> {
                datosState = datosState.copy(nombre = event.nombre)
            }
            is EditarDatosEvent.OnApellidoChanged -> {
                datosState = datosState.copy(apellido = event.apellido)
            }
        }
    }
}