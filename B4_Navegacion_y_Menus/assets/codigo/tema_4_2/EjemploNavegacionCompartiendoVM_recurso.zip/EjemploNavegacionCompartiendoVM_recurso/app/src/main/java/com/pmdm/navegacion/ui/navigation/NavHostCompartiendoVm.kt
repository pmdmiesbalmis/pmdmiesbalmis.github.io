package com.pmdm.navegacion.ui.navigation

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import com.pmdm.navegacion.ui.features.datos.editar.EditarDatosViewModel
import com.pmdm.navegacion.ui.features.datos.ver.VerDatosViewModel

@Composable
fun NavHostCompartiendoVm(
    navController: NavHostController
) {
    val vVm = hiltViewModel<VerDatosViewModel>()
    val eVm = hiltViewModel<EditarDatosViewModel>()

    NavHost(
        navController = navController,
        startDestination = VerDatosRoute,
    ) {
        verDatosDestination(
            vm = vVm,
            onEditar = {
                eVm.setDatos(vVm.datosState)
                navController.navigate(EditarDatosRoute)
            }
        )
        editarDatosDestination(
            vm = eVm,
            onAceptar = { datos ->
                navController.popBackStack()
                vVm.setDatos(datos)
            },
            onCancelar = { navController.popBackStack() }
        )
    }
}