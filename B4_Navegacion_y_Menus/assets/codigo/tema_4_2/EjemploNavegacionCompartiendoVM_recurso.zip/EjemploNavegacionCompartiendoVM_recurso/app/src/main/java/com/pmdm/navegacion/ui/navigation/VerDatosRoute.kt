package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.datos.ver.VerDatosScreen
import com.pmdm.navegacion.ui.features.datos.ver.VerDatosViewModel
import kotlinx.serialization.Serializable

@Serializable
object VerDatosRoute

fun NavGraphBuilder.verDatosDestination(
    vm: VerDatosViewModel,
    onEditar: () -> Unit
) {
    composable<VerDatosRoute> {
        VerDatosScreen(
            datos = vm.datosState,
            onEditar = onEditar
        )
    }
}