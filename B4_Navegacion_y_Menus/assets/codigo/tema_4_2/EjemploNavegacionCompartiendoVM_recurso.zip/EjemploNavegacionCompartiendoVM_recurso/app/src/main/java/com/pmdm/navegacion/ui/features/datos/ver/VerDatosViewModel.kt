package com.pmdm.navegacion.ui.features.datos.ver

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.pmdm.navegacion.ui.features.datos.DatosUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class VerDatosViewModel @Inject constructor() : ViewModel() {
    var datosState by mutableStateOf(DatosUiState())
        private set

    fun setDatos(datosState: DatosUiState) {
        this.datosState = datosState
    }
}
