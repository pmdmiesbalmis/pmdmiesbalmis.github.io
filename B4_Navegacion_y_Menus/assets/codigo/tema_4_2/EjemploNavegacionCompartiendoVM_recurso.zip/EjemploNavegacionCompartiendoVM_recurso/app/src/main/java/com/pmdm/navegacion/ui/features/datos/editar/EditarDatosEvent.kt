package com.pmdm.navegacion.ui.features.datos.editar

sealed interface EditarDatosEvent {
    data class OnNombreChanged(val nombre: String) : EditarDatosEvent
    data class OnApellidoChanged(val apellido: String) : EditarDatosEvent
}
