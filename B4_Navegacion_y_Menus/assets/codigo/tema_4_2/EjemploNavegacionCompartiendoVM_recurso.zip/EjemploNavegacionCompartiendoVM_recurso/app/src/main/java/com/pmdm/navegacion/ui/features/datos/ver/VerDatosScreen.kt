package com.pmdm.navegacion.ui.features.datos.ver

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pmdm.navegacion.ui.composables.TopAppBarEjemplo
import com.pmdm.navegacion.ui.features.datos.DatosUiState
import com.pmdm.navegacion.ui.theme.EjemploNavegacionTheme

@Composable
private fun ContenidoPantalla(
    nombreState: String,
    apellidoState: String,
    onEditar: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.then(
            Modifier
                .fillMaxSize()
                .background(color = MaterialTheme.colorScheme.primaryContainer)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Nombre: $nombreState",
            style = MaterialTheme.typography.titleLarge
        )
        Text(
            text = "Apellido: $apellidoState",
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(modifier = Modifier.padding(16.dp))
        Button(onClick = onEditar) {
            Text(text = "Editar")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VerDatosScreen(
    datos: DatosUiState,
    onEditar: () -> Unit
) {
    val comportamientoAnteScroll = TopAppBarDefaults.pinnedScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(comportamientoAnteScroll.nestedScrollConnection),
        topBar = {
            TopAppBarEjemplo(comportamientoAnteScroll = comportamientoAnteScroll)
        },
        content = { innerPadding ->
            ContenidoPantalla(
                nombreState = datos.nombre,
                apellidoState = datos.apellido,
                onEditar = onEditar,
                modifier = Modifier.padding(innerPadding)
            )
        }
    )
}

@Preview(showBackground = true)
@Composable
fun VerDatosScreenPreview() {
    EjemploNavegacionTheme {
        Surface {
            VerDatosScreen(
                datos = DatosUiState(),
                onEditar = {}
            )
        }
    }
}