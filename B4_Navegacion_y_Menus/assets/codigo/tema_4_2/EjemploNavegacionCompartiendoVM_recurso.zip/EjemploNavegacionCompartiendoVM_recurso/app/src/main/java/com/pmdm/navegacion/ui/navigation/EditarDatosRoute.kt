package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.dialog
import com.pmdm.navegacion.ui.features.datos.DatosUiState
import com.pmdm.navegacion.ui.features.datos.editar.EditarDatosDialog
import com.pmdm.navegacion.ui.features.datos.editar.EditarDatosViewModel
import kotlinx.serialization.Serializable

@Serializable
object EditarDatosRoute

fun NavGraphBuilder.editarDatosDestination(
    vm: EditarDatosViewModel,
    onAceptar: (DatosUiState) -> Unit,
    onCancelar: () -> Unit
) {
    dialog<EditarDatosRoute> {
        EditarDatosDialog(
            datosState = vm.datosState,
            onPantallaPrincipalEvent = vm::onEditarDatosEvent,
            onAceptar = onAceptar,
            onCancelar = onCancelar
        )
    }
}