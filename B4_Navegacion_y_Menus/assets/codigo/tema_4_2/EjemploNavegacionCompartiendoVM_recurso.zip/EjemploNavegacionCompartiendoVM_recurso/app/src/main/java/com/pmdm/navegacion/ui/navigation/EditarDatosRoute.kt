package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.datos.DatosUiState
import com.pmdm.navegacion.ui.features.datos.editar.EditarDatosViewModel
import com.pmdm.navegacion.ui.features.datos.editar.EditarDatosScreen
import kotlinx.serialization.Serializable

@Serializable
object EditarDatosRoute

fun NavGraphBuilder.editarDatosDestination(
    vm: EditarDatosViewModel,
    onAceptar: (DatosUiState) -> Unit,
    onCancelar: () -> Unit
) {
    composable<EditarDatosRoute> {
        EditarDatosScreen(
            datosState = vm.datosState,
            onPantallaPrincipalEvent = vm::onEditarDatosEvent,
            onAceptar = onAceptar,
            onCancelar = onCancelar
        )
    }
}