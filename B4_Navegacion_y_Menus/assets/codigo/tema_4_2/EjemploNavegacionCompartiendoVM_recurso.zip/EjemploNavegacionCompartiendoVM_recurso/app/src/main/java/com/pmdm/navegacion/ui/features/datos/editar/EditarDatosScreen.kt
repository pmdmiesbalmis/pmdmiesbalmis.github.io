package com.pmdm.navegacion.ui.features.datos.editar

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pmdm.navegacion.ui.composables.TopAppBarEjemplo
import com.pmdm.navegacion.ui.features.datos.DatosUiState
import com.pmdm.navegacion.ui.theme.EjemploNavegacionTheme

@Composable
private fun ContenidoPantalla(
    nombreState: String,
    onNombreChange: (String) -> Unit,
    apellidoState: String,
    onApellidoChange: (String) -> Unit,
    onAceptar: (DatosUiState) -> Unit,
    onCancelar: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.then(
            Modifier
                .fillMaxSize()
                .background(color = MaterialTheme.colorScheme.primaryContainer)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TextField(
            value = nombreState,
            onValueChange = onNombreChange,
            placeholder = { Text("Introduce el nombre") },
            label = { Text("Nombre") }
        )
        TextField(
            value = apellidoState,
            onValueChange = onApellidoChange,
            placeholder = { Text("Introduce el apellido") },
            label = { Text("Apellido") }
        )
        Spacer(modifier = Modifier.padding(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = { onAceptar(DatosUiState(nombreState, apellidoState)) }) {
                Text(text = "Aceptar")
            }
            Button(onClick = onCancelar) {
                Text(text = "Cancelar")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditarDatosScreen(
    datosState: DatosUiState,
    onPantallaPrincipalEvent: (EditarDatosEvent) -> Unit,
    onAceptar: (DatosUiState) -> Unit,
    onCancelar: () -> Unit
) {
    val comportamientoAnteScroll = TopAppBarDefaults.pinnedScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(comportamientoAnteScroll.nestedScrollConnection),
        topBar = {
            TopAppBarEjemplo(
                comportamientoAnteScroll = comportamientoAnteScroll,
                onNavegarAtras = onCancelar
            )
        },
        content = { innerPadding ->
            ContenidoPantalla(
                nombreState = datosState.nombre,
                onNombreChange = { onPantallaPrincipalEvent(EditarDatosEvent.OnNombreChanged(it)) },
                apellidoState = datosState.apellido,
                onApellidoChange = { onPantallaPrincipalEvent(EditarDatosEvent.OnApellidoChanged(it)) },
                onAceptar = onAceptar,
                onCancelar = onCancelar,
                modifier = Modifier.padding(innerPadding)
            )
        }
    )
}

@Preview(showBackground = true)
@Composable
fun EditarDatosScreenPreview() {
    EjemploNavegacionTheme {
        Surface {
            EditarDatosScreen(
                datosState = DatosUiState(),
                onPantallaPrincipalEvent = {},
                onAceptar = {},
                onCancelar = {}
            )
        }
    }
}