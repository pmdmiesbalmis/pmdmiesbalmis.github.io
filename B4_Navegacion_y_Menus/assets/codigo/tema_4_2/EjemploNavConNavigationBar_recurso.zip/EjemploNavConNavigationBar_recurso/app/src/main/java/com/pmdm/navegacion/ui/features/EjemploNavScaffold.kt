package com.pmdm.navegacion.ui.features

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Filter1
import androidx.compose.material.icons.filled.Filter2
import androidx.compose.material.icons.filled.Filter3
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.pmdm.navegacion.ui.navigation.EjemploNavHost
import com.pmdm.navegacion.ui.navigation.Pantalla1Route
import com.pmdm.navegacion.ui.navigation.Pantalla2Route
import com.pmdm.navegacion.ui.navigation.Pantalla3Route
import com.pmdm.navegacion.ui.navigation.navigateToPantalla1
import com.pmdm.navegacion.ui.navigation.navigateToPantalla2
import com.pmdm.navegacion.ui.navigation.navigateToPantalla3
import com.pmdm.navegacion.ui.theme.EjemploNavegacionTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarEnEjemploNav(
    comportamientoAnteScroll: TopAppBarScrollBehavior,
    onNavegarAtras: () -> Unit,
    onDeshacerNavegacion: () -> Unit
) = TopAppBar(
    title = {
        Text("Ejemplo NavigationBar", maxLines = 1, overflow = TextOverflow.Ellipsis)
    },
    navigationIcon = {
        IconButton(onClick = onNavegarAtras) {
            Icon(imageVector = Icons.Filled.ArrowBackIosNew, contentDescription = null)
        }
    },
    actions = {
        IconButton(onClick = onDeshacerNavegacion) {
            Icon(imageVector = Icons.Filled.Home, contentDescription = null)
        }
    },
    scrollBehavior = comportamientoAnteScroll
)

@Composable
fun ContenidoPrincipalEnEjemploNav(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) { EjemploNavHost(navController) }
}

@Composable
fun NavigationBarEnEjemploNav(
    iOpcionNevagacionSeleccionada: Int = 0,
    onNavigateToScreen: (Int) -> Unit
) {
    val titlesAndIcons = remember {
        listOf(
            "Pantalla 1" to Icons.Filled.Filter1,
            "Pantalla 2" to Icons.Filled.Filter2,
            "Pantalla 3" to Icons.Filled.Filter3
        )
    }

    NavigationBar {
        titlesAndIcons.forEachIndexed { index, (title, icon) ->
            NavigationBarItem(
                icon = { Icon(icon, contentDescription = title) },
                label = { Text(title) },
                selected = iOpcionNevagacionSeleccionada == index,
                onClick = { onNavigateToScreen(index) }
            )
        }
    }
}

private fun iOpcionNevagacionSeleccionadaAPartirDeRuta(routa: String?): Int {
    return when (routa?.substringBefore("/")) {
        Pantalla1Route -> 0
        Pantalla2Route -> 1
        Pantalla3Route -> 2
        else -> 0
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EjemploNavDentroDeUnScaffold() {
    val comportamientoAnteScroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val navController = rememberNavController()
    val entradaEnPilaDeNavegacionActuasState = navController.currentBackStackEntryAsState()
    var iOpcionNevagacionSeleccionada = derivedStateOf {
        iOpcionNevagacionSeleccionadaAPartirDeRuta(
            entradaEnPilaDeNavegacionActuasState.value?.destination?.route
        )
    }

    Scaffold(
        modifier = Modifier.nestedScroll(comportamientoAnteScroll.nestedScrollConnection),
        topBar = {
            TopAppBarEnEjemploNav(
                comportamientoAnteScroll = comportamientoAnteScroll,
                onNavegarAtras = {
                    navController.navigateUp()
                },
                onDeshacerNavegacion = {
                    navController.popBackStack(navController.graph.startDestinationRoute!!, false)
                })
        },
        bottomBar = {
            NavigationBarEnEjemploNav(
                iOpcionNevagacionSeleccionada = iOpcionNevagacionSeleccionada.value,
                onNavigateToScreen = { nuevo ->
                    when (nuevo) {
                        0 -> navController.navigateToPantalla1(
                            pantallaAnterior = iOpcionNevagacionSeleccionada.value + 1
                        )
                        1 -> navController.navigateToPantalla2(
                            pantallaAnterior = iOpcionNevagacionSeleccionada.value + 1
                        )
                        2 -> navController.navigateToPantalla3(
                            pantallaAnterior = iOpcionNevagacionSeleccionada.value + 1
                        )
                    }
                }
            )
        },
        content = { innerPadding ->
            ContenidoPrincipalEnEjemploNav(
                navController = navController,
                modifier = Modifier.padding(innerPadding)
            )
        }
    )
}

@Preview(showBackground = true)
@Composable
fun PantallaNavBarPreview() {
    EjemploNavegacionTheme {
        Surface {
            EjemploNavDentroDeUnScaffold()
        }
    }
}