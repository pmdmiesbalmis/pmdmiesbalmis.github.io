package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.pmdm.navegacion.ui.features.PantallaScreen

const val Pantalla1Route = "pantalla1"
private const val Pantalla1Parameter1Name = "pantalla_de_donde_vengo"

fun NavController.navigateToPantalla1(
    pantallaAnterior: Int,
    navOptions: NavOptions? = null
) {
    this.navigate("$Pantalla1Route/$pantallaAnterior", navOptions)
}

fun NavGraphBuilder.pantalla1Screen(
    onNavigatePantallaAnterior: () -> Unit
) {
    composable(
        route = "$Pantalla1Route"
    ) { backStackEntry ->
         PantallaScreen(
            pantalla = 1,
            onNavigatePantallaAnterior = onNavigatePantallaAnterior
        )
    }
    composable(
        route = "$Pantalla1Route/{$Pantalla1Parameter1Name}",
        arguments = listOf(
            navArgument(Pantalla1Parameter1Name) {
                type = NavType.IntType
            }
        )
    ) { backStackEntry ->
        val pantallaAnterior :Int? = backStackEntry.arguments?.getInt(
            Pantalla1Parameter1Name, -1
        )
        PantallaScreen(
            pantalla = 1,
            pantallaDeDondeVengo = pantallaAnterior,
            onNavigatePantallaAnterior = onNavigatePantallaAnterior
        )
    }
}