package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.pmdm.navegacion.ui.features.PantallaScreen

const val Pantalla2Route = "pantalla2"
const val Pantalla2Parameter1Name = "pantalla_de_donde_vengo"

fun NavController.navigateToPantalla2(
    pantallaAnterior: Int,
    navOptions: NavOptions? = null
) {
    this.navigate("$Pantalla2Route/$pantallaAnterior", navOptions)
}

fun NavGraphBuilder.pantalla2Screen(
    onNavigatePantallaAnterior: () -> Unit
) {
    composable(
        route = "$Pantalla2Route/{$Pantalla2Parameter1Name}",
        arguments = listOf(
            navArgument(Pantalla2Parameter1Name) {
                type = NavType.IntType
            }
        )
    ) { backStackEntry ->
        val pantallaAnterior :Int? = backStackEntry.arguments?.getInt(
            Pantalla2Parameter1Name, -1
        )
        PantallaScreen(
            pantalla = 2,
            pantallaDeDondeVengo = pantallaAnterior,
            onNavigatePantallaAnterior = onNavigatePantallaAnterior
        )
    }
}