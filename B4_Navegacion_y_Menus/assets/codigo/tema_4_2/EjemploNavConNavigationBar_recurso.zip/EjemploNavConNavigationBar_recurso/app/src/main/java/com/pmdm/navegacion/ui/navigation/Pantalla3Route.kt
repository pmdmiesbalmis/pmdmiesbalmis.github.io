package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavOptions
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.pmdm.navegacion.ui.features.PantallaScreen

const val Pantalla3Route = "pantalla3"
const val Pantalla3Parameter1Name = "pantalla_de_donde_vengo"

fun NavController.navigateToPantalla3(
    pantallaAnterior: Int,
    navOptions: NavOptions? = null
) {
    this.navigate("$Pantalla3Route/$pantallaAnterior", navOptions)
}

fun NavGraphBuilder.pantalla3Screen(
    onNavigatePantallaAnterior: () -> Unit
) {
    composable(
        route = "$Pantalla3Route/{$Pantalla3Parameter1Name}",
        arguments = listOf(
            navArgument(Pantalla3Parameter1Name) {
                type = NavType.IntType
            }
        )
    ) { backStackEntry ->
        val pantallaAnterior :Int? = backStackEntry.arguments?.getInt(
            Pantalla3Parameter1Name, -1
        )
        PantallaScreen(
            pantalla = 3,
            pantallaDeDondeVengo = pantallaAnterior,
            onNavigatePantallaAnterior = onNavigatePantallaAnterior
        )
    }
}