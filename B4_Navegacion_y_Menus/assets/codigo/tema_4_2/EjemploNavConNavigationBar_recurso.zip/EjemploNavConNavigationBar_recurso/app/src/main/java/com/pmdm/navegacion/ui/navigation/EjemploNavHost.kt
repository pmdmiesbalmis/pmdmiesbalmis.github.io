package com.pmdm.navegacion.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost

@Composable
fun EjemploNavHost(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Pantalla1Route()
    ) {
        val onNavigatePantallaAnterior: () -> Unit = {
            navController.navigateUp()
        }
        pantalla1Destination(onNavigatePantallaAnterior = onNavigatePantallaAnterior)
        pantalla2Destination(onNavigatePantallaAnterior = onNavigatePantallaAnterior)
        pantalla3Destination(onNavigatePantallaAnterior = onNavigatePantallaAnterior)
    }
}