package ejercicios.kotlin.colecciones

sealed interface SeriesEvent {
    data class ListaPorGenero(val genero: String) : SeriesEvent
    data class MarcaAcabada(val codigo: Int) : SeriesEvent
    data class MarcaPosicionSerie(
        val codigo: Int,
        val temporada: Int,
        val capitulo: Int,
    ) : SeriesEvent

    object ListaTodas : SeriesEvent
    object ListaAcabadas : SeriesEvent
}

private fun onSeriesEvent(seriesEvent: SeriesEvent, misSeries: MutableList<Serie>) {
    when (seriesEvent) {
        is SeriesEvent.ListaPorGenero -> {
            var aux = Genero.values().find { it.name == seriesEvent.genero.uppercase() }
                ?: Genero.INDEFINIDO
            println("La lista de series por el género ${seriesEvent.genero} son ...")
            misSeries.filter { it.genero == aux }.forEach { println(it) }
        }

        is SeriesEvent.MarcaAcabada -> {
            println("Se marcará la serie con código ${seriesEvent.codigo} como acabada")
            val posicionSerie =
                misSeries.indexOf(misSeries.find { it.coidog == seriesEvent.codigo })
            if (posicionSerie != -1) misSeries[posicionSerie] =
                misSeries[posicionSerie].copy(acabada = true)
            else println("No tienes esa serie en tu lista")
        }

        is SeriesEvent.ListaAcabadas -> {
            println("La lista de series acabadas es ...")
            misSeries.filter { it.acabada == true }.forEach { println(it) }
        }

        is SeriesEvent.ListaTodas -> {
            println("La lista de todas mis series es ...")
            misSeries.forEach { println(it) }
        }

        is SeriesEvent.MarcaPosicionSerie -> {
            val posicionSerie =
                misSeries.indexOf(misSeries.find { it.coidog == seriesEvent.codigo })
            if (posicionSerie != -1 &&
                misSeries[posicionSerie].numeroTemporadas >= seriesEvent.temporada &&
                misSeries[posicionSerie].numeroCapitulosTemporada >= seriesEvent.capitulo
            ) {
                misSeries[posicionSerie] = misSeries[posicionSerie].copy(
                    temporada = seriesEvent.temporada,
                    capitulo = seriesEvent.capitulo
                )
                println(
                    "Se señala la serie con código: ${seriesEvent.codigo} " + "\n" +
                            "como vista hasta la temporada - ${seriesEvent.temporada} y capítulo ${seriesEvent.capitulo}"
                )
            } else println("Lo sentimos has introducido algún dato incorrecto")
        }
    }
}

private fun accionSeleccion(opcion: String, misSeries: MutableList<Serie>) {
    when (opcion.toIntOrNull()) {
        1 -> onSeriesEvent(SeriesEvent.ListaTodas, misSeries)
        2 -> onSeriesEvent(SeriesEvent.ListaAcabadas, misSeries)
        3 -> {
            println("Introduce el genero de las series que quieres mostrar")
            val genero = readln()
            onSeriesEvent(SeriesEvent.ListaPorGenero(genero), misSeries)
        }
        4 -> {
            println("Introduce el código de la serie a marcar como acabada")
            val codigo = readln()
            onSeriesEvent(SeriesEvent.MarcaAcabada(codigo.toInt()), misSeries)
        }
        5 -> {
            println("Introduce el código de la serie de la que quieres marcar su posición")
            val codigo = readln().toInt()
            println("Introduce la temporada de la serie a marcar")
            val temporada = readln().toInt()
            println("Introduce el capítulo de la serie a marcar")
            val capitulo = readln().toInt()
            onSeriesEvent(
                SeriesEvent.MarcaPosicionSerie(
                    codigo,
                    if (temporada < 1) 1 else temporada,
                    if (capitulo < 1) 1 else capitulo
                ), misSeries
            )
        }
        else -> println("Lo siento esa no es una opción válida")
    }
}

fun ejercicio3() {
    var misSeries = generaSeries()
    do {
        println("1. Listar todas mis series")
        println("2. Listar mis series acabadas")
        println("3. Listar mis series por género")
        println("4. Marcar serie como acabada")
        println("5. Marcar seguimiento de la serie")
        println("6. Salir")
        val opcion = readln()
        accionSeleccion(opcion, misSeries)
    } while (opcion != "6")
}

fun generaSeries(): MutableList<Serie> =
    mutableListOf<Serie>().apply {
        add(
            Serie(
                coidog = 111,
                titulo = "Orphan Black",
                numeroTemporadas = 5,
                numeroCapitulosTemporada = 10,
                temporada = 5,
                capitulo = 9,
                acabada = false,
                genero = Genero.FICCION,
                creador = "Graeme Manson y John Fawcett"
            )
        )
        add(
            Serie(
                coidog = 112,
                titulo = "The Good Wife",
                numeroTemporadas = 7,
                numeroCapitulosTemporada = 22,
                temporada = 2,
                capitulo = 1,
                acabada = false,
                genero = Genero.DRAMA,
                creador = "Michelle King y Robert King"
            )
        )
        add(
            Serie(
                coidog = 113,
                titulo = "The Outsider",
                numeroTemporadas = 1,
                numeroCapitulosTemporada = 10,
                temporada = 1,
                capitulo = 5,
                acabada = false,
                genero = Genero.TERROR,
                creador = "Jason Bateman, Andrew Bernstein y Igor Martinovic"
            )
        )
        add(
            Serie(
                coidog = 114,
                titulo = "The 100",
                numeroTemporadas = 7,
                numeroCapitulosTemporada = 15,
                temporada = 2,
                capitulo = 8,
                acabada = false,
                genero = Genero.FICCION,
                creador = "Jason Rothenberg"
            )
        )
    }
