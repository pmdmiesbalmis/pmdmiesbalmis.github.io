package ejercicios.kotlin.colecciones

fun main() {
    //ejercicio1()
    ejercicio2()
    //ejercicio3()

}
