package ejercicios.kotlin.colecciones

data class Articulo(val nombre: String, val cantidad: Int)
enum class Genero(val codigo: Int, val ejemplos: String) {
    INDEFINIDO(
        codigo = 0,
        ejemplos = "Indefinidos"
    ),
    THRILLER(
        codigo = 11,
        ejemplos = "Black Mirror, Breaking Bad, Sons of Anarchy, Casa de Papel..."
    ),
    ANIMACION(
        codigo = 21,
        ejemplos = "Rick y Morty, Bojack Horseman, Mr. Pickles..."
    ),
    FICCION(
        codigo = 31,
        ejemplos = "The 100, Orphan Black, The Leftovers, Stranger Things..."
    ),
    DRAMA(
        codigo = 41,
        ejemplos = "Homeland, The Good Wife, House of Cards..."
    ),
    COMEDIA(
        codigo = 51,
        ejemplos = "Arrested Development, The Bid Bang Theory, Orange Is The New Black, Sex Education..."
    ),
    TERROR(
        codigo = 61,
        ejemplos = "American Horror Story, The Outsider, The Haunting of Hill House..."
    );

    override fun toString() = "$name como [$ejemplos]"
}

data class Serie(
    val coidog: Int,
    val titulo: String,
    val numeroTemporadas: Int,
    val numeroCapitulosTemporada: Int,
    val temporada: Int,
    val capitulo: Int,
    val acabada: Boolean,
    val genero: Genero,
    val creador: String
)

fun ejercicio1() {
    val provincias = listOf("Alicante", "Valencia", "Castellón", "...")
    var pagasEmpleado = FloatArray(12)
    pagasEmpleado[0] = 1250.3f
    var gruposSemana = arrayOfNulls<String>(size = 5)
    gruposSemana.set(2, "Los Puntiagudos")
    var carrito = mutableListOf<Articulo>()
    carrito.add(Articulo("Pepinos", 5))
    val meses = listOf("Enero", "Febrero", "...")
    val datosLogin = mutableMapOf<String, String>()
    datosLogin.set("pepe", "pepe1234")
    var misSeries = mutableListOf<Serie>()
    misSeries.add(
        Serie(
            coidog = 111,
            titulo = "Orphan Black",
            numeroTemporadas = 5,
            numeroCapitulosTemporada = 10,
            temporada = 5,
            capitulo = 9,
            acabada = false,
            genero = Genero.FICCION,
            creador = "Graeme Manson y John Fawcett"
        )
    )
    val mesesDias = mapOf<String, Int>("Enero" to 1, "Febrero" to 28, "..." to 30)
    var menus = arrayOfNulls<Pair<String, String>>(size = 7)
    menus[0] = Pair(
        "Lunes",
        "Ensalada mediterranea, calamares con tomate y patatas y flan de huevo de postre"
    )
    val palabrasClave = arrayOf("if", "else", "int", "...")
}