package ejercicios.kotlin.colecciones

object GestionClaves {

    class ClavesException(mensaje: String) : Exception(mensaje)

    private var claves = mutableMapOf<String, String>()
    fun añadeLogin(login: String, password: String) {
        if (claves.contains(login) || login.isEmpty())
            throw ClavesException("El login ya existe o no es válido, intentelo de nuevo")
        claves.put(login, password)
    }

    fun modificaPassword(login: String) {
        if (!claves.contains(login) || login.isEmpty())
            throw ClavesException("El login no existe, no puedes modificar la contraseña")
        print("Introduce la anterior contraseña")
        val contraseña = readLine()
        if (claves[login] != contraseña) println("Lo siento has introducido una contraseña incorrecta")
        else {
            println("Introduce una nueva contraseña")
            claves[login] = readln()
        }
    }

    fun eliminaLogin(login: String) {
        if (!claves.contains(login))
            throw ClavesException("El login no existe, no puedes eliminarlo")
        claves.remove(login)
    }

    fun mostrarTodo() {
        claves.forEach { println("${it.key} -- ${it.value}") }
    }
}

fun ejercicio2() {
    var opcion: String = ""
    do {
        try {
            println("1. Añade login")
            println("2. Modifica password")
            println("3. Elimina login")
            println("4. Salir")
            opcion = readln()
            when (opcion.toIntOrNull()) {
                1 -> {
                    print("Introduce login")
                    val login = readln()
                    print("Introduce la contraseña")
                    val password = readln()
                    GestionClaves.añadeLogin(login, password)
                }

                2 -> {
                    print("Introduce login")
                    val login = readln()
                    GestionClaves.modificaPassword(login)
                }

                3 -> {
                    print("Introduce login")
                    val login = readln()
                    GestionClaves.eliminaLogin(login)
                }

                4 -> println("Hasta luego")

                else -> println("Lo siento esa no es una opción válida")
            }
        } catch (e: GestionClaves.ClavesException) {
            println(e.message)
        }

    } while (opcion != "4")
    GestionClaves.mostrarTodo()
}
