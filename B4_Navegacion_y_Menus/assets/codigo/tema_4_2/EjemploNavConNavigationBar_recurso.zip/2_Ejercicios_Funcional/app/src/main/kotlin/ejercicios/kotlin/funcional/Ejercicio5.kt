package ejercicios.kotlin.funcional

data class Usuario(
    val login: String, val password: String
)

sealed interface UsuarioEvent {
    data class AñadeUsuario(val usuario: Usuario) : UsuarioEvent
    data class ModificaUsuario(val login: String, val password: String) : UsuarioEvent
    object MuestraUsuarios : UsuarioEvent
}

class UsuarioViewModel() {
    var usuarios = mutableListOf<Usuario>()

    fun onUsuarioEvent(usuarioEvent: UsuarioEvent) {
        when (usuarioEvent) {
            is UsuarioEvent.MuestraUsuarios -> mostrarInformacion(usuarios)

            is UsuarioEvent.ModificaUsuario -> {
                val aux = usuarios.filter { it.login == usuarioEvent.login }
                if (aux != null) usuarios[usuarios.indexOf(aux[0])] =
                    Usuario(usuarioEvent.login, usuarioEvent.password)
            }

            is UsuarioEvent.AñadeUsuario ->
                if (usuarios.filter { it.login == usuarioEvent.usuario.login }.size == 0)
                    usuarios.add(
                        usuarioEvent.usuario
                    )
        }
    }

}

fun mostrarInformacion(usuarios: MutableList<Usuario>) = usuarios.forEach { println(it) }

fun usuarioScreen(
    usuarioEvent: (UsuarioEvent) -> Unit
) {
    var opcion: String = ""
    do {
        println("\n1. Añade usuario")
        println("2. Modifica usuario")
        println("3. Mostrar usuarios")
        println("4. Salir")
        opcion = readln()
        when (opcion) {
            "1" -> {
                print("Introduce login ")
                val login = readln()
                print("Introduce la contraseña ")
                val password = readln()
                usuarioEvent(UsuarioEvent.AñadeUsuario(Usuario(login, password)))
            }

            "2" -> {
                print("Introduce login ")
                val login = readln()
                print("Introduce la contraseña ")
                val password = readln()
                usuarioEvent(UsuarioEvent.ModificaUsuario(login, password))
            }

            "3" -> {
                println("Los usuarios son:")
                usuarioEvent(UsuarioEvent.MuestraUsuarios)
            }
        }
    } while (opcion != "4")
}

fun ejercicio5() {
    val usuarioViewModel = UsuarioViewModel()
    usuarioScreen(usuarioViewModel::onUsuarioEvent)
}
