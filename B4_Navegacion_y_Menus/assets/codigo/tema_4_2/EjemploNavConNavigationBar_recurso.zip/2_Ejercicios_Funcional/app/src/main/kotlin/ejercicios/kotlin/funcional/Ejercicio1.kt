package ejercicios.kotlin.funcional

fun ejercicio1() {
    val lista = listOf(2, 4, 12, 3, 18, 4, 7, 6, 21, 33, 17, 30, 27)

    print("Lista: ")
    lista.forEach { print(" {$it} ") }
    print("\nIntroduce un número: ")
    val n = readln().toInt()

    println("\nMúltiplos de $n - Usando Clausuras")
    lista.forEach {
        val xMultiploDeY_ConClausura = { y: Int -> it % y == 0 }
        if (xMultiploDeY_ConClausura(n)) print("${it} : ")
    }

    println("\nMúltiplos de $n - Sin usar Clausuras")
    val xMultiploDeY_SinClausura = { x: Int, y: Int -> x % y == 0 }
    lista.forEach {
        if (xMultiploDeY_SinClausura(it, n)) print("${it} : ")
    }

}