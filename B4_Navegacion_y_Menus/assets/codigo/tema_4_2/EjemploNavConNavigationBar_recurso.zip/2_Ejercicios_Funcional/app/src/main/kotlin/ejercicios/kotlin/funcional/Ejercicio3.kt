package ejercicios.kotlin.funcional

fun ejercicio3() {
    val reales = listOf<Double>(0.5, 1.6, 2.8, 3.9, 4.1, 5.2, 6.3, 7.4, 8.1, 9.2)
    var texto = ""

    //// 1 ////
    reales.forEach { texto += "$it " }
    println("Solución 1: \n $texto")

    //// 2 ////
    val r = reales.map { it - it.toInt() }.filter { it < 0.5 }.size
    println("Solución 2: \n $r")

    //// 3 ////
    val s = reales.map {
        object {
            val e = it.toInt()
            val r = it
        }
    }.filter { it.e % 3 == 0 }.fold(0.0) { s, it -> s + it.r }
    println("Solución 3: \n $s")

    //// 4 ////
    val m = reales.map {
        object {
            val d = it - it.toInt()
            val r = it
        }
    }.filter { it.d > 0.5 }.fold(0.0) { c, it -> if (it.r > c) it.r else c }
    //maxOf { it.r }
    println("Solución 4: \n $m")
}