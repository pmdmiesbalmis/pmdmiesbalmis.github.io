package ejercicios.kotlin.funcional

fun ejercicio2() {
    val lista =
        listOf(
            "rosa",
            "rosana",
            "mesa",
            "flor",
            "ventana",
            "blanco",
            "perro",
            "sillón",
            "azul",
            "melón"
        )

    print("Lista: ")
    lista.forEach { print(" {$it} ") }
    print("\nIntroduce una cadena a buscar: ")
    val cadena = readln()

    println("\nCoincidencias de $cadena")
    val coincidenciasCadena_UsandoClausuras =
        { x: String, lista: List<String> -> lista.filter { it.contains(x) } }
    //it==x devolvería cadenas coincidentes
    coincidenciasCadena_UsandoClausuras(cadena, lista).forEach { println(it) }
}