package com.pmdm.navegacion.ui.features

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.github.pmdmiesbalmis.components.ui.icons.Filled
import com.pmdm.navegacion.R
import com.pmdm.navegacion.ui.theme.EjemploNavegacionTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaScreen(
    pantalla: Int,
    onNavigatePantallaAnterior: () -> Unit,
    principal: Boolean = false,
    onOpenModalDrawerSheet: () -> Unit = {}
) {
    val comportamientoAnteScroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    val backgroundColor = when (pantalla) {
        1 -> Color(red = 178, green = 235, blue = 242, alpha = 255)
        2 -> Color(red = 200, green = 230, blue = 201, alpha = 255)
        3 -> Color(red = 248, green = 187, blue = 208, alpha = 255)
        4 -> Color(red = 255, green = 249, blue = 196, alpha = 255)
        5 -> Color(red = 197, green = 202, blue = 233, alpha = 255)
        else -> throw IllegalArgumentException("Pantalla $pantalla no soportada")
    }

    Scaffold(
        modifier = Modifier.nestedScroll(comportamientoAnteScroll.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = {
                    Text("Ejemplo NavigationDrawer", maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = {
                    if (!principal) {
                        IconButton(onClick = onNavigatePantallaAnterior) {
                            Icon(painter = Filled.getArrowBackIosIcon(), contentDescription = null)
                        }
                    } else {
                        IconButton(onClick = onOpenModalDrawerSheet) {
                            Icon(painter = painterResource(R.drawable.menu_24px), contentDescription = null)
                        }
                    }
                },
                scrollBehavior = comportamientoAnteScroll
            )
        },
        content = { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues = innerPadding)
                    .background(color = backgroundColor),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    modifier = Modifier.padding(bottom = 32.dp),
                    text = "Pantalla actual $pantalla",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.headlineLarge
                )
            }
        }
    )
}

@Preview(showBackground = true)
@Composable
fun PantallaScreenPreview() {
    EjemploNavegacionTheme {
        Surface {
            PantallaScreen(
                pantalla = 1,
                onNavigatePantallaAnterior = {}
            ) {}
        }
    }
}