package com.pmdm.navegacion.ui.features

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavHostController
import androidx.navigation.NavOptionsBuilder
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.pmdm.navegacion.R
import com.pmdm.navegacion.ui.navigation.EjemploNavHost
import com.pmdm.navegacion.ui.navigation.Pantalla1Route
import com.pmdm.navegacion.ui.navigation.Pantalla2Route
import com.pmdm.navegacion.ui.navigation.Pantalla3Route
import com.pmdm.navegacion.ui.navigation.Pantalla4Route
import com.pmdm.navegacion.ui.navigation.Pantalla5Route
import kotlinx.coroutines.launch

private fun iOpcionNevagacionSeleccionadaAPartirDeDestino(destino: NavDestination?): Int {
    return when {
        destino == null -> 0
        destino.hasRoute<Pantalla1Route>() -> 0
        destino.hasRoute<Pantalla2Route>() -> 1
        destino.hasRoute<Pantalla3Route>() -> 2
        destino.hasRoute<Pantalla4Route>() -> 3
        destino.hasRoute<Pantalla5Route>() -> 4
        else -> 0
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EjemploNavigationDrawer() {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val navController : NavHostController = rememberNavController()

    val entradaEnPilaDeNavegacionActuasState by navController.currentBackStackEntryAsState()
    val iPantalla by remember {
        derivedStateOf {
            iOpcionNevagacionSeleccionadaAPartirDeDestino(
                entradaEnPilaDeNavegacionActuasState?.destination
            )
        }
    }

    val titlesAndIcons = remember {
        listOf(
            "Pantalla 1" to R.drawable.filter_1_24px,
            "Pantalla 2" to R.drawable.filter_2_24px,
            "Pantalla 3" to R.drawable.filter_3_24px,
            "Pantalla 4" to R.drawable.filter_4_24px,
            "Pantalla 5" to R.drawable.filter_5_24px,
        )
    }

    fun NavOptionsBuilder.volverAPantallaInicial() =  popUpTo(Pantalla1Route) { inclusive = false }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text("Menu", modifier = Modifier.padding(16.dp))
                HorizontalDivider()
                titlesAndIcons.forEachIndexed { index, (title, idIcon) ->
                    NavigationDrawerItem(
                        label = { Text(text = title) },
                        icon = {
                            Icon(
                                painter = painterResource(idIcon),
                                contentDescription = ""
                            )
                        },
                        selected = iPantalla == index,
                        onClick = {
                            scope.launch {
                                drawerState.close()
                            }
                            when (index) {
                                0 -> navController.navigate(Pantalla1Route) { volverAPantallaInicial() }
                                1 -> navController.navigate(Pantalla2Route) { volverAPantallaInicial() }
                                2 -> navController.navigate(Pantalla3Route) { volverAPantallaInicial() }
                                3 -> navController.navigate(Pantalla4Route) { volverAPantallaInicial() }
                                4 -> navController.navigate(Pantalla5Route) { volverAPantallaInicial() }
                            }
                        }
                    )
                }
            }
        }
    ) {
        EjemploNavHost(navController = navController) {
            if (drawerState.isClosed)
                scope.launch {
                    drawerState.open()
                }
        }
    }
}