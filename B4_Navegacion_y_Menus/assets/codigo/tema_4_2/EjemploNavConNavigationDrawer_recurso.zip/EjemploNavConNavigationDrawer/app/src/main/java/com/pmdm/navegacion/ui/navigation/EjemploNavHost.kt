package com.pmdm.navegacion.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost

@Composable
fun EjemploNavHost(
    navController: NavHostController,
    onOpenModalDrawerSheet: () -> Unit
) {
    NavHost(
        navController = navController,
        startDestination = Pantalla1Route
    ) {
        pantalla1Destination(
            onNavigatePantallaAnterior = { navController.navigateUp() },
            onOpenModalDrawerSheet = onOpenModalDrawerSheet
        )
        pantalla2Destination(onNavigatePantallaAnterior = { navController.navigateUp() })
        pantalla3Destination(onNavigatePantallaAnterior = { navController.navigateUp() })
        pantalla4Destination(onNavigatePantallaAnterior = { navController.navigateUp() })
        pantalla5Destination(onNavigatePantallaAnterior = { navController.navigateUp() })
    }
}