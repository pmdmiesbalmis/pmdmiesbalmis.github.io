package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaScreen
import kotlinx.serialization.Serializable

@Serializable
object Pantalla3Route

fun NavGraphBuilder.pantalla3Destination(
    onNavigatePantallaAnterior: () -> Unit
) {
    composable<Pantalla3Route>{ backStackEntry ->
        PantallaScreen(
            pantalla = 3,
            onNavigatePantallaAnterior = onNavigatePantallaAnterior,
        )
    }
}