package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaScreen
import kotlinx.serialization.Serializable

@Serializable
object Pantalla4Route

fun NavGraphBuilder.pantalla4Destination(
    onNavigatePantallaAnterior: () -> Unit
) {
    composable<Pantalla4Route>{ backStackEntry ->
        PantallaScreen(
            pantalla = 4,
            onNavigatePantallaAnterior = onNavigatePantallaAnterior,
        )
    }
}