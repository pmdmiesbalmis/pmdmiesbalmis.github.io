package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaScreen
import kotlinx.serialization.Serializable

@Serializable
object Pantalla5Route

fun NavGraphBuilder.pantalla5Destination(
    onNavigatePantallaAnterior: () -> Unit
) {
    composable<Pantalla5Route>{ backStackEntry ->
        PantallaScreen(
            pantalla = 5,
            onNavigatePantallaAnterior = onNavigatePantallaAnterior,
        )
    }
}