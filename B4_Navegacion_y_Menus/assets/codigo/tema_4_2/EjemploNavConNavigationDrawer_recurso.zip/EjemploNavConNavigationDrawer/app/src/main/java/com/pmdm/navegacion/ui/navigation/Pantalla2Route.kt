package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaScreen
import kotlinx.serialization.Serializable

@Serializable
object Pantalla2Route

fun NavGraphBuilder.pantalla2Destination(
    onNavigatePantallaAnterior: () -> Unit
) {
    composable<Pantalla2Route>{ backStackEntry ->
        PantallaScreen(
            pantalla = 2,
            onNavigatePantallaAnterior = onNavigatePantallaAnterior,
        )
    }
}