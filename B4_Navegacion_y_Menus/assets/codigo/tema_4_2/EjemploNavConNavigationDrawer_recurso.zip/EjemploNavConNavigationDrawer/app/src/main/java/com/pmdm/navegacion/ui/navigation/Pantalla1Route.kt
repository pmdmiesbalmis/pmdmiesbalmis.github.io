package com.pmdm.navegacion.ui.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.compose.composable
import com.pmdm.navegacion.ui.features.PantallaScreen
import kotlinx.serialization.Serializable

@Serializable
object Pantalla1Route

fun NavGraphBuilder.pantalla1Destination(
    onNavigatePantallaAnterior: () -> Unit,
    onOpenModalDrawerSheet: () -> Unit
) {
    composable<Pantalla1Route>{ backStackEntry ->
        PantallaScreen(
            pantalla = 1,
            onNavigatePantallaAnterior = onNavigatePantallaAnterior,
            principal = true,
            onOpenModalDrawerSheet = onOpenModalDrawerSheet
        )
    }
}