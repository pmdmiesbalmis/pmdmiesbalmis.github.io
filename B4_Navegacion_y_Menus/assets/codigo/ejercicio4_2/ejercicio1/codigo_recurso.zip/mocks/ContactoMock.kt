package com.navegacion.data.mocks

enum class TipoContacto{amigos, coro, familia, trabajo, vecinos;

    fun toTipoContactoModelo()=when(this){
        TipoContacto.amigos -> com.navegacion.models.TipoContacto.amigos
        TipoContacto.coro -> com.navegacion.models.TipoContacto.coro
        TipoContacto.familia -> com.navegacion.models.TipoContacto.familia
        TipoContacto.trabajo -> com.navegacion.models.TipoContacto.trabajo
        TipoContacto.vecinos -> com.navegacion.models.TipoContacto.vecinos
    }
}
data class ContactoMock(val id:Int, val nombre:String, val tipo:TipoContacto)
