package com.pmdm.navegacionlateral.data.mocks

import javax.inject.Inject

class ContactoRepository @Inject constructor(
    private val contactoDaoMock: ContactoDaoMock
) {
    fun getTodos() = contactoDaoMock.getTodos().toList()
    fun getAmigos() = contactoDaoMock.getAmigos()
    fun getCoro() = contactoDaoMock.getCoro()
    fun getTrabajo() = contactoDaoMock.getTrabajo()
    fun getFamilia() = contactoDaoMock.getFamilia()
    fun getVecinos() = contactoDaoMock.getVecinos()
    fun getTipoContacto(id: Int) = contactoDaoMock.getContacto(id)?.tipo
}