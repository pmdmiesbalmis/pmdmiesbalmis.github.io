package com.pmdm.navegacionlateral.data.mocks
import com.pmdm.navegacionlateral.models.TipoContacto

data class ContactoMock(val id: Int, val nombre: String, val tipo: TipoContacto)
