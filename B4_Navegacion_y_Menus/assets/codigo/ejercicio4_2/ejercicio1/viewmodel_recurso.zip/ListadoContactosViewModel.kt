package com.navegacion.ui.features

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.navegacion.data.mocks.ContactoRepository
import com.navegacion.models.Contacto
import com.navegacion.models.TipoContacto
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class ListadoContactosViewModel @Inject constructor(private val contactoRepository: ContactoRepository) :
    ViewModel() {
    var itemSeleccionado by mutableStateOf(0)
    var visualizarbottomBar by mutableStateOf(true)

    var lista by mutableStateOf(
        contactoRepository.getTodos()
            .map { Contacto(it.id, it.nombre, it.tipo.toTipoContactoModelo()) })
    val onNavigateTo: (TipoContacto) -> Unit = {
        visualizarbottomBar = it != TipoContacto.trabajo
    }
    val onItemSeleccionado: (Int) -> Unit =
        {
            visualizarbottomBar = true
            itemSeleccionado = it
            when (it) {
                1 -> lista = contactoRepository.getAmigos()
                    .map { Contacto(it.id, it.nombre, it.tipo.toTipoContactoModelo()) }

                2 -> lista = contactoRepository.getCoro()
                    .map { Contacto(it.id, it.nombre, it.tipo.toTipoContactoModelo()) }

                3 -> lista = contactoRepository.getFamilia()
                    .map { Contacto(it.id, it.nombre, it.tipo.toTipoContactoModelo()) }

                4 -> lista = contactoRepository.getTrabajo()
                    .map { Contacto(it.id, it.nombre, it.tipo.toTipoContactoModelo()) }

                5 -> lista = contactoRepository.getVecinos()
                    .map { Contacto(it.id, it.nombre, it.tipo.toTipoContactoModelo()) }

                else -> lista = contactoRepository.getTodos()
                    .map { Contacto(it.id, it.nombre, it.tipo.toTipoContactoModelo()) }
            }
        }
}