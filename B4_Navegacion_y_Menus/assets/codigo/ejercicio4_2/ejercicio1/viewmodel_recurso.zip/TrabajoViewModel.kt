package com.navegacion.ui.features

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.navegacion.data.mocks.ContactoRepository
import com.navegacion.models.Contacto
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class TrabajoViewModel @Inject constructor(private val contactoRepository: ContactoRepository) :
    ViewModel() {
    var selectedTabIndex by mutableStateOf(0)

    val lista by mutableStateOf(
        contactoRepository.getTodos()
            .map { Contacto(it.id, it.nombre, it.tipo.toTipoContactoModelo()) })
    val onSelectedTabIndex: (Int) -> Unit =
        {
            selectedTabIndex = it
        }

    fun getContacto(idContacto: Int) = lista.find { it.id==idContacto }

}