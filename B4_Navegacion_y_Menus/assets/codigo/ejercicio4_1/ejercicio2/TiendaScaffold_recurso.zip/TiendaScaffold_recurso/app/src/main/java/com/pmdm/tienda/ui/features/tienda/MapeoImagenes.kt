package com.pmdm.tienda.ui.features.tienda

import com.pmdm.tienda.R


fun recursoImagen(url:String):Int?=mapOf(
        "imagen1" to R.drawable.imagen1,
        "imagen2" to R.drawable.imagen2,
        "imagen3" to R.drawable.imagen3,
        "imagen4" to R.drawable.imagen4,
        "imagen5" to R.drawable.imagen5,
        "imagen6" to R.drawable.imagen6,
        "imagen7" to R.drawable.imagen7,
        "imagen8" to R.drawable.imagen8,
        "imagen9" to R.drawable.imagen9,
        "imagen10" to R.drawable.imagen10,
        "imagen11" to R.drawable.imagen11,
        "imagen12" to R.drawable.imagen12,
        "imagen13" to R.drawable.imagen13,
        "imagen14" to R.drawable.imagen14,
        "imagen15" to R.drawable.imagen15,
        "imagen16" to R.drawable.imagen16,
        "imagen17" to R.drawable.imagen17,
        "imagen18" to R.drawable.imagen18,
        "imagen19" to R.drawable.imagen19,
        "imagen20" to R.drawable.imagen20,
).get(url)
