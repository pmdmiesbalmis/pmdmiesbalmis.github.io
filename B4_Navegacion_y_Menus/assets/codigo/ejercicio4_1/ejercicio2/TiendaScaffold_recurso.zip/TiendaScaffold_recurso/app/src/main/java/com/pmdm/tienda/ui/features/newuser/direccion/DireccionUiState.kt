package com.pmdm.tienda.ui.features.newuser.direccion

data class DireccionUiState(
    val calle: String = "",
    val ciudad: String = "",
    val codigoPostal: String = "",
)