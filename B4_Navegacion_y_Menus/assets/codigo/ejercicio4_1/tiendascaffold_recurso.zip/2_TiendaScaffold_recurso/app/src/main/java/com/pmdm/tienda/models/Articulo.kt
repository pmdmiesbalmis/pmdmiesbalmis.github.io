package com.pmdm.tienda.models

data class Articulo(val id:Int, val url:String, val precio:Float, val descripcion:String)
